/**
 * Telegram rate fetcher mini-service.
 *
 * Polls the public Telegram channel @NerkhDollarIRT every 2 minutes, parses
 * the latest USD->IRR (Toman) rate, and writes it to the shared SQLite
 * database so BOTH the main app (port 3000) and the admin panel (port 3001)
 * always show the live rate.
 *
 * Port 3010 is only used for a tiny /status health endpoint. The real work is
 * the periodic background poll.
 */

import { PrismaClient } from '@prisma/client'
import { fetchTelegramRate, type TelegramRate } from '../../src/lib/telegram-rate'

const db = new PrismaClient({ log: ['error'] })
const PORT = 3010
const POLL_INTERVAL_MS = 2 * 60 * 1000 // 2 minutes

function todayTehran(date = new Date()): string {
  const tehran = new Date(date.getTime() + (3.5 * 60 + date.getTimezoneOffset()) * 60000)
  const y = tehran.getUTCFullYear()
  const m = String(tehran.getUTCMonth() + 1).padStart(2, '0')
  const d = String(tehran.getUTCDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

async function refresh(): Promise<TelegramRate | null> {
  const rate = await fetchTelegramRate(true)
  if (!rate) return null

  const setting = await db.currencySetting.findUnique({ where: { id: 'singleton' } })
  await db.currencySetting.update({
    where: { id: 'singleton' },
    data: { lastAutoRate: rate.rate, lastAutoStatus: rate.status, lastAutoFetchAt: rate.fetchedAt },
  })

  const today = todayTehran()
  const existing = await db.currencyRate.findUnique({ where: { date: today } })
  if (setting?.autoUpdateEnabled) {
    if (!existing) {
      await db.currencyRate.create({
        data: { date: today, rate: rate.rate, marginPercent: setting.marginPercent, source: 'TELEGRAM', note: `نرخ خودکار تلگرام (${rate.status})` },
      })
    } else if (existing.source === 'TELEGRAM') {
      await db.currencyRate.update({
        where: { date: today },
        data: { rate: rate.rate, note: `نرخ خودکار تلگرام (${rate.status})` },
      })
    }
    // If existing is MANUAL, leave it — admin override wins.
  }
  return rate
}

async function poll() {
  try {
    const rate = await refresh()
    if (rate) {
      console.log(`[${new Date().toISOString()}] Telegram rate refreshed: ${rate.rate.toLocaleString()} تومان (${rate.status})`)
    } else {
      console.log(`[${new Date().toISOString()}] Telegram fetch returned no rate`)
    }
  } catch (e) {
    console.error(`[${new Date().toISOString()}] Poll error:`, (e as Error).message)
  }
}

// Initial fetch immediately, then poll on interval.
poll()
setInterval(poll, POLL_INTERVAL_MS)

// Tiny health/status server.
const server = Bun.serve({
  port: PORT,
  async fetch(req) {
    const url = new URL(req.url)
    if (url.pathname === '/status') {
      const setting = await db.currencySetting.findUnique({ where: { id: 'singleton' } })
      return Response.json({
        ok: true,
        service: 'telegram-rate-fetcher',
        lastAutoRate: setting?.lastAutoRate ?? null,
        lastAutoStatus: setting?.lastAutoStatus ?? null,
        lastAutoFetchAt: setting?.lastAutoFetchAt ?? null,
        autoUpdateEnabled: setting?.autoUpdateEnabled ?? null,
      })
    }
    if (url.pathname === '/refresh' && req.method === 'POST') {
      const rate = await refresh()
      return Response.json({ ok: !!rate, rate })
    }
    return new Response('telegram-rate-fetcher. GET /status or POST /refresh', { status: 404 })
  },
})

console.log(`[telegram-rate-fetcher] listening on :${PORT}, polling Telegram every ${POLL_INTERVAL_MS / 1000}s`)
