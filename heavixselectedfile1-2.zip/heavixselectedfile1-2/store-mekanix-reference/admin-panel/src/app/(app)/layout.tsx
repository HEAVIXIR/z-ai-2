import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { Sidebar } from '@/components/admin/sidebar'
import { Topbar } from '@/components/admin/topbar'
import { Footer } from '@/components/admin/footer'

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getSession()
  if (!session) redirect('/login')

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="flex flex-1 flex-col md:flex-row">
        <Sidebar session={session} />
        <div className="flex flex-1 flex-col min-w-0">
          <Topbar session={session} />
          <main className="flex-1 p-4 md:p-6 lg:p-8">{children}</main>
        </div>
      </div>
      <Footer />
    </div>
  )
}
