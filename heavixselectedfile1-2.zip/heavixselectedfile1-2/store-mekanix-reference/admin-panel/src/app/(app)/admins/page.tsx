'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Plus,
  RefreshCw,
  Loader2,
  Pencil,
  Trash2,
  ShieldCheck,
  UserCog,
  Lock,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Card, CardContent } from '@/components/ui/card'

interface AdminUser {
  id: string
  username: string
  name: string
  role: 'SUPER_ADMIN' | 'ADMIN' | 'OPERATOR'
  active: boolean
  lastLoginAt: string | null
  createdAt: string
  auditLogsCount: number
}
interface AdminsResp {
  currentId: string
  admins: AdminUser[]
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

function faDateTime(s: string | null): string {
  if (!s) return '—'
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(s))
  } catch {
    return s
  }
}

const ROLE_LABEL: Record<AdminUser['role'], string> = {
  SUPER_ADMIN: 'مدیر ارشد',
  ADMIN: 'مدیر',
  OPERATOR: 'اپراتور',
}

function roleBadge(role: AdminUser['role']) {
  if (role === 'SUPER_ADMIN') {
    return (
      <Badge className="bg-violet-100 text-violet-700 dark:bg-violet-950/40 dark:text-violet-300 hover:bg-violet-100 gap-1">
        <ShieldCheck className="h-3 w-3" /> {ROLE_LABEL[role]}
      </Badge>
    )
  }
  if (role === 'ADMIN') {
    return (
      <Badge className="bg-cyan-100 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300 hover:bg-cyan-100">
        {ROLE_LABEL[role]}
      </Badge>
    )
  }
  return (
    <Badge variant="secondary">{ROLE_LABEL[role]}</Badge>
  )
}

interface FormState {
  id?: string
  name: string
  username: string
  role: AdminUser['role']
  active: boolean
  password: string
}

const EMPTY: FormState = {
  name: '',
  username: '',
  role: 'OPERATOR',
  active: true,
  password: '',
}

export default function AdminsPage() {
  const [admins, setAdmins] = useState<AdminUser[]>([])
  const [currentId, setCurrentId] = useState('')
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState<FormState>(EMPTY)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleteName, setDeleteName] = useState('')
  const [deleteErr, setDeleteErr] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<AdminsResp>('/api/admin/admins')
      setAdmins(d.admins || [])
      setCurrentId(d.currentId || '')
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری مدیران')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  function openCreate() {
    setForm({ ...EMPTY })
    setDialogOpen(true)
  }
  function openEdit(a: AdminUser) {
    setForm({
      id: a.id,
      name: a.name,
      username: a.username,
      role: a.role,
      active: a.active,
      password: '',
    })
    setDialogOpen(true)
  }

  async function save() {
    if (!form.name.trim() || !form.username.trim()) {
      toast.error('نام و نام کاربری الزامی هستند')
      return
    }
    if (!form.id && form.password.length < 6) {
      toast.error('رمز عبور باید حداقل ۶ کاراکتر باشد')
      return
    }
    setSaving(true)
    try {
      const body: Record<string, unknown> = {
        name: form.name.trim(),
        role: form.role,
        active: form.active,
      }
      if (form.password) body.password = form.password
      if (!form.id) body.username = form.username.trim().toLowerCase()
      if (form.id) {
        await adminFetchJson(`/api/admin/admins/${form.id}`, { method: 'PUT', json: body })
        toast.success('مدیر بروزرسانی شد')
      } else {
        await adminFetchJson('/api/admin/admins', { method: 'POST', json: body })
        toast.success('مدیر ایجاد شد')
      }
      setDialogOpen(false)
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره‌سازی')
    } finally {
      setSaving(false)
    }
  }

  async function toggleActive(a: AdminUser, active: boolean) {
    if (a.id === currentId && !active) {
      toast.error('شما نمی‌توانید حساب خودتان را غیرفعال کنید')
      return
    }
    try {
      await adminFetchJson(`/api/admin/admins/${a.id}`, { method: 'PUT', json: { active } })
      setAdmins((prev) => prev.map((x) => (x.id === a.id ? { ...x, active } : x)))
      toast.success(active ? 'حساب فعال شد' : 'حساب غیرفعال شد')
    } catch (err) {
      toast.error((err as Error).message || 'خطا در تغییر وضعیت')
    }
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      const res = await adminFetch(`/api/admin/admins/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error || `HTTP ${res.status}`)
      }
      toast.success('مدیر حذف شد')
      setDeleteId(null)
      setDeleteErr('')
      load()
    } catch (err) {
      setDeleteErr((err as Error).message || 'خطا در حذف')
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">مدیران سیستم</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            مدیریت کاربران ادمین و سطوح دسترسی (RBAC)
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            بروزرسانی
          </Button>
          <Button size="sm" onClick={openCreate}>
            <Plus className="h-4 w-4" /> مدیر جدید
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4 md:p-6">
          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : admins.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center text-muted-foreground">
              <UserCog className="h-10 w-10 opacity-30" />
              <p className="text-sm">هیچ مدیری ثبت نشده است</p>
            </div>
          ) : (
            <div className="rounded-lg border max-h-[70vh] overflow-y-auto thin-scrollbar">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>نام</TableHead>
                    <TableHead>نام کاربری</TableHead>
                    <TableHead>نقش</TableHead>
                    <TableHead className="text-center">فعال</TableHead>
                    <TableHead className="hidden md:table-cell">آخرین ورود</TableHead>
                    <TableHead className="hidden lg:table-cell text-center">رویدادها</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {admins.map((a) => {
                    const isSelf = a.id === currentId
                    return (
                      <TableRow key={a.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className={`flex h-9 w-9 items-center justify-center rounded-full font-bold ${
                              a.role === 'SUPER_ADMIN'
                                ? 'bg-violet-100 text-violet-700 dark:bg-violet-950/40 dark:text-violet-300'
                                : 'bg-muted text-foreground'
                            }`}>
                              {a.name.slice(0, 1)}
                            </div>
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                {a.name}
                                {isSelf ? (
                                  <Badge variant="outline" className="text-[10px] gap-1">
                                    شما
                                  </Badge>
                                ) : null}
                              </div>
                              <div className="text-xs text-muted-foreground md:hidden">
                                {faDateTime(a.lastLoginAt)}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <code
                            className="text-xs font-mono ltr bg-muted px-1.5 py-0.5 rounded"
                            dir="ltr"
                          >
                            {a.username}
                          </code>
                        </TableCell>
                        <TableCell>{roleBadge(a.role)}</TableCell>
                        <TableCell className="text-center">
                          <Switch
                            checked={a.active}
                            disabled={isSelf}
                            onCheckedChange={(v) => toggleActive(a, v)}
                          />
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-xs text-muted-foreground whitespace-nowrap">
                          {faDateTime(a.lastLoginAt)}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-center">
                          <Badge variant="secondary" className="tabular-nums">
                            {faNum(a.auditLogsCount)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 justify-end">
                            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(a)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8 text-rose-600 hover:text-rose-700"
                              disabled={isSelf}
                              onClick={() => {
                                setDeleteId(a.id)
                                setDeleteName(a.name)
                                setDeleteErr('')
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCog className="h-5 w-5" />
              {form.id ? 'ویرایش مدیر' : 'مدیر جدید'}
            </DialogTitle>
            <DialogDescription>
              {form.id
                ? 'برای تغییر رمز عبور، رمز جدید را وارد کنید؛ در غیر این‌صورت خالی بگذارید.'
                : 'یک حساب مدیر جدید با نقش مشخص ایجاد کنید.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="ad-name">نام کامل *</Label>
              <Input
                id="ad-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثلاً: علی رضایی"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ad-username">نام کاربری *</Label>
              <Input
                id="ad-username"
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
                placeholder="ali"
                className="font-mono ltr"
                dir="ltr"
                disabled={!!form.id}
              />
              {form.id ? (
                <p className="text-xs text-muted-foreground">نام کاربری قابل تغییر نیست</p>
              ) : null}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>نقش</Label>
                <Select
                  value={form.role}
                  onValueChange={(v) => setForm({ ...form, role: v as AdminUser['role'] })}
                  disabled={form.id === currentId}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SUPER_ADMIN">
                      <span className="flex items-center gap-2">
                        <ShieldCheck className="h-3.5 w-3.5 text-violet-600" /> مدیر ارشد
                      </span>
                    </SelectItem>
                    <SelectItem value="ADMIN">مدیر</SelectItem>
                    <SelectItem value="OPERATOR">اپراتور</SelectItem>
                  </SelectContent>
                </Select>
                {form.id === currentId ? (
                  <p className="text-xs text-muted-foreground">نمی‌توانید نقش خودتان را تغییر دهید</p>
                ) : null}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ad-active">فعال</Label>
                <div className="flex h-9 items-center gap-2">
                  <Switch
                    id="ad-active"
                    checked={form.active}
                    onCheckedChange={(v) => setForm({ ...form, active: v })}
                    disabled={form.id === currentId}
                  />
                  <span className="text-sm">
                    {form.active ? 'فعال' : 'غیرفعال'}
                  </span>
                </div>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ad-password" className="flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5" />
                رمز عبور {form.id ? '(اختیاری)' : '*'}
              </Label>
              <Input
                id="ad-password"
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder={form.id ? 'برای تغییر، رمز جدید را وارد کنید' : 'حداقل ۶ کاراکتر'}
                dir="ltr"
              />
              {form.password && form.password.length < 6 ? (
                <p className="text-xs text-rose-600">رمز باید حداقل ۶ کاراکتر باشد</p>
              ) : null}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} disabled={saving}>
              انصراف
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              ذخیره
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (!o) { setDeleteId(null); setDeleteErr('') } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف مدیر</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteErr ? (
                <span className="text-rose-600 dark:text-rose-400 block mb-2">{deleteErr}</span>
              ) : null}
              آیا از حذف «{deleteName}» مطمئن هستید؟ رویدادهای لاگ مرتبط حفظ می‌شوند اما ارجاع به این کاربر حذف خواهد شد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
