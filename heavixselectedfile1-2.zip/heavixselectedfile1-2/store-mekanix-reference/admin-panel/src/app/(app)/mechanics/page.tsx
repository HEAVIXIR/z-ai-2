'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Search,
  RefreshCw,
  Loader2,
  Eye,
  Plus,
  Pencil,
  Star,
  ShieldCheck,
  ShieldAlert,
  ChevronLeft,
  ChevronRight,
  Wrench,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { formatIrr } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Card,
  CardContent,
} from '@/components/ui/card'

const MECHANIC_STATUS_LABEL: Record<string, string> = {
  ACTIVE: 'فعال',
  SUSPENDED: 'تعلیق',
}
const MECHANIC_STATUS_BADGE: Record<string, string> = {
  ACTIVE: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  SUSPENDED: 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200',
}
const ORDER_STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  CONFIRMED: 'تایید شده',
  PROCESSING: 'در حال پردازش',
  SHIPPED: 'ارسال شده',
  DELIVERED: 'تحویل شده',
  CANCELLED: 'لغو شده',
}
const PAYMENT_STATUS_LABEL: Record<string, string> = {
  UNPAID: 'پرداخت‌نشده',
  PENDING: 'در انتظار',
  PAID: 'پرداخت شده',
  REFUNDED: 'بازگشت',
}

interface MechanicListItem {
  id: string
  phone: string
  name: string
  family: string
  shopName?: string | null
  specialty?: string | null
  city?: string | null
  address?: string | null
  rating: number
  verified: boolean
  status: string
  totalOrders: number
  notes?: string | null
  createdAt: string
  _count: { orders: number }
}

interface MechanicDetail extends MechanicListItem {
  orders: Array<{
    id: string
    orderNumber: string
    status: string
    paymentStatus: string
    totalIrr: number
    totalUsd: number
    createdAt: string
    customer: { id: string; name: string; family: string; phone: string }
  }>
  _count: { orders: number }
}

interface MechanicsListResp {
  mechanics: MechanicListItem[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}

interface FormState {
  id?: string
  phone: string
  name: string
  family: string
  shopName: string
  specialty: string
  city: string
  address: string
  notes: string
  verified: boolean
  status: 'ACTIVE' | 'SUSPENDED'
}

const EMPTY_FORM: FormState = {
  phone: '',
  name: '',
  family: '',
  shopName: '',
  specialty: '',
  city: '',
  address: '',
  notes: '',
  verified: false,
  status: 'ACTIVE',
}

function faDateShort(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('fa-IR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
  } catch {
    return iso
  }
}
function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

export default function MechanicsPage() {
  const [mechanics, setMechanics] = useState<MechanicListItem[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [totalPages, setTotalPages] = useState(1)
  const [q, setQ] = useState('')
  const [fStatus, setFStatus] = useState<string>('')
  const [fVerified, setFVerified] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [refreshKey, setRefreshKey] = useState(0)

  const [formOpen, setFormOpen] = useState(false)
  const [form, setForm] = useState<FormState>(EMPTY_FORM)
  const [saving, setSaving] = useState(false)

  const [detail, setDetail] = useState<MechanicDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)

  const [togglingId, setTogglingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set('q', q)
      if (fStatus) params.set('status', fStatus)
      if (fVerified) params.set('verified', fVerified)
      params.set('page', String(page))
      params.set('pageSize', String(pageSize))
      const d = await adminFetchJson<MechanicsListResp>(
        `/api/admin/mechanics?${params.toString()}`,
      )
      setMechanics(d.mechanics)
      setTotal(d.total)
      setTotalPages(d.totalPages)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری مکانیک‌ها')
    } finally {
      setLoading(false)
    }
  }, [q, fStatus, fVerified, page, pageSize])

  useEffect(() => {
    void load()
  }, [load, refreshKey])

  const openAdd = useCallback(() => {
    setForm(EMPTY_FORM)
    setFormOpen(true)
  }, [])

  const openEdit = useCallback((m: MechanicListItem) => {
    setForm({
      id: m.id,
      phone: m.phone,
      name: m.name,
      family: m.family,
      shopName: m.shopName ?? '',
      specialty: m.specialty ?? '',
      city: m.city ?? '',
      address: m.address ?? '',
      notes: m.notes ?? '',
      verified: m.verified,
      status: (m.status as 'ACTIVE' | 'SUSPENDED') ?? 'ACTIVE',
    })
    setFormOpen(true)
  }, [])

  const submitForm = useCallback(async () => {
    if (!form.phone || !form.name || !form.family) {
      toast.error('موبایل، نام و نام خانوادگی الزامی است')
      return
    }
    setSaving(true)
    try {
      if (form.id) {
        await adminFetchJson(`/api/admin/mechanics/${form.id}`, {
          method: 'PUT',
          json: {
            phone: form.phone,
            name: form.name,
            family: form.family,
            shopName: form.shopName || null,
            specialty: form.specialty || null,
            city: form.city || null,
            address: form.address || null,
            notes: form.notes || null,
            verified: form.verified,
            status: form.status,
          },
        })
        toast.success('اطلاعات مکانیک بروزرسانی شد')
      } else {
        await adminFetch('/api/admin/mechanics', {
          method: 'POST',
          json: {
            phone: form.phone,
            name: form.name,
            family: form.family,
            shopName: form.shopName || null,
            specialty: form.specialty || null,
            city: form.city || null,
            address: form.address || null,
            notes: form.notes || null,
          },
        })
        toast.success('مکانیک جدید اضافه شد')
      }
      setFormOpen(false)
      setRefreshKey((k) => k + 1)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره')
    } finally {
      setSaving(false)
    }
  }, [form])

  const toggleVerified = useCallback(
    async (m: MechanicListItem) => {
      setTogglingId(m.id)
      try {
        await adminFetchJson(`/api/admin/mechanics/${m.id}`, {
          method: 'PATCH',
          json: { verified: !m.verified },
        })
        toast.success(m.verified ? 'تأیید مکانیک لغو شد' : 'مکانیک تأیید شد')
        setRefreshKey((k) => k + 1)
      } catch (err) {
        toast.error((err as Error).message || 'خطا در تغییر وضعیت')
      } finally {
        setTogglingId(null)
      }
    },
    [],
  )

  const openDetail = useCallback(async (m: MechanicListItem) => {
    setDetailOpen(true)
    setDetail(null)
    setDetailLoading(true)
    try {
      const d = await adminFetchJson<MechanicDetail>(`/api/admin/mechanics/${m.id}`)
      setDetail(d)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری جزئیات')
      setDetailOpen(false)
    } finally {
      setDetailLoading(false)
    }
  }, [])

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">مکانیک‌ها</h1>
          <p className="text-sm text-muted-foreground">
            مدیریت مکانیک‌های همکار، تأیید هویت و تخصیص سفارش‌ها
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setRefreshKey((k) => k + 1)}>
            <RefreshCw className="ml-2 h-4 w-4" />
            بروزرسانی
          </Button>
          <Button size="sm" onClick={openAdd} className="bg-emerald-600 text-white hover:bg-emerald-700">
            <Plus className="ml-2 h-4 w-4" />
            افزودن مکانیک
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="relative">
              <Search className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => {
                  setQ(e.target.value)
                  setPage(1)
                }}
                placeholder="موبایل، نام، فروشگاه، تخصص یا شهر..."
                className="pr-9"
              />
            </div>
            <Select
              value={fStatus}
              onValueChange={(v) => {
                setFStatus(v === '__all__' ? '' : v)
                setPage(1)
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه وضعیت‌ها</SelectItem>
                {Object.entries(MECHANIC_STATUS_LABEL).map(([k, v]) => (
                  <SelectItem key={k} value={k}>
                    {v}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={fVerified}
              onValueChange={(v) => {
                setFVerified(v === '__all__' ? '' : v)
                setPage(1)
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="تأیید هویت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه</SelectItem>
                <SelectItem value="true">تأیید شده</SelectItem>
                <SelectItem value="false">تأیید نشده</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto thin-scrollbar">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>نام</TableHead>
                  <TableHead>موبایل</TableHead>
                  <TableHead>فروشگاه</TableHead>
                  <TableHead>تخصص</TableHead>
                  <TableHead>شهر</TableHead>
                  <TableHead className="text-center">امتیاز</TableHead>
                  <TableHead className="text-center">تأیید هویت</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead className="text-center">سفارش</TableHead>
                  <TableHead className="text-left">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={`sk-${i}`}>
                      <TableCell colSpan={10}>
                        <Skeleton className="h-6 w-full" />
                      </TableCell>
                    </TableRow>
                  ))
                ) : mechanics.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="py-12 text-center text-muted-foreground">
                      <Wrench className="mx-auto mb-2 h-8 w-8 opacity-50" />
                      مکانیکی یافت نشد
                    </TableCell>
                  </TableRow>
                ) : (
                  mechanics.map((m) => (
                    <TableRow key={m.id} className="cursor-pointer hover:bg-muted/50" onClick={() => openDetail(m)}>
                      <TableCell>
                        <span className="font-medium">
                          {m.name} {m.family}
                        </span>
                      </TableCell>
                      <TableCell className="ltr-content" dir="ltr">
                        {m.phone}
                      </TableCell>
                      <TableCell className="text-sm">{m.shopName ?? '—'}</TableCell>
                      <TableCell className="text-sm">{m.specialty ?? '—'}</TableCell>
                      <TableCell className="text-sm">{m.city ?? '—'}</TableCell>
                      <TableCell className="text-center">
                        <div className="inline-flex items-center gap-1">
                          <Star className="h-3.5 w-3.5 text-amber-500" />
                          <span className="tabular-nums text-xs">{m.rating.toFixed(1)}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <button
                          type="button"
                          aria-label={m.verified ? 'تأیید شده' : 'تأیید نشده'}
                          disabled={togglingId === m.id}
                          onClick={(e) => {
                            e.stopPropagation()
                            void toggleVerified(m)
                          }}
                          className={`inline-flex h-7 w-7 items-center justify-center rounded-full transition-colors ${
                            m.verified
                              ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300'
                              : 'bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-slate-800/40 dark:text-slate-400'
                          } disabled:opacity-50`}
                        >
                          {m.verified ? <ShieldCheck className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
                        </button>
                      </TableCell>
                      <TableCell>
                        <Badge className={MECHANIC_STATUS_BADGE[m.status] ?? ''} variant="outline">
                          {MECHANIC_STATUS_LABEL[m.status] ?? m.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center tabular-nums">
                        {faNum(m._count.orders)}
                      </TableCell>
                      <TableCell className="text-left">
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation()
                              openDetail(m)
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation()
                              openEdit(m)
                            }}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 ? (
            <div className="flex items-center justify-between border-t p-3">
              <span className="text-xs text-muted-foreground">
                صفحه {faNum(page)} از {faNum(totalPages)}
              </span>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  <ChevronRight className="h-4 w-4" />
                  قبلی
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                >
                  بعدی
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {/* Add / Edit dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto thin-scrollbar">
          <DialogHeader>
            <DialogTitle>{form.id ? 'ویرایش مکانیک' : 'افزودن مکانیک جدید'}</DialogTitle>
            <DialogDescription>
              {form.id
                ? 'اطلاعات مکانیک را بروزرسانی کنید'
                : 'فرم زیر را برای ثبت مکانیک جدید تکمیل کنید'}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">نام *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">نام خانوادگی *</Label>
              <Input value={form.family} onChange={(e) => setForm({ ...form, family: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">موبایل *</Label>
              <Input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="mt-1 ltr-content"
                dir="ltr"
                placeholder="09xxxxxxxxx"
              />
            </div>
            <div>
              <Label className="text-xs">فروشگاه</Label>
              <Input value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">تخصص</Label>
              <Input value={form.specialty} onChange={(e) => setForm({ ...form, specialty: e.target.value })} className="mt-1" placeholder="مثال: برق خودرو، موتور، گیربکس" />
            </div>
            <div>
              <Label className="text-xs">شهر</Label>
              <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="mt-1" />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-xs">آدرس</Label>
              <Textarea
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="mt-1 min-h-[60px]"
              />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-xs">یادداشت داخلی</Label>
              <Textarea
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                className="mt-1 min-h-[60px]"
              />
            </div>
            {form.id ? (
              <div>
                <Label className="text-xs">وضعیت</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as 'ACTIVE' | 'SUSPENDED' })}>
                  <SelectTrigger className="mt-1 w-full">
                    <SelectValue placeholder="وضعیت" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(MECHANIC_STATUS_LABEL).map(([k, v]) => (
                      <SelectItem key={k} value={k}>
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}
            {form.id ? (
              <div className="flex items-end">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={form.verified}
                    onChange={(e) => setForm({ ...form, verified: e.target.checked })}
                  />
                  تأیید هویت شده
                </label>
              </div>
            ) : null}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>
              انصراف
            </Button>
            <Button disabled={saving} onClick={submitForm} className="bg-emerald-600 text-white hover:bg-emerald-700">
              {saving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
              {form.id ? 'ذخیره تغییرات' : 'ثبت مکانیک'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto thin-scrollbar">
          {detailLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : detail ? (
            <div className="space-y-5">
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2">
                  <span>{detail.name} {detail.family}</span>
                  <Badge className={MECHANIC_STATUS_BADGE[detail.status] ?? ''} variant="outline">
                    {MECHANIC_STATUS_LABEL[detail.status] ?? detail.status}
                  </Badge>
                  {detail.verified ? (
                    <Badge variant="outline" className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200">
                      <ShieldCheck className="h-3 w-3" />
                      تأیید شده
                    </Badge>
                  ) : null}
                </DialogTitle>
                <DialogDescription>
                  <span className="ltr-content" dir="ltr">{detail.phone}</span>
                  {' · '}
                  عضو از {faDateShort(detail.createdAt)}
                </DialogDescription>
              </DialogHeader>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">امتیاز</p>
                  <p className="mt-1 flex items-center gap-1 font-semibold">
                    <Star className="h-3.5 w-3.5 text-amber-500" />
                    <span className="tabular-nums">{detail.rating.toFixed(1)}</span>
                  </p>
                </div>
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">سفارش‌ها</p>
                  <p className="mt-1 font-semibold tabular-nums">{faNum(detail._count.orders)}</p>
                </div>
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">شهر</p>
                  <p className="mt-1 font-medium">{detail.city ?? '—'}</p>
                </div>
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">فروشگاه</p>
                  <p className="mt-1 font-medium truncate">{detail.shopName ?? '—'}</p>
                </div>
              </div>

              {/* Profile */}
              <div className="rounded-md border p-3 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">تخصص</span>
                  <span>{detail.specialty ?? '—'}</span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-muted-foreground shrink-0">آدرس</span>
                  <span className="text-left">{detail.address ?? '—'}</span>
                </div>
                {detail.notes ? (
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground shrink-0">یادداشت</span>
                    <span className="text-left">{detail.notes}</span>
                  </div>
                ) : null}
              </div>

              {/* Assigned orders */}
              <div className="rounded-md border">
                <div className="flex items-center gap-2 border-b p-3">
                  <Wrench className="h-4 w-4 text-muted-foreground" />
                  <p className="text-xs font-medium text-muted-foreground">سفارش‌های تخصیص‌یافته</p>
                </div>
                <div className="max-h-80 overflow-y-auto thin-scrollbar">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>سفارش</TableHead>
                        <TableHead>مشتری</TableHead>
                        <TableHead>وضعیت</TableHead>
                        <TableHead>پرداخت</TableHead>
                        <TableHead className="text-left">مبلغ</TableHead>
                        <TableHead>تاریخ</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detail.orders.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="py-6 text-center text-xs text-muted-foreground">
                            سفارشی تخصیص نیافته است
                          </TableCell>
                        </TableRow>
                      ) : (
                        detail.orders.map((o) => (
                          <TableRow key={o.id}>
                            <TableCell className="font-mono text-xs ltr-content" dir="ltr">
                              {o.orderNumber}
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="text-sm">{o.customer.name} {o.customer.family}</span>
                                <span className="text-xs text-muted-foreground ltr-content" dir="ltr">
                                  {o.customer.phone}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{ORDER_STATUS_LABEL[o.status] ?? o.status}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{PAYMENT_STATUS_LABEL[o.paymentStatus] ?? o.paymentStatus}</Badge>
                            </TableCell>
                            <TableCell className="text-left tabular-nums">{formatIrr(o.totalIrr)}</TableCell>
                            <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                              {faDateShort(o.createdAt)}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setDetailOpen(false)
                    openEdit(detail)
                  }}
                >
                  <Pencil className="ml-2 h-4 w-4" />
                  ویرایش
                </Button>
                <Button
                  onClick={() => toggleVerified(detail)}
                  disabled={togglingId === detail.id}
                >
                  {togglingId === detail.id ? (
                    <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  ) : detail.verified ? (
                    <ShieldAlert className="ml-2 h-4 w-4" />
                  ) : (
                    <ShieldCheck className="ml-2 h-4 w-4" />
                  )}
                  {detail.verified ? 'لغو تأیید' : 'تأیید هویت'}
                </Button>
              </DialogFooter>
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">مکانیک یافت نشد</div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
