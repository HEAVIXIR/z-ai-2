'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Plus,
  RefreshCw,
  Loader2,
  Pencil,
  Trash2,
  Tag,
  Factory,
  Car,
  ChevronLeft,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent } from '@/components/ui/card'

// ---------------- Types ----------------
interface CategoryNode {
  id: string
  name: string
  slug: string
  icon?: string | null
  parentId?: string | null
  partsCount: number
  childrenCount: number
  children?: CategoryNode[]
}
interface CategoriesResp {
  tree: CategoryNode[]
}
interface Brand {
  id: string
  name: string
  slug: string
  logoUrl?: string | null
  country?: string | null
  partsCount: number
  createdAt: string
}
interface BrandsResp {
  brands: Brand[]
}
interface CarModel {
  id: string
  brand: string
  model: string
  yearFrom: number
  yearTo: number
  partsCount: number
}
interface CarModelsResp {
  carModels: CarModel[]
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

// =================================================================
// Main page
// =================================================================
export default function CategoriesPage() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">دسته‌ها، برندها و خودروها</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            مدیریت دسته‌بندی محصولات، برندها و مدل‌های خودروی سازگار
          </p>
        </div>
      </div>

      <Tabs defaultValue="categories" className="w-full">
        <TabsList className="grid w-full grid-cols-3 sm:w-auto sm:grid-cols-3">
          <TabsTrigger value="categories" className="gap-2">
            <Tag className="h-4 w-4" /> دسته‌ها
          </TabsTrigger>
          <TabsTrigger value="brands" className="gap-2">
            <Factory className="h-4 w-4" /> برندها
          </TabsTrigger>
          <TabsTrigger value="cars" className="gap-2">
            <Car className="h-4 w-4" /> خودروها
          </TabsTrigger>
        </TabsList>
        <TabsContent value="categories">
          <CategoriesTab />
        </TabsContent>
        <TabsContent value="brands">
          <BrandsTab />
        </TabsContent>
        <TabsContent value="cars">
          <CarsTab />
        </TabsContent>
      </Tabs>
    </div>
  )
}

// =================================================================
// Categories tab — nested tree with add/edit/delete
// =================================================================
function CategoriesTab() {
  const [tree, setTree] = useState<CategoryNode[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState<{ id?: string; name: string; parentId: string; icon: string }>({
    name: '',
    parentId: '',
    icon: '',
  })
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleteName, setDeleteName] = useState('')
  const [deleteErr, setDeleteErr] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<CategoriesResp>('/api/admin/categories')
      setTree(d.tree || [])
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری دسته‌ها')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  function openCreate() {
    setForm({ name: '', parentId: '', icon: '' })
    setDialogOpen(true)
  }
  function openEdit(c: CategoryNode) {
    setForm({ id: c.id, name: c.name, parentId: c.parentId || '', icon: c.icon || '' })
    setDialogOpen(true)
  }

  async function save() {
    if (!form.name.trim()) {
      toast.error('نام دسته الزامی است')
      return
    }
    setSaving(true)
    try {
      const body = {
        name: form.name.trim(),
        parentId: form.parentId || null,
        icon: form.icon.trim() || null,
      }
      if (form.id) {
        await adminFetchJson(`/api/admin/categories/${form.id}`, {
          method: 'PUT',
          json: body,
        })
        toast.success('دسته بروزرسانی شد')
      } else {
        await adminFetchJson('/api/admin/categories', { method: 'POST', json: body })
        toast.success('دسته ایجاد شد')
      }
      setDialogOpen(false)
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره‌سازی')
    } finally {
      setSaving(false)
    }
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      const res = await adminFetch(`/api/admin/categories/${deleteId}`, {
        method: 'DELETE',
      })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error || `HTTP ${res.status}`)
      }
      toast.success('دسته حذف شد')
      setDeleteId(null)
      setDeleteErr('')
      load()
    } catch (err) {
      setDeleteErr((err as Error).message || 'خطا در حذف')
    }
  }

  return (
    <Card>
      <CardContent className="p-4 md:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold">دسته‌بندی محصولات</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={load} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              بروزرسانی
            </Button>
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> دسته جدید
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : tree.length === 0 ? (
          <EmptyState message="هنوز هیچ دسته‌ای ثبت نشده است" />
        ) : (
          <div className="rounded-lg border divide-y">
            {tree.map((c) => (
              <CategoryRow key={c.id} c={c} onEdit={openEdit} onDelete={(id, name) => {
                setDeleteId(id)
                setDeleteName(name)
                setDeleteErr('')
              }} />
            ))}
          </div>
        )}
      </CardContent>

      {/* Add/Edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id ? 'ویرایش دسته' : 'دسته جدید'}</DialogTitle>
            <DialogDescription>
              دسته‌ها حداکثر در ۲ سطح (دسته و زیردسته) سازماندهی می‌شوند.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="cat-name">نام دسته *</Label>
              <Input
                id="cat-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثلاً: ترمز، روغن موتور..."
              />
            </div>
            <div className="space-y-1.5">
              <Label>دسته والد</Label>
              <Select
                value={form.parentId || 'none'}
                onValueChange={(v) => setForm({ ...form, parentId: v === 'none' ? '' : v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="بدون والد (دسته اصلی)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— دسته اصلی —</SelectItem>
                  {tree.map((c) => (
                    <SelectItem key={c.id} value={c.id} disabled={form.id === c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cat-icon">آیکن (اختیاری)</Label>
              <Input
                id="cat-icon"
                value={form.icon}
                onChange={(e) => setForm({ ...form, icon: e.target.value })}
                placeholder="نام آیکن یا ایموجی (مثلاً: brake یا 🛞)"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} disabled={saving}>
              انصراف
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              ذخیره
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (!o) { setDeleteId(null); setDeleteErr('') } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف دسته</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteErr ? (
                <span className="text-rose-600 dark:text-rose-400 block mb-2">{deleteErr}</span>
              ) : null}
              آیا از حذف «{deleteName}» مطمئن هستید؟ این عملیات قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}

function CategoryRow({
  c,
  onEdit,
  onDelete,
  depth = 0,
}: {
  c: CategoryNode
  onEdit: (c: CategoryNode) => void
  onDelete: (id: string, name: string) => void
  depth?: number
}) {
  return (
    <>
      <div
        className="flex items-center gap-2 px-3 py-2.5 hover:bg-muted/40"
        style={{ paddingInlineStart: `${12 + depth * 24}px` }}
      >
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-50 text-violet-700 dark:bg-violet-950/30 dark:text-violet-300">
          <Tag className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium truncate">{c.name}</span>
            {c.icon ? (
              <Badge variant="outline" className="font-mono text-[10px]">
                {c.icon}
              </Badge>
            ) : null}
          </div>
          <div className="text-xs text-muted-foreground font-mono ltr text-left" dir="ltr">
            /{c.slug}
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2">
          <Badge variant="secondary" className="gap-1">
            {faNum(c.partsCount)} قطعه
          </Badge>
          {c.childrenCount > 0 ? (
            <Badge variant="outline" className="gap-1">
              {faNum(c.childrenCount)} زیردسته
            </Badge>
          ) : null}
        </div>
        <div className="flex items-center gap-1">
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => onEdit(c)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-rose-600 hover:text-rose-700"
            onClick={() => onDelete(c.id, c.name)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      {c.children?.map((ch) => (
        <CategoryRow key={ch.id} c={ch} onEdit={onEdit} onDelete={onDelete} depth={depth + 1} />
      ))}
    </>
  )
}

// =================================================================
// Brands tab — table
// =================================================================
function BrandsTab() {
  const [brands, setBrands] = useState<Brand[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState<{ id?: string; name: string; country: string; logoUrl: string }>({
    name: '',
    country: '',
    logoUrl: '',
  })
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleteName, setDeleteName] = useState('')
  const [deleteErr, setDeleteErr] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<BrandsResp>('/api/admin/brands')
      setBrands(d.brands || [])
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری برندها')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  function openCreate() {
    setForm({ name: '', country: '', logoUrl: '' })
    setDialogOpen(true)
  }
  function openEdit(b: Brand) {
    setForm({ id: b.id, name: b.name, country: b.country || '', logoUrl: b.logoUrl || '' })
    setDialogOpen(true)
  }

  async function save() {
    if (!form.name.trim()) {
      toast.error('نام برند الزامی است')
      return
    }
    setSaving(true)
    try {
      const body = {
        name: form.name.trim(),
        country: form.country.trim() || null,
        logoUrl: form.logoUrl.trim() || null,
      }
      if (form.id) {
        await adminFetchJson(`/api/admin/brands/${form.id}`, { method: 'PUT', json: body })
        toast.success('برند بروزرسانی شد')
      } else {
        await adminFetchJson('/api/admin/brands', { method: 'POST', json: body })
        toast.success('برند ایجاد شد')
      }
      setDialogOpen(false)
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره‌سازی')
    } finally {
      setSaving(false)
    }
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      const res = await adminFetch(`/api/admin/brands/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error || `HTTP ${res.status}`)
      }
      toast.success('برند حذف شد')
      setDeleteId(null)
      setDeleteErr('')
      load()
    } catch (err) {
      setDeleteErr((err as Error).message || 'خطا در حذف')
    }
  }

  return (
    <Card>
      <CardContent className="p-4 md:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold">برندها</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={load} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              بروزرسانی
            </Button>
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> برند جدید
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : brands.length === 0 ? (
          <EmptyState message="هنوز هیچ برندی ثبت نشده است" />
        ) : (
          <div className="rounded-lg border max-h-[70vh] overflow-y-auto thin-scrollbar">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>نام برند</TableHead>
                  <TableHead className="hidden md:table-cell">کشور</TableHead>
                  <TableHead className="text-center">قطعات</TableHead>
                  <TableHead className="text-left">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {brands.map((b) => (
                  <TableRow key={b.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300 font-bold uppercase">
                          {b.name.slice(0, 2)}
                        </div>
                        <div className="min-w-0">
                          <div className="font-medium truncate">{b.name}</div>
                          <div className="text-xs text-muted-foreground font-mono ltr text-left" dir="ltr">
                            /{b.slug}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {b.country ? <span>{b.country}</span> : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary">{faNum(b.partsCount)}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 justify-end">
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(b)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-rose-600 hover:text-rose-700"
                          onClick={() => {
                            setDeleteId(b.id)
                            setDeleteName(b.name)
                            setDeleteErr('')
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id ? 'ویرایش برند' : 'برند جدید'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="brand-name">نام برند *</Label>
              <Input
                id="brand-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثلاً: Bosch, Denso..."
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="brand-country">کشور</Label>
              <Input
                id="brand-country"
                value={form.country}
                onChange={(e) => setForm({ ...form, country: e.target.value })}
                placeholder="مثلاً: Germany, Japan..."
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="brand-logo">آدرس لوگو (اختیاری)</Label>
              <Input
                id="brand-logo"
                value={form.logoUrl}
                onChange={(e) => setForm({ ...form, logoUrl: e.target.value })}
                placeholder="https://..."
                dir="ltr"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} disabled={saving}>
              انصراف
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              ذخیره
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (!o) { setDeleteId(null); setDeleteErr('') } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف برند</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteErr ? (
                <span className="text-rose-600 dark:text-rose-400 block mb-2">{deleteErr}</span>
              ) : null}
              آیا از حذف برند «{deleteName}» مطمئن هستید؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}

// =================================================================
// Cars tab — table
// =================================================================
function CarsTab() {
  const [models, setModels] = useState<CarModel[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState<{
    id?: string
    brand: string
    model: string
    yearFrom: string
    yearTo: string
  }>({ brand: '', model: '', yearFrom: '', yearTo: '' })
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleteName, setDeleteName] = useState('')
  const [deleteErr, setDeleteErr] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<CarModelsResp>('/api/admin/car-models')
      setModels(d.carModels || [])
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری خودروها')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  function openCreate() {
    const year = new Date().getFullYear()
    setForm({ brand: '', model: '', yearFrom: String(year), yearTo: String(year) })
    setDialogOpen(true)
  }
  function openEdit(m: CarModel) {
    setForm({
      id: m.id,
      brand: m.brand,
      model: m.model,
      yearFrom: String(m.yearFrom),
      yearTo: String(m.yearTo),
    })
    setDialogOpen(true)
  }

  async function save() {
    if (!form.brand.trim() || !form.model.trim()) {
      toast.error('برند و مدل الزامی هستند')
      return
    }
    const yf = Number(form.yearFrom)
    const yt = Number(form.yearTo)
    if (!Number.isFinite(yf) || !Number.isFinite(yt) || yf > yt) {
      toast.error('سال شروع/پایان نامعتبر است')
      return
    }
    setSaving(true)
    try {
      const body = {
        brand: form.brand.trim(),
        model: form.model.trim(),
        yearFrom: yf,
        yearTo: yt,
      }
      if (form.id) {
        await adminFetchJson(`/api/admin/car-models/${form.id}`, { method: 'PUT', json: body })
        toast.success('مدل بروزرسانی شد')
      } else {
        await adminFetchJson('/api/admin/car-models', { method: 'POST', json: body })
        toast.success('مدل ایجاد شد')
      }
      setDialogOpen(false)
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره‌سازی')
    } finally {
      setSaving(false)
    }
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      const res = await adminFetch(`/api/admin/car-models/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error || `HTTP ${res.status}`)
      }
      toast.success('مدل خودرو حذف شد')
      setDeleteId(null)
      setDeleteErr('')
      load()
    } catch (err) {
      setDeleteErr((err as Error).message || 'خطا در حذف')
    }
  }

  return (
    <Card>
      <CardContent className="p-4 md:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold">مدل‌های خودرو</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={load} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              بروزرسانی
            </Button>
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> مدل خودرو جدید
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : models.length === 0 ? (
          <EmptyState message="هنوز هیچ مدل خودرویی ثبت نشده است" />
        ) : (
          <div className="rounded-lg border max-h-[70vh] overflow-y-auto thin-scrollbar">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>برند</TableHead>
                  <TableHead>مدل</TableHead>
                  <TableHead className="hidden md:table-cell">سال تولید</TableHead>
                  <TableHead className="text-center">قطعات</TableHead>
                  <TableHead className="text-left">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {models.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell className="font-medium">{m.brand}</TableCell>
                    <TableCell>{m.model}</TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">
                      <span dir="ltr">{faNum(m.yearFrom)} – {faNum(m.yearTo)}</span>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary">{faNum(m.partsCount)}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 justify-end">
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(m)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-rose-600 hover:text-rose-700"
                          onClick={() => {
                            setDeleteId(m.id)
                            setDeleteName(`${m.brand} ${m.model}`)
                            setDeleteErr('')
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id ? 'ویرایش مدل خودرو' : 'مدل خودرو جدید'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="car-brand">برند *</Label>
              <Input
                id="car-brand"
                value={form.brand}
                onChange={(e) => setForm({ ...form, brand: e.target.value })}
                placeholder="مثلاً: Toyota, Hyundai..."
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="car-model">مدل *</Label>
              <Input
                id="car-model"
                value={form.model}
                onChange={(e) => setForm({ ...form, model: e.target.value })}
                placeholder="مثلاً: Corolla, Elantra..."
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="car-yf">سال شروع *</Label>
                <Input
                  id="car-yf"
                  type="number"
                  value={form.yearFrom}
                  onChange={(e) => setForm({ ...form, yearFrom: e.target.value })}
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="car-yt">سال پایان *</Label>
                <Input
                  id="car-yt"
                  type="number"
                  value={form.yearTo}
                  onChange={(e) => setForm({ ...form, yearTo: e.target.value })}
                  dir="ltr"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} disabled={saving}>
              انصراف
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              ذخیره
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (!o) { setDeleteId(null); setDeleteErr('') } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف مدل خودرو</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteErr ? (
                <span className="text-rose-600 dark:text-rose-400 block mb-2">{deleteErr}</span>
              ) : null}
              آیا از حذف «{deleteName}» مطمئن هستید؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center gap-2 py-10 text-center text-muted-foreground">
      <ChevronLeft className="h-8 w-8 opacity-40" />
      <p className="text-sm">{message}</p>
    </div>
  )
}
