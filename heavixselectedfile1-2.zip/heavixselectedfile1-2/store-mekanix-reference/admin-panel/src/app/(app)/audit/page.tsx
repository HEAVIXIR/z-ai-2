'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  RefreshCw,
  Loader2,
  ScrollText,
  Search,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetchJson } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Card, CardContent } from '@/components/ui/card'

interface AuditLog {
  id: string
  adminId: string | null
  adminName: string
  adminUsername: string | null
  action: string
  entity: string
  entityId: string | null
  before: string | null
  after: string | null
  ipAddress: string | null
  createdAt: string
}
interface AuditResp {
  logs: AuditLog[]
  total: number
  page: number
  pageSize: number
}

const ACTIONS = [
  'CREATE',
  'UPDATE',
  'DELETE',
  'LOGIN',
  'LOGOUT',
  'APPROVE',
  'REJECT',
] as const
const ENTITIES = [
  'Part',
  'Category',
  'Brand',
  'CarModel',
  'Order',
  'Payment',
  'Customer',
  'Mechanic',
  'CurrencyRate',
  'CurrencySetting',
  'Setting',
  'Coupon',
  'Review',
  'AdminUser',
] as const

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

function faDateTime(s: string): string {
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(s))
  } catch {
    return s
  }
}

function actionVariant(action: string): {
  className: string
  label: string
} {
  const map: Record<string, { className: string; label: string }> = {
    CREATE: {
      className: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 hover:bg-emerald-100',
      label: 'ایجاد',
    },
    UPDATE: {
      className: 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 hover:bg-amber-100',
      label: 'ویرایش',
    },
    DELETE: {
      className: 'bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 hover:bg-rose-100',
      label: 'حذف',
    },
    LOGIN: {
      className: 'bg-violet-100 text-violet-700 dark:bg-violet-950/40 dark:text-violet-300 hover:bg-violet-100',
      label: 'ورود',
    },
    LOGOUT: {
      className: 'bg-slate-100 text-slate-700 dark:bg-slate-800/60 dark:text-slate-300 hover:bg-slate-100',
      label: 'خروج',
    },
    APPROVE: {
      className: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 hover:bg-emerald-100',
      label: 'تایید',
    },
    REJECT: {
      className: 'bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 hover:bg-rose-100',
      label: 'رد',
    },
  }
  return map[action] || { className: '', label: action }
}

function entityLabel(entity: string): string {
  const map: Record<string, string> = {
    Part: 'قطعه',
    Category: 'دسته',
    Brand: 'برند',
    CarModel: 'خودرو',
    Order: 'سفارش',
    Payment: 'پرداخت',
    Customer: 'مشتری',
    Mechanic: 'مکانیک',
    CurrencyRate: 'نرخ ارز',
    CurrencySetting: 'تنظیم ارز',
    Setting: 'تنظیمات',
    Coupon: 'کد تخفیف',
    Review: 'نظر',
    AdminUser: 'مدیر',
  }
  return map[entity] || entity
}

function truncateJson(s: string | null, max = 300): string {
  if (!s) return ''
  if (s.length <= max) return s
  return s.slice(0, max) + '…'
}

export default function AuditPage() {
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(50)
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [action, setAction] = useState<string>('all')
  const [entity, setEntity] = useState<string>('all')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: String(page),
        pageSize: String(pageSize),
      })
      if (q) params.set('q', q)
      if (action !== 'all') params.set('action', action)
      if (entity !== 'all') params.set('entity', entity)
      const d = await adminFetchJson<AuditResp>(`/api/admin/audit?${params.toString()}`)
      setLogs(d.logs || [])
      setTotal(d.total || 0)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری لاگ‌ها')
    } finally {
      setLoading(false)
    }
  }, [page, pageSize, q, action, entity])

  useEffect(() => {
    load()
  }, [load])

  const totalPages = Math.max(1, Math.ceil(total / pageSize))

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">لاگ رویدادها</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            تاریخچه کامل عملیات و تغییرات انجام‌شده توسط مدیران
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          بروزرسانی
        </Button>
      </div>

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => {
                  setQ(e.target.value)
                  setPage(1)
                }}
                placeholder="جستجو بر اساس نام مدیر..."
                className="pr-9"
              />
            </div>
            <Select
              value={action}
              onValueChange={(v) => {
                setAction(v)
                setPage(1)
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="همه عملیات‌ها" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه عملیات‌ها</SelectItem>
                {ACTIONS.map((a) => (
                  <SelectItem key={a} value={a}>
                    {actionVariant(a).label} ({a})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={entity}
              onValueChange={(v) => {
                setEntity(v)
                setPage(1)
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="همه موجودیت‌ها" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه موجودیت‌ها</SelectItem>
                {ENTITIES.map((e) => (
                  <SelectItem key={e} value={e}>
                    {entityLabel(e)} ({e})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : logs.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center text-muted-foreground">
              <ScrollText className="h-10 w-10 opacity-30" />
              <p className="text-sm">هیچ رویدادی یافت نشد</p>
            </div>
          ) : (
            <div className="rounded-lg border max-h-[70vh] overflow-y-auto thin-scrollbar">
              <Table>
                <TableHeader className="sticky top-0 bg-background z-10">
                  <TableRow>
                    <TableHead className="whitespace-nowrap">زمان</TableHead>
                    <TableHead>مدیر</TableHead>
                    <TableHead>عملیات</TableHead>
                    <TableHead className="hidden md:table-cell">موجیت</TableHead>
                    <TableHead className="hidden lg:table-cell">شناسه</TableHead>
                    <TableHead className="hidden md:table-cell">تغییرات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((l) => {
                    const v = actionVariant(l.action)
                    return (
                      <TableRow key={l.id}>
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                          {faDateTime(l.createdAt)}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm font-medium">{l.adminName}</span>
                            {l.adminUsername ? (
                              <span className="text-xs text-muted-foreground font-mono ltr" dir="ltr">
                                @{l.adminUsername}
                              </span>
                            ) : null}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={v.className}>{v.label}</Badge>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <div className="flex flex-col">
                            <span className="text-sm">{entityLabel(l.entity)}</span>
                            <span className="text-xs text-muted-foreground font-mono ltr" dir="ltr">
                              {l.entity}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          {l.entityId ? (
                            <code
                              className="text-xs text-muted-foreground font-mono ltr bg-muted px-1.5 py-0.5 rounded"
                              dir="ltr"
                              title={l.entityId}
                            >
                              {l.entityId.slice(-8)}
                            </code>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {l.after ? (
                            <pre
                              className="text-[10px] leading-tight max-w-md max-h-20 overflow-auto thin-scrollbar bg-muted/60 dark:bg-muted/30 rounded p-2 font-mono ltr"
                              dir="ltr"
                            >
                              {truncateJson(l.after)}
                            </pre>
                          ) : l.before ? (
                            <pre
                              className="text-[10px] leading-tight max-w-md max-h-20 overflow-auto thin-scrollbar bg-muted/60 dark:bg-muted/30 rounded p-2 font-mono ltr text-muted-foreground"
                              dir="ltr"
                            >
                              {truncateJson(l.before)}
                            </pre>
                          ) : (
                            <span className="text-muted-foreground text-xs">—</span>
                          )}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Pagination */}
          {!loading && total > 0 ? (
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <p className="text-xs text-muted-foreground">
                {faNum((page - 1) * pageSize + 1)} تا{' '}
                {faNum(Math.min(page * pageSize, total))} از {faNum(total)}
              </p>
              <div className="flex items-center gap-1">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page <= 1}
                >
                  <ChevronRight className="h-4 w-4" /> قبلی
                </Button>
                <span className="text-xs text-muted-foreground px-2 tabular-nums">
                  {faNum(page)} / {faNum(totalPages)}
                </span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  disabled={page >= totalPages}
                >
                  بعدی <ChevronLeft className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>
    </div>
  )
}
