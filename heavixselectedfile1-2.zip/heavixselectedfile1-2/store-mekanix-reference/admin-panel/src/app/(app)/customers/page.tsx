'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Search,
  RefreshCw,
  Loader2,
  Eye,
  Wallet,
  ChevronLeft,
  ChevronRight,
  ShoppingCart,
  Receipt,
  Heart,
  Save,
  PlusCircle,
  MinusCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { formatIrr, formatUsd } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Card,
  CardContent,
} from '@/components/ui/card'

const CUSTOMER_STATUS_LABEL: Record<string, string> = {
  ACTIVE: 'فعال',
  BLOCKED: 'مسدود',
}
const CUSTOMER_STATUS_BADGE: Record<string, string> = {
  ACTIVE: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  BLOCKED: 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200',
}
const ORDER_STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  CONFIRMED: 'تایید شده',
  PROCESSING: 'در حال پردازش',
  SHIPPED: 'ارسال شده',
  DELIVERED: 'تحویل شده',
  CANCELLED: 'لغو شده',
}
const PAYMENT_STATUS_LABEL: Record<string, string> = {
  UNPAID: 'پرداخت‌نشده',
  PENDING: 'در انتظار',
  PAID: 'پرداخت شده',
  REFUNDED: 'بازگشت',
}
const PAYMENT_STATUS_BADGE: Record<string, string> = {
  UNPAID: 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200',
  PENDING: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  PAID: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  REFUNDED: 'bg-slate-100 text-slate-700 dark:bg-slate-800/40 dark:text-slate-200',
}
const WALLET_TYPE_LABEL: Record<string, string> = {
  CREDIT: 'افزایش',
  DEBIT: 'کاهش',
  ORDER: 'سفارش',
  DEPOSIT: 'شارژ',
}

interface CustomerListItem {
  id: string
  phone: string
  name: string
  family: string
  nationalCode?: string | null
  address?: string | null
  status: string
  totalOrders: number
  totalSpentIrr: number
  walletBalanceIrr: number
  notes?: string | null
  createdAt: string
  _count: {
    orders: number
    payments: number
    wishlists: number
    reviews: number
  }
}

interface OrderRef {
  id: string
  orderNumber: string
  status: string
  paymentStatus: string
  totalIrr: number
  totalUsd: number
  createdAt: string
}
interface PaymentRef {
  id: string
  status: string
  method: string
  amountIrr: number
  amountUsd: number
  referenceCode?: string | null
  gateway?: string | null
  refId?: string | null
  createdAt: string
  reviewedAt?: string | null
}
interface WalletTxn {
  id: string
  amount: number
  type: string
  description?: string | null
  createdAt: string
}
interface CustomerDetail {
  id: string
  phone: string
  name: string
  family: string
  nationalCode?: string | null
  address?: string | null
  status: string
  totalOrders: number
  totalSpentIrr: number
  walletBalanceIrr: number
  notes?: string | null
  createdAt: string
  orders: OrderRef[]
  payments: PaymentRef[]
  walletTxns: WalletTxn[]
  _count: { wishlists: number; reviews: number }
}

interface CustomersListResp {
  customers: CustomerListItem[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}

function faDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString('fa-IR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return iso
  }
}
function faDateShort(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('fa-IR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
  } catch {
    return iso
  }
}
function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<CustomerListItem[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [totalPages, setTotalPages] = useState(1)
  const [q, setQ] = useState('')
  const [fStatus, setFStatus] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [refreshKey, setRefreshKey] = useState(0)

  const [detail, setDetail] = useState<CustomerDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)

  // Editable fields
  const [edName, setEdName] = useState('')
  const [edFamily, setEdFamily] = useState('')
  const [edNationalCode, setEdNationalCode] = useState('')
  const [edAddress, setEdAddress] = useState('')
  const [edNotes, setEdNotes] = useState('')
  const [edStatus, setEdStatus] = useState<'ACTIVE' | 'BLOCKED'>('ACTIVE')
  const [savingProfile, setSavingProfile] = useState(false)

  // Wallet form
  const [wAmount, setWAmount] = useState('')
  const [wType, setWType] = useState<'CREDIT' | 'DEBIT'>('CREDIT')
  const [wDescription, setWDescription] = useState('')
  const [savingWallet, setSavingWallet] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set('q', q)
      if (fStatus) params.set('status', fStatus)
      params.set('page', String(page))
      params.set('pageSize', String(pageSize))
      const d = await adminFetchJson<CustomersListResp>(
        `/api/admin/customers?${params.toString()}`,
      )
      setCustomers(d.customers)
      setTotal(d.total)
      setTotalPages(d.totalPages)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری مشتریان')
    } finally {
      setLoading(false)
    }
  }, [q, fStatus, page, pageSize])

  useEffect(() => {
    void load()
  }, [load, refreshKey])

  const openDetail = useCallback(async (c: CustomerListItem) => {
    setDetailOpen(true)
    setDetail(null)
    setDetailLoading(true)
    setWAmount('')
    setWType('CREDIT')
    setWDescription('')
    try {
      const d = await adminFetchJson<CustomerDetail>(`/api/admin/customers/${c.id}`)
      setDetail(d)
      setEdName(d.name)
      setEdFamily(d.family)
      setEdNationalCode(d.nationalCode ?? '')
      setEdAddress(d.address ?? '')
      setEdNotes(d.notes ?? '')
      setEdStatus((d.status as 'ACTIVE' | 'BLOCKED') ?? 'ACTIVE')
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری جزئیات')
      setDetailOpen(false)
    } finally {
      setDetailLoading(false)
    }
  }, [])

  const saveProfile = useCallback(async () => {
    if (!detail) return
    setSavingProfile(true)
    try {
      const body = {
        name: edName,
        family: edFamily,
        nationalCode: edNationalCode || null,
        address: edAddress || null,
        notes: edNotes || null,
        status: edStatus,
      }
      const d = await adminFetchJson<{ ok: boolean; customer: Partial<CustomerDetail> }>(
        `/api/admin/customers/${detail.id}`,
        { method: 'PATCH', json: body },
      )
      toast.success('پروفایل مشتری بروزرسانی شد')
      setDetail((prev) => (prev ? { ...prev, ...d.customer } as CustomerDetail : prev))
      setRefreshKey((k) => k + 1)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره')
    } finally {
      setSavingProfile(false)
    }
  }, [detail, edName, edFamily, edNationalCode, edAddress, edNotes, edStatus])

  const submitWallet = useCallback(async () => {
    if (!detail) return
    const amount = Number(wAmount)
    if (!Number.isFinite(amount) || amount <= 0) {
      toast.error('مبلغ باید عددی مثبت باشد')
      return
    }
    setSavingWallet(true)
    try {
      const d = await adminFetchJson<{ ok: boolean; walletBalanceIrr: number; transaction: WalletTxn }>(
        `/api/admin/customers/${detail.id}/wallet`,
        { method: 'POST', json: { amount, type: wType, description: wDescription || null } },
      )
      toast.success(wType === 'CREDIT' ? 'موجودی کیف پول افزایش یافت' : 'موجودی کیف پول کاهش یافت')
      setDetail((prev) =>
        prev
          ? {
              ...prev,
              walletBalanceIrr: d.walletBalanceIrr,
              walletTxns: [d.transaction, ...prev.walletTxns],
            }
          : prev,
      )
      setWAmount('')
      setWDescription('')
      setRefreshKey((k) => k + 1)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ثبت تراکنش کیف پول')
    } finally {
      setSavingWallet(false)
    }
  }, [detail, wAmount, wType, wDescription])

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">مشتریان</h1>
          <p className="text-sm text-muted-foreground">
            مدیریت حساب کاربران، کیف پول و سوابق سفارش
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setRefreshKey((k) => k + 1)}>
          <RefreshCw className="ml-2 h-4 w-4" />
          بروزرسانی
        </Button>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="relative sm:col-span-2">
              <Search className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => {
                  setQ(e.target.value)
                  setPage(1)
                }}
                placeholder="موبایل، نام، نام خانوادگی یا کد ملی..."
                className="pr-9"
              />
            </div>
            <Select
              value={fStatus}
              onValueChange={(v) => {
                setFStatus(v === '__all__' ? '' : v)
                setPage(1)
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="وضعیت مشتری" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه</SelectItem>
                {Object.entries(CUSTOMER_STATUS_LABEL).map(([k, v]) => (
                  <SelectItem key={k} value={k}>
                    {v}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto thin-scrollbar">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>نام</TableHead>
                  <TableHead>موبایل</TableHead>
                  <TableHead>کد ملی</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead className="text-center">سفارش</TableHead>
                  <TableHead>مجموع خرید</TableHead>
                  <TableHead>موجودی کیف پول</TableHead>
                  <TableHead>تاریخ عضویت</TableHead>
                  <TableHead className="text-left">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={`sk-${i}`}>
                      <TableCell colSpan={9}>
                        <Skeleton className="h-6 w-full" />
                      </TableCell>
                    </TableRow>
                  ))
                ) : customers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="py-12 text-center text-muted-foreground">
                      <Wallet className="mx-auto mb-2 h-8 w-8 opacity-50" />
                      مشتری‌ای یافت نشد
                    </TableCell>
                  </TableRow>
                ) : (
                  customers.map((c) => (
                    <TableRow key={c.id} className="cursor-pointer hover:bg-muted/50" onClick={() => openDetail(c)}>
                      <TableCell>
                        <span className="font-medium">
                          {c.name} {c.family}
                        </span>
                      </TableCell>
                      <TableCell className="ltr-content" dir="ltr">
                        {c.phone}
                      </TableCell>
                      <TableCell className="ltr-content text-sm" dir="ltr">
                        {c.nationalCode ?? '—'}
                      </TableCell>
                      <TableCell>
                        <Badge className={CUSTOMER_STATUS_BADGE[c.status] ?? ''} variant="outline">
                          {CUSTOMER_STATUS_LABEL[c.status] ?? c.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center tabular-nums">
                        {faNum(c._count.orders)}
                      </TableCell>
                      <TableCell className="tabular-nums">{formatIrr(c.totalSpentIrr)}</TableCell>
                      <TableCell className="tabular-nums font-medium text-violet-700 dark:text-violet-300">
                        {formatIrr(c.walletBalanceIrr)}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        {faDateShort(c.createdAt)}
                      </TableCell>
                      <TableCell className="text-left">
                        <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); openDetail(c) }}>
                          <Eye className="ml-1 h-4 w-4" />
                          مشاهده
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 ? (
            <div className="flex items-center justify-between border-t p-3">
              <span className="text-xs text-muted-foreground">
                صفحه {faNum(page)} از {faNum(totalPages)}
              </span>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  <ChevronRight className="h-4 w-4" />
                  قبلی
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                >
                  بعدی
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {/* Detail dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[92vh] overflow-y-auto thin-scrollbar">
          {detailLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : detail ? (
            <div className="space-y-5">
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2">
                  <span>{detail.name} {detail.family}</span>
                  <Badge className={CUSTOMER_STATUS_BADGE[detail.status] ?? ''} variant="outline">
                    {CUSTOMER_STATUS_LABEL[detail.status] ?? detail.status}
                  </Badge>
                </DialogTitle>
                <DialogDescription>
                  <span className="ltr-content" dir="ltr">{detail.phone}</span>
                  {' · '}
                  عضو از {faDateShort(detail.createdAt)}
                </DialogDescription>
              </DialogHeader>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">مجموع خرید</p>
                  <p className="mt-1 font-semibold tabular-nums">{formatIrr(detail.totalSpentIrr)}</p>
                </div>
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">موجودی کیف پول</p>
                  <p className="mt-1 font-semibold tabular-nums text-violet-700 dark:text-violet-300">
                    {formatIrr(detail.walletBalanceIrr)}
                  </p>
                </div>
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">سفارش‌ها</p>
                  <p className="mt-1 font-semibold tabular-nums">{faNum(detail.orders.length)}</p>
                </div>
                <div className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">علاقه‌مندی‌ها</p>
                  <p className="mt-1 font-semibold tabular-nums">{faNum(detail._count.wishlists)}</p>
                </div>
              </div>

              {/* Profile editor */}
              <div className="rounded-md border p-3 space-y-3">
                <p className="text-xs font-medium text-muted-foreground">پروفایل</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">نام</Label>
                    <Input value={edName} onChange={(e) => setEdName(e.target.value)} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs">نام خانوادگی</Label>
                    <Input value={edFamily} onChange={(e) => setEdFamily(e.target.value)} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs">کد ملی</Label>
                    <Input
                      value={edNationalCode}
                      onChange={(e) => setEdNationalCode(e.target.value)}
                      className="mt-1 ltr-content"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">موبایل</Label>
                    <Input value={detail.phone} disabled className="mt-1 ltr-content opacity-70" dir="ltr" />
                  </div>
                  <div className="sm:col-span-2">
                    <Label className="text-xs">آدرس</Label>
                    <Textarea
                      value={edAddress}
                      onChange={(e) => setEdAddress(e.target.value)}
                      className="mt-1 min-h-[60px]"
                      placeholder="آدرس پستی مشتری..."
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Label className="text-xs">یادداشت داخلی</Label>
                    <Textarea
                      value={edNotes}
                      onChange={(e) => setEdNotes(e.target.value)}
                      className="mt-1 min-h-[60px]"
                      placeholder="یادداشت‌های داخلی..."
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between rounded border p-2">
                  <div>
                    <p className="text-sm font-medium">وضعیت حساب</p>
                    <p className="text-xs text-muted-foreground">
                      {edStatus === 'BLOCKED' ? 'مشتری مسدود می‌شود' : 'مشتری فعال است'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs">{edStatus === 'ACTIVE' ? 'فعال' : 'مسدود'}</span>
                    <Switch
                      checked={edStatus === 'ACTIVE'}
                      onCheckedChange={(checked) => setEdStatus(checked ? 'ACTIVE' : 'BLOCKED')}
                    />
                  </div>
                </div>
                <Button size="sm" disabled={savingProfile} onClick={saveProfile}>
                  {savingProfile ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
                  ذخیره پروفایل
                </Button>
              </div>

              {/* Wallet adjustment */}
              <div className="rounded-md border p-3 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium text-muted-foreground">مدیریت کیف پول</p>
                  <Badge variant="outline" className="bg-violet-100 text-violet-800 dark:bg-violet-900/40 dark:text-violet-200">
                    موجودی: <span className="tabular-nums ltr-content ml-1" dir="ltr">{faNum(detail.walletBalanceIrr)}</span> تومان
                  </Badge>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <Label className="text-xs">مبلغ (تومان)</Label>
                    <Input
                      value={wAmount}
                      onChange={(e) => setWAmount(e.target.value)}
                      placeholder="مثال: 100000"
                      className="mt-1 ltr-content"
                      dir="ltr"
                      inputMode="numeric"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">نوع تراکنش</Label>
                    <Select value={wType} onValueChange={(v) => setWType(v as 'CREDIT' | 'DEBIT')}>
                      <SelectTrigger className="mt-1 w-full">
                        <SelectValue placeholder="نوع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CREDIT">افزایش موجودی (CREDIT)</SelectItem>
                        <SelectItem value="DEBIT">کاهش موجودی (DEBIT)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">توضیحات</Label>
                    <Input
                      value={wDescription}
                      onChange={(e) => setWDescription(e.target.value)}
                      placeholder="اختیاری"
                      className="mt-1"
                    />
                  </div>
                </div>
                <Button size="sm" variant="secondary" disabled={savingWallet} onClick={submitWallet}>
                  {savingWallet ? (
                    <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  ) : wType === 'CREDIT' ? (
                    <PlusCircle className="ml-2 h-4 w-4" />
                  ) : (
                    <MinusCircle className="ml-2 h-4 w-4" />
                  )}
                  ثبت تراکنش
                </Button>
              </div>

              {/* Orders */}
              <div className="rounded-md border">
                <div className="flex items-center gap-2 border-b p-3">
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                  <p className="text-xs font-medium text-muted-foreground">سفارش‌های اخیر</p>
                </div>
                <div className="max-h-72 overflow-y-auto thin-scrollbar">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>سفارش</TableHead>
                        <TableHead>وضعیت</TableHead>
                        <TableHead>پرداخت</TableHead>
                        <TableHead className="text-left">مبلغ</TableHead>
                        <TableHead>تاریخ</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detail.orders.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="py-6 text-center text-xs text-muted-foreground">
                            سفارشی ثبت نشده است
                          </TableCell>
                        </TableRow>
                      ) : (
                        detail.orders.map((o) => (
                          <TableRow key={o.id}>
                            <TableCell className="font-mono text-xs ltr-content" dir="ltr">
                              {o.orderNumber}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{ORDER_STATUS_LABEL[o.status] ?? o.status}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={PAYMENT_STATUS_BADGE[o.paymentStatus] ?? ''}>
                                {PAYMENT_STATUS_LABEL[o.paymentStatus] ?? o.paymentStatus}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-left tabular-nums">{formatIrr(o.totalIrr)}</TableCell>
                            <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                              {faDateShort(o.createdAt)}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Payments */}
              <div className="rounded-md border">
                <div className="flex items-center gap-2 border-b p-3">
                  <Receipt className="h-4 w-4 text-muted-foreground" />
                  <p className="text-xs font-medium text-muted-foreground">پرداخت‌های اخیر</p>
                </div>
                <div className="max-h-72 overflow-y-auto thin-scrollbar">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>وضعیت</TableHead>
                        <TableHead>روش</TableHead>
                        <TableHead>کد پیگیری</TableHead>
                        <TableHead className="text-left">مبلغ</TableHead>
                        <TableHead>تاریخ</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detail.payments.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="py-6 text-center text-xs text-muted-foreground">
                            پرداختی ثبت نشده است
                          </TableCell>
                        </TableRow>
                      ) : (
                        detail.payments.map((p) => (
                          <TableRow key={p.id}>
                            <TableCell>
                              <Badge variant="outline" className={PAYMENT_STATUS_BADGE[p.status] ?? ''}>
                                {PAYMENT_STATUS_LABEL[p.status] ?? p.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs">
                              {p.method === 'GATEWAY'
                                ? `درگاه${p.gateway ? ` · ${p.gateway}` : ''}`
                                : p.method === 'CARD'
                                  ? 'کارت'
                                  : p.method === 'WALLET'
                                    ? 'کیف پول'
                                    : p.method === 'CASH'
                                      ? 'نقدی'
                                      : p.method}
                            </TableCell>
                            <TableCell className="font-mono text-xs ltr-content" dir="ltr">
                              {p.referenceCode ?? p.refId ?? '—'}
                            </TableCell>
                            <TableCell className="text-left tabular-nums">{formatIrr(p.amountIrr)}</TableCell>
                            <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                              {faDateShort(p.createdAt)}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Wallet transactions */}
              <div className="rounded-md border">
                <div className="flex items-center gap-2 border-b p-3">
                  <Wallet className="h-4 w-4 text-muted-foreground" />
                  <p className="text-xs font-medium text-muted-foreground">تراکنش‌های کیف پول</p>
                </div>
                <div className="max-h-72 overflow-y-auto thin-scrollbar">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>نوع</TableHead>
                        <TableHead className="text-left">مبلغ</TableHead>
                        <TableHead>توضیحات</TableHead>
                        <TableHead>تاریخ</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detail.walletTxns.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="py-6 text-center text-xs text-muted-foreground">
                            <Heart className="mx-auto mb-2 h-6 w-6 opacity-40" />
                            تراکنشی ثبت نشده است
                          </TableCell>
                        </TableRow>
                      ) : (
                        detail.walletTxns.map((t) => (
                          <TableRow key={t.id}>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={
                                  t.amount >= 0
                                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200'
                                    : 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200'
                                }
                              >
                                {WALLET_TYPE_LABEL[t.type] ?? t.type}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-left tabular-nums">
                              <span className={t.amount >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'}>
                                {t.amount >= 0 ? '+' : '−'}
                                {formatIrr(Math.abs(t.amount))}
                              </span>
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground">{t.description ?? '—'}</TableCell>
                            <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                              {faDateShort(t.createdAt)}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">مشتری یافت نشد</div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
