'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  RefreshCw,
  Loader2,
  Save,
  Store,
  Phone,
  MapPin,
  DollarSign,
  Truck,
  Instagram,
  Send,
  MessageCircle,
  Database,
  Package,
  Users,
  Wrench,
  ShoppingCart,
  CreditCard,
  ScrollText,
  UserCog,
  Ticket,
  Star,
  ArrowLeft,
} from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'
import { adminFetchJson } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface Stats {
  parts: number
  customers: number
  mechanics: number
  orders: number
  payments: number
  auditLogs: number
  adminUsers: number
  coupons: number
  reviews: number
}
interface SettingsResp {
  settings: Record<string, string>
  stats: Stats
}

const KNOWN_KEYS = [
  'shopName',
  'shopPhone',
  'shopAddress',
  'shippingFlatFeeUsd',
  'minOrderUsd',
  'socialInstagram',
  'socialTelegram',
  'socialWhatsapp',
] as const

type FormState = Record<(typeof KNOWN_KEYS)[number], string>

const EMPTY_FORM: FormState = {
  shopName: '',
  shopPhone: '',
  shopAddress: '',
  shippingFlatFeeUsd: '',
  minOrderUsd: '',
  socialInstagram: '',
  socialTelegram: '',
  socialWhatsapp: '',
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Record<string, string>>({})
  const [stats, setStats] = useState<Stats | null>(null)
  const [form, setForm] = useState<FormState>(EMPTY_FORM)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<SettingsResp>('/api/admin/settings')
      setSettings(d.settings || {})
      setStats(d.stats || null)
      const next: FormState = { ...EMPTY_FORM }
      for (const k of KNOWN_KEYS) {
        if (d.settings[k] != null) next[k] = d.settings[k]
      }
      setForm(next)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری تنظیمات')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function save() {
    setSaving(true)
    try {
      // Only send changed fields to keep the audit log clean
      const diff: Record<string, string> = {}
      for (const k of KNOWN_KEYS) {
        const before = settings[k] ?? ''
        const after = form[k] ?? ''
        if (before !== after) diff[k] = after
      }
      if (Object.keys(diff).length === 0) {
        toast.info('تغییری برای ذخیره وجود ندارد')
        return
      }
      await adminFetchJson('/api/admin/settings', { method: 'PUT', json: diff })
      toast.success('تنظیمات ذخیره شد')
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره‌سازی')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">تنظیمات فروشگاه</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            پیکربندی اطلاعات فروشگاه، ارسال و شبکه‌های اجتماعی
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            بروزرسانی
          </Button>
          <Button size="sm" onClick={save} disabled={saving || loading}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            ذخیره تغییرات
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main form (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Store className="h-4 w-4 text-emerald-600" /> اطلاعات فروشگاه
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {loading ? (
                <>
                  <Skeleton className="h-9 w-full" />
                  <Skeleton className="h-9 w-full" />
                  <Skeleton className="h-20 w-full" />
                </>
              ) : (
                <>
                  <div className="space-y-1.5">
                    <Label htmlFor="shopName">نام فروشگاه</Label>
                    <Input
                      id="shopName"
                      value={form.shopName}
                      onChange={(e) => setForm({ ...form, shopName: e.target.value })}
                      placeholder="بازار قطعات خودرو"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="shopPhone" className="flex items-center gap-1.5">
                      <Phone className="h-3.5 w-3.5" /> تلفن تماس
                    </Label>
                    <Input
                      id="shopPhone"
                      value={form.shopPhone}
                      onChange={(e) => setForm({ ...form, shopPhone: e.target.value })}
                      placeholder="021-12345678"
                      dir="ltr"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="shopAddress" className="flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5" /> آدرس
                    </Label>
                    <Textarea
                      id="shopAddress"
                      value={form.shopAddress}
                      onChange={(e) => setForm({ ...form, shopAddress: e.target.value })}
                      placeholder="تهران، خیابان ولیعصر، پلاک ۱۲۳"
                      rows={3}
                    />
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Truck className="h-4 w-4 text-amber-600" /> هزینه ارسال و حداقل سفارش
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {loading ? (
                <>
                  <Skeleton className="h-9 w-full" />
                  <Skeleton className="h-9 w-full" />
                </>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="shippingFlatFeeUsd" className="flex items-center gap-1.5">
                      <DollarSign className="h-3.5 w-3.5" /> هزینه ثابت ارسال (دلار)
                    </Label>
                    <Input
                      id="shippingFlatFeeUsd"
                      type="number"
                      step="0.5"
                      value={form.shippingFlatFeeUsd}
                      onChange={(e) => setForm({ ...form, shippingFlatFeeUsd: e.target.value })}
                      placeholder="2"
                      dir="ltr"
                    />
                    <p className="text-xs text-muted-foreground">
                      هزینه ارسال با نرخ روز محاسبه می‌شود
                    </p>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="minOrderUsd" className="flex items-center gap-1.5">
                      <DollarSign className="h-3.5 w-3.5" /> حداقل مبلغ سفارش (دلار)
                    </Label>
                    <Input
                      id="minOrderUsd"
                      type="number"
                      step="0.5"
                      value={form.minOrderUsd}
                      onChange={(e) => setForm({ ...form, minOrderUsd: e.target.value })}
                      placeholder="0 = بدون حداقل"
                      dir="ltr"
                    />
                    <p className="text-xs text-muted-foreground">
                      سفارش‌های کمتر از این مبلغ قابل ثبت نیستند
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <MessageCircle className="h-4 w-4 text-violet-600" /> شبکه‌های اجتماعی
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {loading ? (
                <>
                  <Skeleton className="h-9 w-full" />
                  <Skeleton className="h-9 w-full" />
                  <Skeleton className="h-9 w-full" />
                </>
              ) : (
                <>
                  <div className="space-y-1.5">
                    <Label htmlFor="socialInstagram" className="flex items-center gap-1.5">
                      <Instagram className="h-3.5 w-3.5" /> اینستاگرام
                    </Label>
                    <Input
                      id="socialInstagram"
                      value={form.socialInstagram}
                      onChange={(e) => setForm({ ...form, socialInstagram: e.target.value })}
                      placeholder="@shop یا https://instagram.com/shop"
                      dir="ltr"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="socialTelegram" className="flex items-center gap-1.5">
                      <Send className="h-3.5 w-3.5" /> تلگرام
                    </Label>
                    <Input
                      id="socialTelegram"
                      value={form.socialTelegram}
                      onChange={(e) => setForm({ ...form, socialTelegram: e.target.value })}
                      placeholder="@shop یا https://t.me/shop"
                      dir="ltr"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="socialWhatsapp" className="flex items-center gap-1.5">
                      <MessageCircle className="h-3.5 w-3.5" /> واتساپ
                    </Label>
                    <Input
                      id="socialWhatsapp"
                      value={form.socialWhatsapp}
                      onChange={(e) => setForm({ ...form, socialWhatsapp: e.target.value })}
                      placeholder="989123456789"
                      dir="ltr"
                    />
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar (1 col) */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <DollarSign className="h-4 w-4 text-cyan-600" /> نرخ ارز
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                برای تنظیم نرخ لحظه‌ای دلار به تومان و حاشیه سود، به صفحه نرخ ارز مراجعه کنید.
              </p>
              <Button asChild variant="outline" size="sm" className="mt-3">
                <Link href="/currency">
                  مدیریت نرخ ارز
                  <ArrowLeft className="h-4 w-4 ms-1" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Database className="h-4 w-4 text-slate-600" /> نمای دیتابیس
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading || !stats ? (
                <div className="space-y-2">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  <StatTile icon={Package} label="قطعات" value={faNum(stats.parts)} accent="emerald" />
                  <StatTile icon={Users} label="مشتریان" value={faNum(stats.customers)} accent="cyan" />
                  <StatTile icon={Wrench} label="مکانیک‌ها" value={faNum(stats.mechanics)} accent="amber" />
                  <StatTile icon={ShoppingCart} label="سفارش‌ها" value={faNum(stats.orders)} accent="violet" />
                  <StatTile icon={CreditCard} label="پرداخت‌ها" value={faNum(stats.payments)} accent="rose" />
                  <StatTile icon={Ticket} label="کدهای تخفیف" value={faNum(stats.coupons)} accent="slate" />
                  <StatTile icon={Star} label="نظرات" value={faNum(stats.reviews)} accent="amber" />
                  <StatTile icon={UserCog} label="مدیران" value={faNum(stats.adminUsers)} accent="violet" />
                  <StatTile icon={ScrollText} label="رویدادهای لاگ" value={faNum(stats.auditLogs)} accent="slate" />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function StatTile({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  accent: 'emerald' | 'amber' | 'rose' | 'violet' | 'cyan' | 'slate'
}) {
  const ACCENTS: Record<string, string> = {
    emerald: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30',
    amber: 'text-amber-600 bg-amber-50 dark:bg-amber-950/30',
    rose: 'text-rose-600 bg-rose-50 dark:bg-rose-950/30',
    violet: 'text-violet-600 bg-violet-50 dark:bg-violet-950/30',
    cyan: 'text-cyan-600 bg-cyan-50 dark:bg-cyan-950/30',
    slate: 'text-slate-600 bg-slate-100 dark:bg-slate-800/40',
  }
  return (
    <div className="flex items-center justify-between gap-2 rounded-lg border p-2.5">
      <div className="flex items-center gap-2.5">
        <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${ACCENTS[accent]}`}>
          <Icon className="h-4 w-4" />
        </div>
        <span className="text-sm text-muted-foreground">{label}</span>
      </div>
      <span className="font-bold tabular-nums">{value}</span>
    </div>
  )
}
