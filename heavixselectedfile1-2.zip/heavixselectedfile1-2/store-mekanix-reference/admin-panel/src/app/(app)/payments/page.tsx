'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Search,
  RefreshCw,
  Loader2,
  Eye,
  CheckCircle2,
  XCircle,
  CreditCard,
  Wallet,
  Banknote,
  Globe,
  PartyPopper,
  ExternalLink,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { formatIrr, formatUsd } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Card,
  CardContent,
} from '@/components/ui/card'

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  APPROVED: 'تایید شده',
  REJECTED: 'رد شده',
  REFUNDED: 'بازگشت',
}
const STATUS_BADGE: Record<string, string> = {
  PENDING: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  APPROVED: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  REJECTED: 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200',
  REFUNDED: 'bg-slate-100 text-slate-700 dark:bg-slate-800/40 dark:text-slate-200',
}
const METHOD_LABEL: Record<string, string> = {
  CARD: 'کارت',
  WALLET: 'کیف پول',
  CASH: 'نقدی',
  GATEWAY: 'درگاه آنلاین',
}
const METHOD_BADGE: Record<string, string> = {
  CARD: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-200',
  WALLET: 'bg-violet-100 text-violet-800 dark:bg-violet-900/40 dark:text-violet-200',
  CASH: 'bg-slate-100 text-slate-700 dark:bg-slate-800/40 dark:text-slate-200',
  GATEWAY: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
}

function methodIcon(method: string) {
  if (method === 'GATEWAY') return Globe
  if (method === 'WALLET') return Wallet
  if (method === 'CASH') return Banknote
  return CreditCard
}

interface OrderRef {
  id: string
  orderNumber: string
  totalIrr: number
  totalUsd: number
  status: string
}
interface CustomerRef {
  id: string
  name: string
  family: string
  phone: string
}
interface PaymentListItem {
  id: string
  status: string
  method: string
  amountIrr: number
  amountUsd: number
  receiptImageUrl?: string | null
  referenceCode?: string | null
  payerName?: string | null
  payerCard?: string | null
  gateway?: string | null
  authority?: string | null
  refId?: string | null
  gatewayUrl?: string | null
  note?: string | null
  reviewedAt?: string | null
  createdAt: string
  orderId: string
  customerId: string
  order: OrderRef
  customer: CustomerRef
  reviewedBy?: { id: string; name: string } | null
}

interface PaymentDetail extends PaymentListItem {
  order: OrderRef & {
    shippingAddress?: string | null
    notes?: string | null
    couponCode?: string | null
    currencyRateAtOrder: number
    marginPercentAtOrder: number
    subtotalUsd: number
    shippingUsd: number
    discountIrr: number
    items: Array<{
      id: string
      partNameSnapshot: string
      quantity: number
      unitPriceUsd: number
      unitPriceIrr: number
      lineTotalUsd: number
      lineTotalIrr: number
      part?: { id: string; name: string; sku: string } | null
    }>
    customer: CustomerRef & {
      nationalCode?: string | null
      walletBalanceIrr: number
      totalOrders: number
      totalSpentIrr: number
    }
  }
  customer: CustomerRef & {
    nationalCode?: string | null
    walletBalanceIrr: number
    totalOrders: number
    totalSpentIrr: number
  }
}

interface PaymentsListResp {
  payments: PaymentListItem[]
  total: number
}

function faDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString('fa-IR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return iso
  }
}
function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}
function maskCard(card?: string | null): string {
  if (!card) return '—'
  const digits = String(card).replace(/\D/g, '')
  if (digits.length < 8) return card
  return `${digits.slice(0, 4)} **** **** ${digits.slice(-4)}`
}

export default function PaymentsPage() {
  const [tab, setTab] = useState<'PENDING' | 'APPROVED' | 'REJECTED' | 'ALL'>('PENDING')
  const [q, setQ] = useState('')
  const [method, setMethod] = useState<string>('')
  const [payments, setPayments] = useState<PaymentListItem[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [refreshKey, setRefreshKey] = useState(0)

  const [detail, setDetail] = useState<PaymentDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)

  const [actionLoading, setActionLoading] = useState<'approve' | 'reject' | null>(null)
  const [actionNote, setActionNote] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (tab !== 'ALL') params.set('status', tab)
      if (method) params.set('method', method)
      if (q) params.set('q', q)
      params.set('pageSize', '50')
      const d = await adminFetchJson<PaymentsListResp>(
        `/api/admin/payments?${params.toString()}`,
      )
      setPayments(d.payments)
      setTotal(d.total)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری پرداخت‌ها')
    } finally {
      setLoading(false)
    }
  }, [tab, q, method])

  useEffect(() => {
    void load()
  }, [load, refreshKey])

  const openDetail = useCallback(async (p: PaymentListItem) => {
    setDetailOpen(true)
    setDetail(null)
    setDetailLoading(true)
    setActionNote('')
    try {
      const d = await adminFetchJson<PaymentDetail>(`/api/admin/payments/${p.id}`)
      setDetail(d)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری جزئیات')
      setDetailOpen(false)
    } finally {
      setDetailLoading(false)
    }
  }, [])

  const doAction = useCallback(
    async (action: 'approve' | 'reject') => {
      if (!detail) return
      setActionLoading(action)
      try {
        const d = await adminFetchJson<{ ok: boolean; payment: PaymentListItem; orderStatus?: string }>(
          `/api/admin/payments/${detail.id}`,
          { method: 'PATCH', json: { action, note: actionNote || null } },
        )
        toast.success(action === 'approve' ? 'پرداخت تایید شد' : 'پرداخت رد شد')
        setDetailOpen(false)
        setRefreshKey((k) => k + 1)
        // Optional: surface the order status side-effect.
        if (action === 'approve' && d.orderStatus) {
          toast.message(`وضعیت سفارش به «${d.orderStatus}» تغییر کرد`, {
            description: `${detail.order.orderNumber}`,
          })
        }
      } catch (err) {
        toast.error((err as Error).message || 'خطا در انجام عملیات')
      } finally {
        setActionLoading(null)
      }
    },
    [detail, actionNote],
  )

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">تایید پرداخت‌ها</h1>
          <p className="text-sm text-muted-foreground">
            بررسی رسیدهای کارت به کارت و پرداخت‌های درگاه آنلاین
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setRefreshKey((k) => k + 1)}>
          <RefreshCw className="ml-2 h-4 w-4" />
          بروزرسانی
        </Button>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="PENDING">در انتظار</TabsTrigger>
          <TabsTrigger value="APPROVED">تایید شده</TabsTrigger>
          <TabsTrigger value="REJECTED">رد شده</TabsTrigger>
          <TabsTrigger value="ALL">همه</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4 space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div className="relative sm:col-span-2">
                  <Search className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="کد پیگیری، موبایل، payerCard، refId..."
                    className="pr-9"
                  />
                </div>
                <Select value={method} onValueChange={(v) => setMethod(v === '__all__' ? '' : v)}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="روش پرداخت" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__all__">همه روش‌ها</SelectItem>
                    {Object.entries(METHOD_LABEL).map(([k, v]) => (
                      <SelectItem key={k} value={k}>
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto thin-scrollbar">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>سفارش</TableHead>
                      <TableHead>مشتری</TableHead>
                      <TableHead>مبلغ</TableHead>
                      <TableHead>روش</TableHead>
                      <TableHead>کد پیگیری</TableHead>
                      <TableHead>پرداخت‌کننده</TableHead>
                      <TableHead>رسید</TableHead>
                      <TableHead>تاریخ</TableHead>
                      <TableHead className="text-left">عملیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={`sk-${i}`}>
                          <TableCell colSpan={9}>
                            <Skeleton className="h-6 w-full" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : payments.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={9} className="py-12 text-center text-muted-foreground">
                          <PartyPopper className="mx-auto mb-2 h-8 w-8 text-emerald-500" />
                          {tab === 'PENDING'
                            ? 'پرداخت در انتظاری وجود ندارد 🎉'
                            : 'پرداختی یافت نشد'}
                        </TableCell>
                      </TableRow>
                    ) : (
                      payments.map((p) => {
                        const MIcon = methodIcon(p.method)
                        return (
                          <TableRow key={p.id} className="cursor-pointer hover:bg-muted/50" onClick={() => openDetail(p)}>
                            <TableCell>
                              <span className="font-mono font-medium ltr-content" dir="ltr">
                                {p.order.orderNumber}
                              </span>
                              <span className="block text-xs text-muted-foreground tabular-nums">
                                {formatIrr(p.order.totalIrr)}
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="font-medium">
                                  {p.customer.name} {p.customer.family}
                                </span>
                                <span className="text-xs text-muted-foreground ltr-content" dir="ltr">
                                  {p.customer.phone}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="font-medium tabular-nums">{formatIrr(p.amountIrr)}</span>
                                <span className="text-xs text-muted-foreground ltr-content" dir="ltr">
                                  {formatUsd(p.amountUsd)}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1.5">
                                <MIcon className="h-3.5 w-3.5 text-muted-foreground" />
                                <Badge className={METHOD_BADGE[p.method] ?? ''} variant="outline">
                                  {METHOD_LABEL[p.method] ?? p.method}
                                </Badge>
                              </div>
                              {p.method === 'GATEWAY' && (p.gateway || p.refId) ? (
                                <span className="mt-0.5 block text-xs text-muted-foreground ltr-content" dir="ltr">
                                  {p.gateway ? p.gateway : ''}{p.refId ? ` · ${p.refId}` : ''}
                                </span>
                              ) : null}
                            </TableCell>
                            <TableCell>
                              {p.referenceCode ? (
                                <span className="font-mono text-xs ltr-content" dir="ltr">
                                  {p.referenceCode}
                                </span>
                              ) : (
                                <span className="text-xs text-muted-foreground">—</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <span className="text-sm">{p.payerName ?? '—'}</span>
                              {p.payerCard ? (
                                <span className="block text-xs text-muted-foreground ltr-content" dir="ltr">
                                  {maskCard(p.payerCard)}
                                </span>
                              ) : null}
                            </TableCell>
                            <TableCell>
                              {p.receiptImageUrl ? (
                                <a
                                  href={p.receiptImageUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center gap-1 text-xs text-emerald-700 hover:underline dark:text-emerald-400"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <ExternalLink className="h-3.5 w-3.5" />
                                  رسید
                                </a>
                              ) : (
                                <span className="text-xs text-muted-foreground">—</span>
                              )}
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                              {faDate(p.createdAt)}
                            </TableCell>
                            <TableCell className="text-left">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  openDetail(p)
                                }}
                              >
                                <Eye className="ml-1 h-4 w-4" />
                                بررسی
                              </Button>
                            </TableCell>
                          </TableRow>
                        )
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
              {!loading && payments.length > 0 ? (
                <div className="border-t p-3 text-xs text-muted-foreground">
                  مجموع: {faNum(total)} پرداخت
                </div>
              ) : null}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Payment detail + actions */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto thin-scrollbar">
          {detailLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : detail ? (
            <div className="space-y-5">
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2">
                  <span className="text-sm text-muted-foreground">پرداخت برای سفارش</span>
                  <span className="font-mono ltr-content" dir="ltr">{detail.order.orderNumber}</span>
                  <Badge className={STATUS_BADGE[detail.status] ?? ''} variant="outline">
                    {STATUS_LABEL[detail.status] ?? detail.status}
                  </Badge>
                  <Badge className={METHOD_BADGE[detail.method] ?? ''} variant="outline">
                    {METHOD_LABEL[detail.method] ?? detail.method}
                  </Badge>
                </DialogTitle>
                <DialogDescription>
                  {detail.status === 'PENDING'
                    ? 'رسید را بررسی کرده و تایید یا رد کنید'
                    : 'این پرداخت قبلاً بررسی شده است'}
                </DialogDescription>
              </DialogHeader>

              {/* Amount & basic info */}
              <div className="rounded-md border p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">مبلغ پرداخت</span>
                  <div className="text-left">
                    <p className="text-xl font-bold tabular-nums">{formatIrr(detail.amountIrr)}</p>
                    <p className="text-xs text-muted-foreground ltr-content" dir="ltr">{formatUsd(detail.amountUsd)}</p>
                  </div>
                </div>
                <Separator />
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">مشتری</p>
                    <p className="font-medium">
                      {detail.customer.name} {detail.customer.family}
                    </p>
                    <p className="text-xs text-muted-foreground ltr-content" dir="ltr">{detail.customer.phone}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">پرداخت‌کننده</p>
                    <p className="font-medium">{detail.payerName ?? '—'}</p>
                    <p className="text-xs text-muted-foreground ltr-content" dir="ltr">{maskCard(detail.payerCard)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">کد پیگیری</p>
                    <p className="font-mono text-xs ltr-content" dir="ltr">
                      {detail.referenceCode ?? '—'}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">تاریخ</p>
                    <p className="text-xs">{faDate(detail.createdAt)}</p>
                  </div>
                </div>
                {detail.receiptImageUrl ? (
                  <div>
                    <a
                      href={detail.receiptImageUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm text-emerald-700 hover:underline dark:text-emerald-400"
                    >
                      <ExternalLink className="h-4 w-4" />
                      مشاهده تصویر رسید
                    </a>
                  </div>
                ) : null}
                {detail.note ? (
                  <div className="rounded bg-muted/50 p-2 text-xs">
                    <p className="font-medium">یادداشت پرداخت:</p>
                    <p className="mt-1 text-muted-foreground">{detail.note}</p>
                  </div>
                ) : null}
              </div>

              {/* Gateway info if applicable */}
              {detail.method === 'GATEWAY' ? (
                <div className="rounded-md border border-emerald-200 bg-emerald-50/50 p-4 dark:border-emerald-900/50 dark:bg-emerald-950/20">
                  <p className="mb-2 text-xs font-medium text-emerald-700 dark:text-emerald-300">
                    اطلاعات درگاه آنلاین
                  </p>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground">درگاه</p>
                      <p className="font-mono ltr-content" dir="ltr">{detail.gateway ?? '—'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Authority</p>
                      <p className="font-mono text-xs ltr-content" dir="ltr">
                        {detail.authority ?? '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Ref ID</p>
                      <p className="font-mono text-xs ltr-content" dir="ltr">
                        {detail.refId ?? '—'}
                      </p>
                    </div>
                    {detail.gatewayUrl ? (
                      <div>
                        <a
                          href={detail.gatewayUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-emerald-700 hover:underline dark:text-emerald-400"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                          صفحه درگاه
                        </a>
                      </div>
                    ) : null}
                  </div>
                  <p className="mt-2 text-xs text-emerald-700 dark:text-emerald-300">
                    * پرداخت‌های درگاهی توسط خود درگاه تایید شده‌اند؛ تایید دستی نیز نهایی می‌کند.
                  </p>
                </div>
              ) : null}

              {/* Order items */}
              <div className="rounded-md border">
                <div className="overflow-x-auto thin-scrollbar">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>قطعه</TableHead>
                        <TableHead className="text-center">تعداد</TableHead>
                        <TableHead className="text-left">قیمت واحد ($)</TableHead>
                        <TableHead className="text-left">جمع ردیف</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detail.order.items.map((it) => (
                        <TableRow key={it.id}>
                          <TableCell>
                            <span className="font-medium">{it.partNameSnapshot}</span>
                            {it.part?.sku ? (
                              <span className="block text-xs text-muted-foreground ltr-content" dir="ltr">
                                {it.part.sku}
                              </span>
                            ) : null}
                          </TableCell>
                          <TableCell className="text-center tabular-nums">{faNum(it.quantity)}</TableCell>
                          <TableCell className="text-left tabular-nums ltr-content" dir="ltr">{formatUsd(it.unitPriceUsd)}</TableCell>
                          <TableCell className="text-left tabular-nums">{formatIrr(it.lineTotalIrr)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Order totals */}
              <div className="rounded-md border p-3 space-y-1.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">جمع کل سفارش</span>
                  <span className="tabular-nums ltr-content" dir="ltr">{formatUsd(detail.order.subtotalUsd)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ارسال</span>
                  <span className="tabular-nums ltr-content" dir="ltr">{formatUsd(detail.order.shippingUsd)}</span>
                </div>
                {detail.order.discountIrr > 0 ? (
                  <div className="flex justify-between text-emerald-700 dark:text-emerald-400">
                    <span>تخفیف</span>
                    <span className="tabular-nums">−{formatIrr(detail.order.discountIrr)}</span>
                  </div>
                ) : null}
                <Separator className="my-2" />
                <div className="flex justify-between font-semibold">
                  <span>مبلغ نهایی سفارش</span>
                  <span className="tabular-nums">{formatIrr(detail.order.totalIrr)}</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>مبلغ این پرداخت</span>
                  <span className="tabular-nums">{formatIrr(detail.amountIrr)}</span>
                </div>
              </div>

              {/* Reviewer history (if reviewed) */}
              {detail.reviewedAt ? (
                <div className="rounded-md border p-3 text-xs">
                  <p className="text-muted-foreground">
                    بررسی‌کننده: <span className="font-medium text-foreground">{detail.reviewedBy?.name ?? '—'}</span>
                  </p>
                  <p className="mt-1 text-muted-foreground">تاریخ بررسی: {faDate(detail.reviewedAt)}</p>
                </div>
              ) : null}

              {/* Approve / Reject actions */}
              {detail.status === 'PENDING' ? (
                <div className="rounded-md border border-amber-300 bg-amber-50/50 p-3 space-y-3 dark:border-amber-900/50 dark:bg-amber-950/20">
                  <Label className="text-xs">یادداشت بررسی (اختیاری)</Label>
                  <Textarea
                    value={actionNote}
                    onChange={(e) => setActionNote(e.target.value)}
                    placeholder="توضیحاتی درباره تایید یا رد این پرداخت..."
                    className="min-h-[60px]"
                  />
                  <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                    <Button
                      variant="destructive"
                      disabled={actionLoading !== null}
                      onClick={() => doAction('reject')}
                    >
                      {actionLoading === 'reject' ? (
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      ) : (
                        <XCircle className="ml-2 h-4 w-4" />
                      )}
                      رد پرداخت
                    </Button>
                    <Button
                      className="bg-emerald-600 text-white hover:bg-emerald-700"
                      disabled={actionLoading !== null}
                      onClick={() => doAction('approve')}
                    >
                      {actionLoading === 'approve' ? (
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      ) : (
                        <CheckCircle2 className="ml-2 h-4 w-4" />
                      )}
                      تایید پرداخت
                    </Button>
                  </div>
                </div>
              ) : null}
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">پرداخت یافت نشد</div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
