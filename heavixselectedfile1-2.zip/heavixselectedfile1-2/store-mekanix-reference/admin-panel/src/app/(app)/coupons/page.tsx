'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Plus,
  RefreshCw,
  Loader2,
  Pencil,
  Trash2,
  Ticket,
  CheckCircle2,
  XCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { formatIrr } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Card, CardContent } from '@/components/ui/card'

interface Coupon {
  id: string
  code: string
  type: 'PERCENT' | 'FIXED'
  value: number
  expiresAt: string | null
  usageLimit: number
  usedCount: number
  active: boolean
  minOrderIrr: number
  createdAt: string
}
interface CouponsResp {
  coupons: Coupon[]
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

function faDate(s: string | null): string {
  if (!s) return '—'
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(new Date(s))
  } catch {
    return '—'
  }
}

interface FormState {
  id?: string
  code: string
  type: 'PERCENT' | 'FIXED'
  value: string
  expiresAt: string
  usageLimit: string
  minOrderIrr: string
  active: boolean
}

const EMPTY: FormState = {
  code: '',
  type: 'PERCENT',
  value: '',
  expiresAt: '',
  usageLimit: '0',
  minOrderIrr: '0',
  active: true,
}

export default function CouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState<FormState>(EMPTY)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleteErr, setDeleteErr] = useState('')
  const [deleteCode, setDeleteCode] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<CouponsResp>('/api/admin/coupons')
      setCoupons(d.coupons || [])
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری کدهای تخفیف')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  function openCreate() {
    setForm({ ...EMPTY })
    setDialogOpen(true)
  }
  function openEdit(c: Coupon) {
    setForm({
      id: c.id,
      code: c.code,
      type: c.type,
      value: String(c.value),
      expiresAt: c.expiresAt ? c.expiresAt.slice(0, 10) : '',
      usageLimit: String(c.usageLimit),
      minOrderIrr: String(c.minOrderIrr),
      active: c.active,
    })
    setDialogOpen(true)
  }

  async function save() {
    if (!form.code.trim()) {
      toast.error('کد تخفیف الزامی است')
      return
    }
    const v = Number(form.value)
    if (!Number.isFinite(v) || v <= 0) {
      toast.error('مقدار تخفیف نامعتبر است')
      return
    }
    if (form.type === 'PERCENT' && v > 100) {
      toast.error('درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد')
      return
    }
    setSaving(true)
    try {
      const body: Record<string, unknown> = {
        code: form.code.trim().toUpperCase(),
        type: form.type,
        value: v,
        usageLimit: Number(form.usageLimit) || 0,
        minOrderIrr: Number(form.minOrderIrr) || 0,
        active: form.active,
      }
      if (form.expiresAt) {
        // Set end-of-day
        body.expiresAt = new Date(`${form.expiresAt}T23:59:59`).toISOString()
      } else {
        body.expiresAt = null
      }
      if (form.id) {
        await adminFetchJson(`/api/admin/coupons/${form.id}`, { method: 'PUT', json: body })
        toast.success('کد تخفیف بروزرسانی شد')
      } else {
        await adminFetchJson('/api/admin/coupons', { method: 'POST', json: body })
        toast.success('کد تخفیف ایجاد شد')
      }
      setDialogOpen(false)
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره‌سازی')
    } finally {
      setSaving(false)
    }
  }

  async function toggleActive(c: Coupon, active: boolean) {
    try {
      await adminFetchJson(`/api/admin/coupons/${c.id}`, { method: 'PUT', json: { active } })
      setCoupons((prev) => prev.map((x) => (x.id === c.id ? { ...x, active } : x)))
      toast.success(active ? 'کد فعال شد' : 'کد غیرفعال شد')
    } catch (err) {
      toast.error((err as Error).message || 'خطا در تغییر وضعیت')
    }
  }

  async function confirmDelete() {
    if (!deleteId) return
    try {
      const res = await adminFetch(`/api/admin/coupons/${deleteId}`, { method: 'DELETE' })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error || `HTTP ${res.status}`)
      }
      toast.success('کد تخفیف حذف شد')
      setDeleteId(null)
      setDeleteErr('')
      load()
    } catch (err) {
      setDeleteErr((err as Error).message || 'خطا در حذف')
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">کدهای تخفیف</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            مدیریت کدهای تخفیف درصدی و مبلغ ثابت برای سفارش‌ها
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            بروزرسانی
          </Button>
          <Button size="sm" onClick={openCreate}>
            <Plus className="h-4 w-4" /> کد تخفیف جدید
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4 md:p-6">
          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : coupons.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center text-muted-foreground">
              <Ticket className="h-10 w-10 opacity-30" />
              <p className="text-sm">هنوز کد تخفیفی ثبت نشده است</p>
              <Button size="sm" onClick={openCreate}>
                <Plus className="h-4 w-4" /> ثبت اولین کد تخفیف
              </Button>
            </div>
          ) : (
            <div className="rounded-lg border max-h-[70vh] overflow-y-auto thin-scrollbar">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>کد</TableHead>
                    <TableHead>نوع</TableHead>
                    <TableHead>مقدار</TableHead>
                    <TableHead className="hidden md:table-cell">حداقل سفارش</TableHead>
                    <TableHead className="text-center">استفاده</TableHead>
                    <TableHead className="hidden lg:table-cell">انقضا</TableHead>
                    <TableHead className="text-center">فعال</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {coupons.map((c) => {
                    const expired = c.expiresAt ? new Date(c.expiresAt).getTime() < Date.now() : false
                    return (
                      <TableRow key={c.id}>
                        <TableCell>
                          <span className="font-mono font-bold tracking-wide ltr inline-block" dir="ltr">
                            {c.code}
                          </span>
                        </TableCell>
                        <TableCell>
                          {c.type === 'PERCENT' ? (
                            <Badge className="bg-violet-100 text-violet-700 dark:bg-violet-950/40 dark:text-violet-300 hover:bg-violet-100">
                              درصد
                            </Badge>
                          ) : (
                            <Badge className="bg-cyan-100 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300 hover:bg-cyan-100">
                              مبلغ ثابت
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">
                          {c.type === 'PERCENT'
                            ? `٪${faNum(c.value)}`
                            : formatIrr(c.value)}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-muted-foreground">
                          {c.minOrderIrr > 0 ? formatIrr(c.minOrderIrr) : '—'}
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex flex-col items-center gap-0.5">
                            <span className="text-sm font-medium tabular-nums">
                              {faNum(c.usedCount)} / {c.usageLimit > 0 ? faNum(c.usageLimit) : '∞'}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          {c.expiresAt ? (
                            <span className={expired ? 'text-rose-600 dark:text-rose-400' : ''}>
                              {faDate(c.expiresAt)}
                              {expired ? ' (منقضی)' : ''}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">بدون انقضا</span>
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <Switch
                            checked={c.active && !expired}
                            disabled={expired}
                            onCheckedChange={(v) => toggleActive(c, v)}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 justify-end">
                            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(c)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8 text-rose-600 hover:text-rose-700"
                              onClick={() => {
                                setDeleteId(c.id)
                                setDeleteCode(c.code)
                                setDeleteErr('')
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id ? 'ویرایش کد تخفیف' : 'کد تخفیف جدید'}</DialogTitle>
            <DialogDescription>
              کدها می‌توانند به‌صورت درصدی (٪) یا مبلغ ثابت (تومان) اعمال شوند.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="cp-code">کد تخفیف *</Label>
              <Input
                id="cp-code"
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                placeholder="SUMMER20"
                className="font-mono ltr"
                dir="ltr"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>نوع تخفیف</Label>
                <Select
                  value={form.type}
                  onValueChange={(v) => setForm({ ...form, type: v as 'PERCENT' | 'FIXED' })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PERCENT">درصدی (٪)</SelectItem>
                    <SelectItem value="FIXED">مبلغ ثابت (تومان)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cp-value">مقدار *</Label>
                <Input
                  id="cp-value"
                  type="number"
                  value={form.value}
                  onChange={(e) => setForm({ ...form, value: e.target.value })}
                  placeholder={form.type === 'PERCENT' ? 'مثلاً: 15' : 'مبلغ به تومان'}
                  dir="ltr"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="cp-min">حداقل مبلغ سفارش (تومان)</Label>
                <Input
                  id="cp-min"
                  type="number"
                  value={form.minOrderIrr}
                  onChange={(e) => setForm({ ...form, minOrderIrr: e.target.value })}
                  placeholder="0 = بدون حداقل"
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cp-limit">حد استفاده (۰ = نامحدود)</Label>
                <Input
                  id="cp-limit"
                  type="number"
                  value={form.usageLimit}
                  onChange={(e) => setForm({ ...form, usageLimit: e.target.value })}
                  placeholder="0"
                  dir="ltr"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cp-exp">تاریخ انقضا (اختیاری)</Label>
              <Input
                id="cp-exp"
                type="date"
                value={form.expiresAt}
                onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
                dir="ltr"
              />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label htmlFor="cp-active" className="cursor-pointer">فعال بودن</Label>
                <p className="text-xs text-muted-foreground mt-0.5">
                  اگر غیرفعال باشد، کد قابل استفاده نیست
                </p>
              </div>
              <Switch
                id="cp-active"
                checked={form.active}
                onCheckedChange={(v) => setForm({ ...form, active: v })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)} disabled={saving}>
              انصراف
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              ذخیره
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (!o) { setDeleteId(null); setDeleteErr('') } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کد تخفیف</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteErr ? (
                <span className="text-rose-600 dark:text-rose-400 block mb-2">{deleteErr}</span>
              ) : null}
              آیا از حذف کد «<span className="font-mono ltr" dir="ltr">{deleteCode}</span>» مطمئن هستید؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
