'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import {
  Plus,
  Search,
  RefreshCw,
  Loader2,
  Pencil,
  Trash2,
  Star,
  Eye,
  AlertTriangle,
  Package,
  ImageOff,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { formatIrr, formatUsd } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

interface EffectiveRate {
  rate: number
  marginPercent: number
  source: 'MANUAL' | 'TELEGRAM' | 'DEFAULT'
  date: string
}

interface Category {
  id: string
  name: string
}
interface Brand {
  id: string
  name: string
}
interface CarModel {
  id: string
  brand: string
  model: string
  yearFrom: number
  yearTo: number
}

interface Part {
  id: string
  name: string
  nameFa?: string | null
  sku: string
  categoryId: string
  brandId?: string | null
  description?: string | null
  priceUsd: number
  oldPriceUsd?: number | null
  stock: number
  lowStockThreshold: number
  images: string[]
  compatibleCars: string[]
  carModels: CarModel[]
  active: boolean
  featured: boolean
  views: number
  soldCount: number
  category: { id: string; name: string } | null
  brand: { id: string; name: string } | null
  priceIrr: number
  oldPriceIrr: number | null
}

interface PartsListResp {
  parts: Part[]
  effectiveRate: EffectiveRate
}
interface CategoriesResp {
  flat: Category[]
}
interface BrandsResp {
  brands: Array<{ id: string; name: string }>
}
interface CarModelsResp {
  grouped: Record<string, CarModel[]>
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

interface FormState {
  id?: string
  name: string
  nameFa: string
  sku: string
  categoryId: string
  brandId: string
  description: string
  priceUsd: string
  oldPriceUsd: string
  stock: string
  lowStockThreshold: string
  images: string
  compatibleCars: string
  carModelIds: string[]
  active: boolean
  featured: boolean
}

const EMPTY: FormState = {
  name: '',
  nameFa: '',
  sku: '',
  categoryId: '',
  brandId: '',
  description: '',
  priceUsd: '',
  oldPriceUsd: '',
  stock: '0',
  lowStockThreshold: '5',
  images: '',
  compatibleCars: '',
  carModelIds: [],
  active: true,
  featured: false,
}

export default function PartsPage() {
  const [parts, setParts] = useState<Part[]>([])
  const [eff, setEff] = useState<EffectiveRate | null>(null)
  const [categories, setCategories] = useState<Category[]>([])
  const [brands, setBrands] = useState<Array<{ id: string; name: string }>>([])
  const [groupedModels, setGroupedModels] = useState<Record<string, CarModel[]>>({})

  const [q, setQ] = useState('')
  const [fCat, setFCat] = useState<string>('')
  const [fBrand, setFBrand] = useState<string>('')
  const [fActive, setFActive] = useState<'true' | 'false' | ''>('')

  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState<FormState>(EMPTY)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set('q', q)
      if (fCat) params.set('categoryId', fCat)
      if (fBrand) params.set('brandId', fBrand)
      if (fActive) params.set('active', fActive)
      const d = await adminFetchJson<PartsListResp>(
        `/api/admin/parts${params.size ? `?${params.toString()}` : ''}`,
      )
      setParts(d.parts)
      setEff(d.effectiveRate)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری قطعات')
    } finally {
      setLoading(false)
    }
  }, [q, fCat, fBrand, fActive])

  const loadMeta = useCallback(async () => {
    try {
      const [c, b, m] = await Promise.all([
        adminFetchJson<CategoriesResp>('/api/admin/categories'),
        adminFetchJson<BrandsResp>('/api/admin/brands'),
        adminFetchJson<CarModelsResp>('/api/admin/car-models'),
      ])
      setCategories(c.flat || [])
      setBrands(b.brands || [])
      setGroupedModels(m.grouped || {})
    } catch {
      // ignore
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    loadMeta()
  }, [loadMeta])

  function openCreate() {
    setForm({ ...EMPTY, lowStockThreshold: '5', stock: '0' })
    setDialogOpen(true)
  }

  function openEdit(p: Part) {
    setForm({
      id: p.id,
      name: p.name,
      nameFa: p.nameFa || '',
      sku: p.sku,
      categoryId: p.categoryId,
      brandId: p.brandId || '',
      description: p.description || '',
      priceUsd: String(p.priceUsd),
      oldPriceUsd: p.oldPriceUsd != null ? String(p.oldPriceUsd) : '',
      stock: String(p.stock),
      lowStockThreshold: String(p.lowStockThreshold),
      images: Array.isArray(p.images) ? p.images.join(', ') : '',
      compatibleCars: Array.isArray(p.compatibleCars) ? p.compatibleCars.join(', ') : '',
      carModelIds: p.carModels.map((c) => c.id),
      active: p.active,
      featured: p.featured,
    })
    setDialogOpen(true)
  }

  async function save() {
    if (!form.name || !form.sku || !form.categoryId || !form.priceUsd) {
      toast.error('نام، SKU، دسته و قیمت الزامی هستند')
      return
    }
    setSaving(true)
    try {
      const body = {
        name: form.name,
        nameFa: form.nameFa || undefined,
        sku: form.sku,
        categoryId: form.categoryId,
        brandId: form.brandId || undefined,
        description: form.description || undefined,
        priceUsd: Number(form.priceUsd),
        oldPriceUsd: form.oldPriceUsd === '' ? null : Number(form.oldPriceUsd),
        stock: Number(form.stock) || 0,
        lowStockThreshold: Number(form.lowStockThreshold) || 5,
        images: form.images,
        compatibleCars: form.compatibleCars,
        carModelIds: form.carModelIds,
        active: form.active,
        featured: form.featured,
      }
      const res = form.id
        ? await adminFetch(`/api/admin/parts/${form.id}`, { method: 'PUT', json: body })
        : await adminFetch('/api/admin/parts', { method: 'POST', json: body })
      const json = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(json?.error || 'ذخیره ناموفق بود')
        return
      }
      toast.success(form.id ? 'قطعه بروزرسانی شد' : 'قطعه ساخته شد')
      setDialogOpen(false)
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    } finally {
      setSaving(false)
    }
  }

  async function remove(id: string) {
    try {
      const res = await adminFetch(`/api/admin/parts/${id}`, { method: 'DELETE' })
      const json = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(json?.error || 'حذف ناموفق بود')
        return
      }
      toast.success('قطعه حذف شد')
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    }
  }

  const liveIrr = useMemo(() => {
    if (!form.priceUsd || !eff) return null
    const usd = Number(form.priceUsd)
    if (!Number.isFinite(usd) || usd <= 0) return null
    const r = eff.rate * (1 + (eff.marginPercent || 0) / 100)
    return Math.round(usd * r)
  }, [form.priceUsd, eff])

  const allModels = useMemo(() => {
    return Object.entries(groupedModels).flatMap(([brand, list]) =>
      list.map((m) => ({ ...m, brand })),
    )
  }, [groupedModels])

  function toggleModel(id: string) {
    setForm((f) =>
      f.carModelIds.includes(id)
        ? { ...f, carModelIds: f.carModelIds.filter((x) => x !== id) }
        : { ...f, carModelIds: [...f.carModelIds, id] },
    )
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">مدیریت قطعات</h1>
          <p className="text-sm text-muted-foreground">
            {eff ? (
              <>
                نرخ مؤثر: <b>{faNum(eff.rate)} تومان</b> · حاشیه {faNum(eff.marginPercent)}٪
              </>
            ) : (
              'در حال بارگذاری نرخ...'
            )}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => load()}>
            <RefreshCw className="h-4 w-4" />
            بروزرسانی
          </Button>
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" />
            قطعه جدید
          </Button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-5">
        <div className="relative col-span-2 md:col-span-2 lg:col-span-1">
          <Search className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی نام / SKU"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="pr-9"
          />
        </div>
        <Select value={fCat} onValueChange={setFCat}>
          <SelectTrigger>
            <SelectValue placeholder="همه دسته‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">همه دسته‌ها</SelectItem>
            {categories.map((c) => (
              <SelectItem key={c.id} value={c.id}>
                {c.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={fBrand} onValueChange={setFBrand}>
          <SelectTrigger>
            <SelectValue placeholder="همه برندها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">همه برندها</SelectItem>
            {brands.map((b) => (
              <SelectItem key={b.id} value={b.id}>
                {b.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={fActive} onValueChange={setFActive}>
          <SelectTrigger>
            <SelectValue placeholder="همه وضعیت‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">همه وضعیت‌ها</SelectItem>
            <SelectItem value="true">فعال</SelectItem>
            <SelectItem value="false">غیرفعال</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="ghost" onClick={() => { setQ(''); setFCat(''); setFBrand(''); setFActive('') }}>
          پاک کردن فیلترها
        </Button>
      </div>

      {/* Table */}
      <div className="thin-scrollbar overflow-x-auto rounded-md border bg-card">
        <Table>
          <TableHeader className="sticky top-0 z-10 bg-card">
            <TableRow>
              <TableHead className="min-w-48">نام قطعه</TableHead>
              <TableHead className="min-w-32">SKU</TableHead>
              <TableHead>دسته</TableHead>
              <TableHead>برند</TableHead>
              <TableHead className="text-left">قیمت ($)</TableHead>
              <TableHead className="text-left">قیمت (تومان)</TableHead>
              <TableHead className="text-center">موجودی</TableHead>
              <TableHead className="text-center">ویژه</TableHead>
              <TableHead className="text-center">فعال</TableHead>
              <TableHead className="text-center">بازدید</TableHead>
              <TableHead className="text-center">فروش</TableHead>
              <TableHead className="text-center">عملیات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={12}>
                    <Skeleton className="h-10 w-full" />
                  </TableCell>
                </TableRow>
              ))
            ) : parts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={12} className="py-12">
                  <div className="flex flex-col items-center gap-2 text-center text-sm text-muted-foreground">
                    <Package className="h-8 w-8 opacity-50" />
                    <p>قطعه‌ای یافت نشد</p>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              parts.map((p) => (
                <TableRow key={p.id} className={p.active ? '' : 'opacity-60'}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {p.images && p.images[0] ? (
                        <img
                          src={p.images[0]}
                          alt={p.name}
                          className="h-10 w-10 rounded-md object-cover"
                          onError={(e) => {
                            ;(e.target as HTMLImageElement).style.display = 'none'
                          }}
                        />
                      ) : (
                        <div className="flex h-10 w-10 items-center justify-center rounded-md bg-muted">
                          <ImageOff className="h-4 w-4 text-muted-foreground" />
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{p.name}</p>
                        {p.nameFa && (
                          <p className="truncate text-[11px] text-muted-foreground">
                            {p.nameFa}
                          </p>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs" dir="ltr">
                    {p.sku}
                  </TableCell>
                  <TableCell className="text-xs">{p.category?.name || '—'}</TableCell>
                  <TableCell className="text-xs">{p.brand?.name || '—'}</TableCell>
                  <TableCell className="text-left text-xs tabular-nums" dir="ltr">
                    {formatUsd(p.priceUsd)}
                    {p.oldPriceUsd ? (
                      <span className="mr-1 text-muted-foreground line-through">
                        {formatUsd(p.oldPriceUsd)}
                      </span>
                    ) : null}
                  </TableCell>
                  <TableCell className="text-left text-xs tabular-nums">
                    {faNum(p.priceIrr)}
                    {p.oldPriceIrr ? (
                      <span className="mr-1 text-muted-foreground line-through">
                        {faNum(p.oldPriceIrr)}
                      </span>
                    ) : null}
                  </TableCell>
                  <TableCell className="text-center">
                    {p.stock === 0 ? (
                      <Badge variant="destructive">ناموجود</Badge>
                    ) : p.stock <= p.lowStockThreshold ? (
                      <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200">
                        {faNum(p.stock)}
                      </Badge>
                    ) : (
                      <span className="text-xs tabular-nums">{faNum(p.stock)}</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {p.featured ? (
                      <Star className="mx-auto h-4 w-4 fill-amber-400 text-amber-400" />
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {p.active ? (
                      <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200">
                        فعال
                      </Badge>
                    ) : (
                      <Badge variant="secondary">غیرفعال</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-center text-xs tabular-nums">
                    <span className="inline-flex items-center gap-1">
                      <Eye className="h-3 w-3 text-muted-foreground" />
                      {faNum(p.views)}
                    </span>
                  </TableCell>
                  <TableCell className="text-center text-xs tabular-nums">
                    {faNum(p.soldCount)}
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => openEdit(p)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>حذف قطعه «{p.name}»؟</AlertDialogTitle>
                            <AlertDialogDescription>
                              این عمل قابل بازگشت نیست. اگر قطعه در سفارشی استفاده
                              شده باشد، حذف رد می‌شود.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>انصراف</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => remove(p.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              حذف کن
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="thin-scrollbar max-h-[92vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {form.id ? 'ویرایش قطعه' : 'ایجاد قطعه جدید'}
            </DialogTitle>
            <DialogDescription>
              قیمت‌ها به دلار ثبت می‌شوند و به‌صورت خودکار با نرخ مؤثر امروز به
              تومان تبدیل می‌شوند.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="name">نام قطعه *</Label>
              <Input
                id="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="nameFa">نام فارسی</Label>
              <Input
                id="nameFa"
                value={form.nameFa}
                onChange={(e) => setForm({ ...form, nameFa: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sku">SKU *</Label>
              <Input
                id="sku"
                dir="ltr"
                className="text-left"
                value={form.sku}
                onChange={(e) => setForm({ ...form, sku: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="category">دسته *</Label>
              <Select
                value={form.categoryId}
                onValueChange={(v) => setForm({ ...form, categoryId: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب دسته" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="brand">برند</Label>
              <Select
                value={form.brandId}
                onValueChange={(v) => setForm({ ...form, brandId: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="بدون برند" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">بدون برند</SelectItem>
                  {brands.map((b) => (
                    <SelectItem key={b.id} value={b.id}>
                      {b.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="priceUsd">قیمت (دلار) *</Label>
              <Input
                id="priceUsd"
                dir="ltr"
                inputMode="decimal"
                className="text-left"
                value={form.priceUsd}
                onChange={(e) => setForm({ ...form, priceUsd: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="oldPriceUsd">قیمت قبلی (دلار - برای تخفیف)</Label>
              <Input
                id="oldPriceUsd"
                dir="ltr"
                inputMode="decimal"
                className="text-left"
                value={form.oldPriceUsd}
                onChange={(e) => setForm({ ...form, oldPriceUsd: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stock">موجودی</Label>
              <Input
                id="stock"
                dir="ltr"
                inputMode="numeric"
                className="text-left"
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="lowStockThreshold">آستانه موجودی کم</Label>
              <Input
                id="lowStockThreshold"
                dir="ltr"
                inputMode="numeric"
                className="text-left"
                value={form.lowStockThreshold}
                onChange={(e) => setForm({ ...form, lowStockThreshold: e.target.value })}
              />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="images">تصاویر (URL با کاما جدا شود)</Label>
              <Textarea
                id="images"
                rows={2}
                dir="ltr"
                className="text-left"
                placeholder="https://example.com/img1.jpg, https://example.com/img2.jpg"
                value={form.images}
                onChange={(e) => setForm({ ...form, images: e.target.value })}
              />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="compatibleCars">خودروهای سازگار (یادداشت آزاد، کاما)</Label>
              <Textarea
                id="compatibleCars"
                rows={2}
                placeholder="مثلاً تویوتا کرولا ۲۰۱۸، هیوندای النترا ۲۰۲۰"
                value={form.compatibleCars}
                onChange={(e) => setForm({ ...form, compatibleCars: e.target.value })}
              />
            </div>

            {/* Car models multi-select */}
            <div className="space-y-1.5 md:col-span-2">
              <Label>مدل خودروهای سازگار (انتخاب چندتایی)</Label>
              <div className="thin-scrollbar max-h-48 overflow-y-auto rounded-md border p-2">
                {allModels.length === 0 ? (
                  <p className="py-4 text-center text-xs text-muted-foreground">
                    هیچ مدل خودرویی ثبت نشده است
                  </p>
                ) : (
                  Object.entries(groupedModels).map(([brand, list]) => (
                    <div key={brand} className="mb-2">
                      <p className="mb-1 text-xs font-medium text-muted-foreground">
                        {brand}
                      </p>
                      <div className="grid grid-cols-1 gap-1 sm:grid-cols-2">
                        {list.map((m) => (
                          <label
                            key={m.id}
                            className="flex cursor-pointer items-center gap-2 rounded px-2 py-1 hover:bg-accent"
                          >
                            <Checkbox
                              checked={form.carModelIds.includes(m.id)}
                              onCheckedChange={() => toggleModel(m.id)}
                            />
                            <span className="text-xs">
                              {m.model} ({faNum(m.yearFrom)}–{faNum(m.yearTo)})
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="description">توضیحات</Label>
              <Textarea
                id="description"
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>

            <div className="flex items-center justify-between rounded-md border p-3">
              <div>
                <Label htmlFor="active" className="cursor-pointer">فعال</Label>
                <p className="text-xs text-muted-foreground">
                  قطعات غیرفعال در فروشگاه نمایش داده نمی‌شوند
                </p>
              </div>
              <Switch
                id="active"
                checked={form.active}
                onCheckedChange={(v) => setForm({ ...form, active: v })}
              />
            </div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <div>
                <Label htmlFor="featured" className="cursor-pointer">قطعه ویژه</Label>
                <p className="text-xs text-muted-foreground">در صفحه اصلی نمایش داده می‌شود</p>
              </div>
              <Switch
                id="featured"
                checked={form.featured}
                onCheckedChange={(v) => setForm({ ...form, featured: v })}
              />
            </div>
          </div>

          {/* Live IRR preview */}
          {liveIrr != null && (
            <div className="flex items-center justify-between rounded-lg bg-emerald-50 p-3 text-sm dark:bg-emerald-950/30">
              <span className="text-muted-foreground">پیش‌نمایش قیمت تومانی:</span>
              <span className="font-bold text-emerald-700 dark:text-emerald-300">
                {formatIrr(liveIrr)}
              </span>
            </div>
          )}

          <DialogFooter>
            <Button variant="ghost" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
              {form.id ? 'ذخیره تغییرات' : 'ساختن قطعه'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Helper note when filters yield nothing */}
      {!loading && parts.length === 0 && (
        <p className="flex items-center gap-2 text-xs text-muted-foreground">
          <AlertTriangle className="h-3.5 w-3.5" />
          اگر فیلتری تنظیم کرده‌اید، آن را پاک کنید یا قطعه جدید بسازید.
        </p>
      )}
    </div>
  )
}
