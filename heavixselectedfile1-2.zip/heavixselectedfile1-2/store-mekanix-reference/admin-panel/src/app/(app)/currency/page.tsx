'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  RefreshCw,
  TrendingUp,
  Clock,
  Loader2,
  Trash2,
  Save,
  Settings2,
  Calendar,
  Info,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { formatIrr } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

const SOURCE_LABEL: Record<string, string> = {
  MANUAL: 'دستی',
  TELEGRAM: 'تلگرام',
  DEFAULT: 'پیش‌فرض',
}

const SOURCE_BADGE: Record<string, string> = {
  MANUAL: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  TELEGRAM: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  DEFAULT: 'bg-slate-100 text-slate-700 dark:bg-slate-800/50 dark:text-slate-200',
}

interface CurrencyData {
  date: string
  effective: {
    rate: number
    marginPercent: number
    source: 'MANUAL' | 'TELEGRAM' | 'DEFAULT'
    date: string
  }
  setting: {
    defaultRate: number
    marginPercent: number
    autoUpdateEnabled: boolean
    autoSource: string
    lastAutoRate: number | null
    lastAutoStatus: string | null
    lastAutoFetchAt: string | null
    updatedAt: string
  } | null
  todayRate: {
    date: string
    rate: number
    marginPercent: number
    source: string
    note: string | null
    setBy: { id: string; name: string; username: string } | null
    createdAt: string
  } | null
  telegram: { rate: number; status: string; fetchedAt: string } | null
  history: Array<{
    id: string
    date: string
    rate: number
    marginPercent: number
    source: string
    note: string | null
    setBy: { id: string; name: string; username: string } | null
    createdAt: string
  }>
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

export default function CurrencyPage() {
  const [data, setData] = useState<CurrencyData | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshingTg, setRefreshingTg] = useState(false)
  const [savingRate, setSavingRate] = useState(false)
  const [deletingRate, setDeletingRate] = useState(false)
  const [savingSetting, setSavingSetting] = useState(false)

  // Form state: today manual rate
  const [manualRate, setManualRate] = useState('')
  const [manualMargin, setManualMargin] = useState('')
  const [manualNote, setManualNote] = useState('')

  // Form state: settings
  const [defaultRate, setDefaultRate] = useState('')
  const [marginPercent, setMarginPercent] = useState('')
  const [autoUpdateEnabled, setAutoUpdateEnabled] = useState(true)
  const [autoSource, setAutoSource] = useState('telegram')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<CurrencyData>('/api/admin/currency')
      setData(d)
      // sync form defaults from loaded data
      if (d.todayRate) {
        setManualRate(String(d.todayRate.rate))
        setManualMargin(String(d.todayRate.marginPercent ?? ''))
        setManualNote(d.todayRate.note ?? '')
      } else if (d.telegram) {
        setManualRate(String(d.telegram.rate))
        setManualMargin('')
        setManualNote('')
      }
      if (d.setting) {
        setDefaultRate(String(d.setting.defaultRate))
        setMarginPercent(String(d.setting.marginPercent))
        setAutoUpdateEnabled(d.setting.autoUpdateEnabled)
        setAutoSource(d.setting.autoSource || 'telegram')
      }
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری نرخ ارز')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function refreshTelegram() {
    setRefreshingTg(true)
    try {
      const res = await adminFetch('/api/admin/currency/refresh', {
        method: 'POST',
      })
      const json = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(json?.error || 'بروزرسانی ناموفق بود')
        return
      }
      toast.success(
        json?.rate
          ? `نرخ تلگرام: ${faNum(json.rate.rate)} تومان (${json.rate.status})`
          : 'نرخ دریافت نشد',
      )
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    } finally {
      setRefreshingTg(false)
    }
  }

  async function saveManualRate() {
    const rate = Number(manualRate)
    if (!Number.isFinite(rate) || rate <= 0) {
      toast.error('نرخ را به درستی وارد کنید')
      return
    }
    setSavingRate(true)
    try {
      const res = await adminFetch('/api/admin/currency/rate', {
        method: 'POST',
        json: {
          rate,
          marginPercent:
            manualMargin === '' ? undefined : Number(manualMargin),
          note: manualNote || undefined,
        },
      })
      const json = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(json?.error || 'ذخیره ناموفق بود')
        return
      }
      toast.success('نرخ امروز ثبت شد')
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    } finally {
      setSavingRate(false)
    }
  }

  async function deleteTodayRate() {
    setDeletingRate(true)
    try {
      const res = await adminFetch('/api/admin/currency/rate', {
        method: 'DELETE',
      })
      const json = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(json?.error || 'حذف ناموفق بود')
        return
      }
      toast.success('نرخ امروز حذف شد. نرخ تلگرام/پیش‌فرض اعمال می‌شود.')
      setManualRate('')
      setManualMargin('')
      setManualNote('')
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    } finally {
      setDeletingRate(false)
    }
  }

  async function saveSettings() {
    setSavingSetting(true)
    try {
      const payload: Record<string, unknown> = {}
      if (defaultRate !== '') payload.defaultRate = Number(defaultRate)
      if (marginPercent !== '') payload.marginPercent = Number(marginPercent)
      payload.autoUpdateEnabled = autoUpdateEnabled
      payload.autoSource = autoSource
      const res = await adminFetch('/api/admin/currency/setting', {
        method: 'PUT',
        json: payload,
      })
      const json = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(json?.error || 'ذخیره تنظیمات ناموفق بود')
        return
      }
      toast.success('تنظیمات ذخیره شد')
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    } finally {
      setSavingSetting(false)
    }
  }

  const tg = data?.telegram
  const eff = data?.effective
  const src = eff?.source ?? 'DEFAULT'
  const liveIrr =
    eff && eff.rate
      ? eff.rate * (1 + (eff.marginPercent || 0) / 100)
      : 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">مدیریت نرخ ارز</h1>
          <p className="text-sm text-muted-foreground">
            نرخ لحظه‌ای دلار از تلگرام، نرخ مؤثر، و تنظیمات خودکار
          </p>
        </div>
        <Button variant="outline" onClick={() => load()}>
          <RefreshCw className="h-4 w-4" />
          بروزرسانی
        </Button>
      </div>

      {/* Live Telegram banner */}
      <Card className="overflow-hidden border-emerald-200 dark:border-emerald-900">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-emerald-600" />
            <CardTitle className="text-base">نرخ لحظه‌ای تلگرام</CardTitle>
            {tg ? (
              <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200">
                {tg.status}
              </Badge>
            ) : (
              <Badge variant="secondary">در دسترس نیست</Badge>
            )}
          </div>
          <CardDescription className="text-xs">
            کانال @NerkhDollarIRT — این نرخ مستقیماً از تلگرام خوانده می‌شود.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-20 w-full" />
          ) : (
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                {tg ? (
                  <p className="text-4xl font-bold tabular-nums">
                    {faNum(tg.rate)}
                    <span className="mr-2 text-lg font-normal text-muted-foreground">
                      تومان
                    </span>
                  </p>
                ) : (
                  <p className="text-lg text-muted-foreground">—</p>
                )}
                <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {tg
                    ? `دریافت شده در ${new Intl.DateTimeFormat('fa-IR', {
                        hour: '2-digit',
                        minute: '2-digit',
                        day: '2-digit',
                        month: '2-digit',
                      }).format(new Date(tg.fetchedAt))}`
                    : 'هنوز دریافت نشده'}
                </p>
              </div>
              <Button onClick={refreshTelegram} disabled={refreshingTg}>
                {refreshingTg ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                بروزرسانی از تلگرام
              </Button>
            </div>
          )}
          {data?.setting?.autoUpdateEnabled ? (
            <p className="mt-3 text-xs text-emerald-600">
              ● به‌روزرسانی خودکار فعال — مینی‌سرویس هر ۲ دقیقه نرخ را از تلگرام
              می‌خواند و در پایگاه‌داده ذخیره می‌کند.
            </p>
          ) : (
            <p className="mt-3 text-xs text-amber-600">
              ● به‌روزرسانی خودکار غیرفعال — نرخ تلگرام فقط با کلیک دستی بروز می‌شود.
            </p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Today effective rate */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">نرخ مؤثر امروز</CardTitle>
            <CardDescription>
              نرخی که همین حالا برای محاسبه قیمت قطعات استفاده می‌شود
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-24 w-full" />
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm text-muted-foreground">تاریخ</span>
                  <span className="flex items-center gap-1 text-sm font-medium">
                    <Calendar className="h-3.5 w-3.5" />
                    {data?.date}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm text-muted-foreground">نرخ پایه</span>
                  <span className="text-xl font-bold tabular-nums">
                    {eff ? faNum(eff.rate) : '—'} تومان
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm text-muted-foreground">منبع</span>
                  <Badge className={SOURCE_BADGE[src] || ''}>
                    {SOURCE_LABEL[src] || src}
                  </Badge>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm text-muted-foreground">حاشیه سود</span>
                  <span className="text-sm font-medium">
                    {eff ? faNum(eff.marginPercent) : '—'}٪
                  </span>
                </div>
                <Separator />
                <div className="rounded-lg bg-emerald-50 p-3 text-sm dark:bg-emerald-950/30">
                  <span className="text-muted-foreground">پیش‌نمایش زنده: </span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-300">
                    ۱ دلار = {liveIrr ? faNum(liveIrr) : '—'} تومان
                  </span>
                  {eff && eff.marginPercent ? (
                    <span className="text-muted-foreground">
                      {' '}
                      (با حاشیه {faNum(eff.marginPercent)}٪)
                    </span>
                  ) : null}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Set today manual rate */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">ثبت نرخ دستی امروز</CardTitle>
            <CardDescription>
              این نرخ تا پایان امروز جایگزین نرخ تلگرام می‌شود. حذف کنید تا نرخ
              تلگرام دوباره اعمال شود.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {loading ? (
              <Skeleton className="h-40 w-full" />
            ) : (
              <>
                {data?.todayRate && (
                  <div className="flex items-center justify-between rounded-lg bg-amber-50 p-2 text-xs dark:bg-amber-950/30">
                    <span className="text-amber-700 dark:text-amber-200">
                      نرخ دستی فعلی: {faNum(data.todayRate.rate)} تومان
                    </span>
                    {data.todayRate.setBy ? (
                      <span className="text-muted-foreground">
                        توسط {data.todayRate.setBy.name}
                      </span>
                    ) : null}
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="rate">نرخ (تومان)</Label>
                    <Input
                      id="rate"
                      dir="ltr"
                      inputMode="numeric"
                      className="text-left"
                      value={manualRate}
                      onChange={(e) => setManualRate(e.target.value)}
                      placeholder="مثلاً ۲۳۰۰۰۰"
                      disabled={savingRate}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="margin">حاشیه (٪)</Label>
                    <Input
                      id="margin"
                      dir="ltr"
                      inputMode="numeric"
                      className="text-left"
                      value={manualMargin}
                      onChange={(e) => setManualMargin(e.target.value)}
                      placeholder="۳"
                      disabled={savingRate}
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="note">یادداشت (اختیاری)</Label>
                  <Textarea
                    id="note"
                    rows={2}
                    value={manualNote}
                    onChange={(e) => setManualNote(e.target.value)}
                    placeholder="مثلاً نرخ توافقی با تامین‌کننده"
                    disabled={savingRate}
                  />
                </div>
                <div className="flex items-center justify-between gap-2">
                  <Button onClick={saveManualRate} disabled={savingRate}>
                    {savingRate ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    ذخیره نرخ
                  </Button>
                  {data?.todayRate && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" disabled={deletingRate}>
                          {deletingRate ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                          حذف نرخ امروز
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            حذف نرخ دستی امروز؟
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            پس از حذف، نرخ تلگرام (یا نرخ پیش‌فرض) به‌عنوان نرخ
                            مؤثر اعمال می‌شود.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>انصراف</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={deleteTodayRate}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            حذف کن
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Default & auto settings */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-muted-foreground" />
            <CardTitle className="text-base">
              نرخ پیش‌فرض و تنظیمات خودکار
            </CardTitle>
          </div>
          <CardDescription>
            هنگامی که به‌روزرسانی خودکار فعال باشد، مینی‌سرویس و دکمه «بروزرسانی از
            تلگرام» نرخ زنده را در پایگاه‌داده ذخیره می‌کنند.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-40 w-full" />
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-1.5">
                <Label htmlFor="defaultRate">نرخ پیش‌فرض (تومان)</Label>
                <Input
                  id="defaultRate"
                  dir="ltr"
                  inputMode="numeric"
                  className="text-left"
                  value={defaultRate}
                  onChange={(e) => setDefaultRate(e.target.value)}
                  disabled={savingSetting}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="marginPercent">حاشیه سود (٪)</Label>
                <Input
                  id="marginPercent"
                  dir="ltr"
                  inputMode="numeric"
                  className="text-left"
                  value={marginPercent}
                  onChange={(e) => setMarginPercent(e.target.value)}
                  disabled={savingSetting}
                />
              </div>
              <div className="space-y-1.5">
                <Label>منبع خودکار</Label>
                <Select
                  value={autoSource}
                  onValueChange={setAutoSource}
                  disabled={savingSetting}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="تلگرام" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="telegram">تلگرام</SelectItem>
                    <SelectItem value="manual">دستی</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>به‌روزرسانی خودکار</Label>
                <div className="flex h-9 items-center gap-2">
                  <Switch
                    checked={autoUpdateEnabled}
                    onCheckedChange={setAutoUpdateEnabled}
                    disabled={savingSetting}
                  />
                  <span className="text-sm">
                    {autoUpdateEnabled ? 'فعال' : 'غیرفعال'}
                  </span>
                </div>
              </div>
              <div className="md:col-span-2 lg:col-span-4">
                <Button onClick={saveSettings} disabled={savingSetting}>
                  {savingSetting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  ذخیره تنظیمات
                </Button>
              </div>
            </div>
          )}
          <div className="mt-3 flex items-start gap-2 rounded-lg bg-muted p-3 text-xs text-muted-foreground">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <p>
              اولویت محاسبه نرخ مؤثر: <b>۱) نرخ دستی امروز</b> ←{' '}
              <b>۲) نرخ خودکار تلگرام</b> ← <b>۳) نرخ پیش‌فرض</b>.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* History table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">تاریخچه نرخ (۳۰ روز اخیر)</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <div className="thin-scrollbar max-h-96 overflow-y-auto rounded-md border">
              <Table>
                <TableHeader className="sticky top-0 bg-card">
                  <TableRow>
                    <TableHead className="text-xs">تاریخ</TableHead>
                    <TableHead className="text-xs">نرخ (تومان)</TableHead>
                    <TableHead className="text-xs">حاشیه</TableHead>
                    <TableHead className="text-xs">منبع</TableHead>
                    <TableHead className="text-xs">ثبت توسط</TableHead>
                    <TableHead className="text-xs">یادداشت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(data?.history ?? []).length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={6}
                        className="py-8 text-center text-sm text-muted-foreground"
                      >
                        رکوردی موجود نیست
                      </TableCell>
                    </TableRow>
                  ) : (
                    (data?.history ?? []).map((h) => (
                      <TableRow key={h.id}>
                        <TableCell className="text-xs font-medium" dir="ltr">
                          {h.date}
                        </TableCell>
                        <TableCell className="text-xs tabular-nums">
                          {faNum(h.rate)}
                        </TableCell>
                        <TableCell className="text-xs tabular-nums">
                          {faNum(h.marginPercent)}٪
                        </TableCell>
                        <TableCell>
                          <Badge className={SOURCE_BADGE[h.source] || ''}>
                            {SOURCE_LABEL[h.source] || h.source}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          {h.setBy?.name || '—'}
                        </TableCell>
                        <TableCell className="max-w-48 truncate text-xs text-muted-foreground">
                          {h.note || '—'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
