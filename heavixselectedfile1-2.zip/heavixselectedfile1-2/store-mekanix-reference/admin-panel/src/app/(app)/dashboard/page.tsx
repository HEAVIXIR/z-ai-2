'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  AlertCircle,
  RefreshCw,
  DollarSign,
  Clock,
  TrendingUp,
  Package,
  ShoppingCart,
  Users,
  Wrench,
  Star,
  Loader2,
  ArrowLeftCircle,
  TriangleAlert,
} from 'lucide-react'
import Link from 'next/link'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  CartesianGrid,
} from 'recharts'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { StatCard } from '@/components/admin/stat-card'
import { formatIrr } from '@/lib/currency'

const SOURCE_LABEL: Record<string, string> = {
  MANUAL: 'دستی',
  TELEGRAM: 'تلگرام',
  DEFAULT: 'پیش‌فرض',
}

const SOURCE_BADGE: Record<string, string> = {
  MANUAL: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  TELEGRAM: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  DEFAULT: 'bg-slate-100 text-slate-700 dark:bg-slate-800/50 dark:text-slate-200',
}

const PAYMENT_STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  APPROVED: 'تایید شده',
  REJECTED: 'رد شده',
  REFUNDED: 'بازگشت داده شده',
}

const PAYMENT_COLORS: Record<string, string> = {
  PENDING: '#f59e0b',
  APPROVED: '#10b981',
  REJECTED: '#ef4444',
  REFUNDED: '#64748b',
}

interface DashboardData {
  currency: {
    todayRate: number
    source: string
    margin: number
    date: string
    defaultRate: number
    autoUpdateEnabled: boolean
    autoSource: string
    lastAutoRate: number | null
    lastAutoStatus: string | null
    lastAutoFetchAt: string | null
    telegram: { rate: number; status: string; fetchedAt: string } | null
  }
  counts: {
    parts: number
    activeParts: number
    lowStock: number
    pendingPayments: number
    pendingOrders: number
    customers: number
    mechanics: number
    orders: number
    pendingReviews: number
  }
  revenueIrr: number
  salesByDay: { day: string; amount: number }[]
  paymentsByStatus: { status: string; count: number }[]
  ordersByStatus: { status: string; count: number }[]
  recentPendingPayments: Array<{
    id: string
    amountIrr: number
    method: string
    status: string
    createdAt: string
    orderNumber: string | null
    orderTotalIrr: number | null
    customerName: string | null
    customerPhone: string | null
  }>
  lowStockList: Array<{
    id: string
    name: string
    sku: string
    stock: number
    lowStockThreshold: number
    active: boolean
  }>
  recentPendingReviews: Array<{
    id: string
    rating: number
    title: string | null
    comment: string | null
    createdAt: string
    partName: string | null
    customerName: string | null
  }>
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

function shortDay(key: string): string {
  // key YYYY-MM-DD -> weekday short Persian
  const d = new Date(key + 'T00:00:00')
  try {
    return new Intl.DateTimeFormat('fa-IR', { weekday: 'short' }).format(d)
  } catch {
    return key.slice(5)
  }
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshingTg, setRefreshingTg] = useState(false)
  const [refreshingAll, setRefreshingAll] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await adminFetchJson<DashboardData>('/api/admin/dashboard')
      setData(d)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری داشبورد')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function refreshTelegram() {
    setRefreshingTg(true)
    try {
      const res = await adminFetch('/api/admin/currency/refresh', {
        method: 'POST',
      })
      const json = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(json?.error || 'بروزرسانی ناموفق بود')
        return
      }
      toast.success(
        json?.rate
          ? `نرخ تلگرام: ${faNum(json.rate.rate)} تومان (${json.rate.status})`
          : 'نرخ از تلگرام دریافت نشد',
      )
      load()
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    } finally {
      setRefreshingTg(false)
    }
  }

  const tg = data?.currency?.telegram
  const src = data?.currency.source ?? 'DEFAULT'

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">داشبورد مدیریت</h1>
          <p className="text-sm text-muted-foreground">
            نمای کلی نرخ ارز، فروش، سفارش‌ها و موجودی‌ها
          </p>
        </div>
        <Button variant="outline" onClick={() => { setRefreshingAll(true); load().finally(() => setRefreshingAll(false)) }}>
          {refreshingAll ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          بروزرسانی
        </Button>
      </div>

      {/* Live Telegram rate banner */}
      {loading && !data ? (
        <Skeleton className="h-28 w-full" />
      ) : (
        <Card className="overflow-hidden border-emerald-200 dark:border-emerald-900">
          <CardContent className="p-4 md:p-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-start gap-4">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
                  <TrendingUp className="h-7 w-7" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium text-muted-foreground">
                      نرخ لحظه‌ای تلگرام
                    </span>
                    {tg ? (
                      <Badge className="bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200">
                        {tg.status}
                      </Badge>
                    ) : (
                      <Badge variant="secondary">در دسترس نیست</Badge>
                    )}
                  </div>
                  {tg ? (
                    <p className="mt-1 text-3xl font-bold tabular-nums">
                      {faNum(tg.rate)}
                      <span className="mr-1 text-base font-normal text-muted-foreground">
                        تومان
                      </span>
                    </p>
                  ) : (
                    <p className="mt-1 text-lg text-muted-foreground">—</p>
                  )}
                  <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {tg
                      ? new Intl.DateTimeFormat('fa-IR', {
                          hour: '2-digit',
                          minute: '2-digit',
                          day: '2-digit',
                          month: '2-digit',
                        }).format(new Date(tg.fetchedAt))
                      : 'هنوز دریافت نشده'}
                  </p>
                </div>
              </div>
              <Button onClick={refreshTelegram} disabled={refreshingTg}>
                {refreshingTg ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                بروزرسانی از تلگرام
              </Button>
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 border-t pt-3 text-xs text-muted-foreground">
              <span>
                نرخ مؤثر امروز:{' '}
                <span className="font-bold text-foreground">
                  {data ? faNum(data.currency.todayRate) : '—'} تومان
                </span>
              </span>
              <span>
                منبع:{' '}
                <Badge
                  variant="secondary"
                  className={SOURCE_BADGE[src] || ''}
                >
                  {SOURCE_LABEL[src] || src}
                </Badge>
              </span>
              <span>
                حاشیه سود:{' '}
                <span className="font-bold text-foreground">
                  {data ? faNum(data.currency.margin) : '—'}٪
                </span>
              </span>
              {data?.currency.autoUpdateEnabled ? (
                <span className="text-emerald-600">
                  ● به‌روزرسانی خودکار فعال
                </span>
              ) : (
                <span className="text-amber-600">● به‌روزرسانی خودکار غیرفعال</span>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stat cards */}
      {loading && !data ? (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <StatCard
            title="درآمد کل (تایید شده)"
            value={formatIrr(data?.revenueIrr ?? 0)}
            icon={DollarSign}
            accent="emerald"
          />
          <StatCard
            title="پرداخت‌های در انتظار"
            value={faNum(data?.counts.pendingPayments ?? 0)}
            sub="نیازمند بررسی"
            icon={Clock}
            accent="amber"
          />
          <StatCard
            title="سفارش‌های در انتظار"
            value={faNum(data?.counts.pendingOrders ?? 0)}
            icon={ShoppingCart}
            accent="violet"
          />
          <StatCard
            title="قطعات فعال"
            value={faNum(data?.counts.activeParts ?? 0)}
            sub={`از ${faNum(data?.counts.parts ?? 0)} قطعه`}
            icon={Package}
            accent="cyan"
          />
          <StatCard
            title="موجودی کم"
            value={faNum(data?.counts.lowStock ?? 0)}
            sub="stock ≤ ۵"
            icon={TriangleAlert}
            accent="rose"
          />
          <StatCard
            title="مشتریان"
            value={faNum(data?.counts.customers ?? 0)}
            icon={Users}
            accent="slate"
          />
          <StatCard
            title="مکانیک‌ها"
            value={faNum(data?.counts.mechanics ?? 0)}
            icon={Wrench}
            accent="slate"
          />
          <StatCard
            title="نظرات در انتظار"
            value={faNum(data?.counts.pendingReviews ?? 0)}
            sub="نیازمند تایید"
            icon={Star}
            accent="amber"
          />
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">فروش ۷ روز اخیر (تایید شده)</CardTitle>
          </CardHeader>
          <CardContent>
            {loading && !data ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={(data?.salesByDay ?? []).map((d) => ({ ...d, label: shortDay(d.day) }))}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0 0 / 0.5)" />
                  <XAxis dataKey="label" tick={{ fontSize: 12 }} reversed />
                  <YAxis
                    tick={{ fontSize: 11 }}
                    tickFormatter={(v) =>
                      v >= 1_000_000
                        ? `${(v / 1_000_000).toFixed(1)}م`
                        : v >= 1000
                          ? `${(v / 1000).toFixed(0)}ه`
                          : String(v)
                    }
                  />
                  <Tooltip
                    formatter={(v: number) => [formatIrr(v), 'فروش']}
                    labelStyle={{ fontSize: 12 }}
                  />
                  <Bar dataKey="amount" fill="#10b981" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">پرداخت‌ها بر اساس وضعیت</CardTitle>
          </CardHeader>
          <CardContent>
            {loading && !data ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={(data?.paymentsByStatus ?? []).map((p) => ({
                      ...p,
                      label: PAYMENT_STATUS_LABEL[p.status] || p.status,
                    }))}
                    dataKey="count"
                    nameKey="label"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={(entry) => `${entry.label}: ${entry.count}`}
                  >
                    {(data?.paymentsByStatus ?? []).map((entry) => (
                      <Cell
                        key={entry.status}
                        fill={PAYMENT_COLORS[entry.status] || '#94a3b8'}
                      />
                    ))}
                  </Pie>
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Pending payments + low stock */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">پرداخت‌های در انتظار</CardTitle>
            <Link
              href="/payments"
              className="text-xs text-emerald-600 hover:underline"
            >
              مشاهده همه
            </Link>
          </CardHeader>
          <CardContent>
            {loading && !data ? (
              <Skeleton className="h-40 w-full" />
            ) : (data?.recentPendingPayments ?? []).length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                پرداخت در انتظاری وجود ندارد
              </p>
            ) : (
              <ul className="thin-scrollbar max-h-80 divide-y overflow-y-auto">
                {(data?.recentPendingPayments ?? []).map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">
                        {p.customerName || 'مشتری ناشناس'}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        سفارش #{p.orderNumber || '—'} · {p.customerPhone || ''}
                      </p>
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold tabular-nums">
                        {formatIrr(p.amountIrr)}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {new Intl.DateTimeFormat('fa-IR', {
                          month: '2-digit',
                          day: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit',
                        }).format(new Date(p.createdAt))}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">موجودی کم</CardTitle>
            <Link href="/parts" className="text-xs text-emerald-600 hover:underline">
              مدیریت قطعات
            </Link>
          </CardHeader>
          <CardContent>
            {loading && !data ? (
              <Skeleton className="h-40 w-full" />
            ) : (data?.lowStockList ?? []).length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                موجودی همه قطعات کافی است
              </p>
            ) : (
              <ul className="thin-scrollbar max-h-80 divide-y overflow-y-auto">
                {(data?.lowStockList ?? []).map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{p.name}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {p.sku}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {p.stock === 0 ? (
                        <Badge variant="destructive">ناموجود</Badge>
                      ) : (
                        <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200">
                          {faNum(p.stock)} عدد
                        </Badge>
                      )}
                      {!p.active && (
                        <Badge variant="secondary">غیرفعال</Badge>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent pending reviews */}
      <Card>
        <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">نظرات در انتظار تایید</CardTitle>
          <Link href="/reviews" className="text-xs text-emerald-600 hover:underline">
            مشاهده همه
          </Link>
        </CardHeader>
        <CardContent>
          {loading && !data ? (
            <Skeleton className="h-32 w-full" />
          ) : (data?.recentPendingReviews ?? []).length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              نظری در انتظار تایید نیست
            </p>
          ) : (
            <ul className="thin-scrollbar max-h-72 divide-y overflow-y-auto">
              {(data?.recentPendingReviews ?? []).map((r) => (
                <li key={r.id} className="py-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-sm font-medium">
                      {r.partName || 'قطعه حذف شده'}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-amber-600">
                      {Array.from({ length: r.rating }).map((_, i) => (
                        <Star key={i} className="h-3 w-3 fill-current" />
                      ))}
                    </span>
                  </div>
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                    {r.title ? `${r.title} — ` : ''}
                    {r.comment || 'بدون متن'}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {r.customerName || '—'} ·{' '}
                    {new Intl.DateTimeFormat('fa-IR', {
                      month: '2-digit',
                      day: '2-digit',
                    }).format(new Date(r.createdAt))}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// Avoid unused-import warning
void AlertCircle
void ArrowLeftCircle
