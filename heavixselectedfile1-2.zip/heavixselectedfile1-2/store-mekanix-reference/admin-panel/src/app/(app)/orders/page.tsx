'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Search,
  RefreshCw,
  Loader2,
  Eye,
  Package,
  Truck,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch, adminFetchJson } from '@/lib/client'
import { formatIrr, formatUsd } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Card,
  CardContent,
} from '@/components/ui/card'

// ---- Status labels (Persian, RTL) ----
const ORDER_STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  CONFIRMED: 'تایید شده',
  PROCESSING: 'در حال پردازش',
  SHIPPED: 'ارسال شده',
  DELIVERED: 'تحویل شده',
  CANCELLED: 'لغو شده',
}
const ORDER_STATUS_BADGE: Record<string, string> = {
  PENDING: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  CONFIRMED: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  PROCESSING: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-200',
  SHIPPED: 'bg-violet-100 text-violet-800 dark:bg-violet-900/40 dark:text-violet-200',
  DELIVERED: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  CANCELLED: 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200',
}
const PAYMENT_STATUS_LABEL: Record<string, string> = {
  UNPAID: 'پرداخت‌نشده',
  PENDING: 'در انتظار',
  PAID: 'پرداخت شده',
  REFUNDED: 'بازگشت',
}
const PAYMENT_STATUS_BADGE: Record<string, string> = {
  UNPAID: 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200',
  PENDING: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
  PAID: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
  REFUNDED: 'bg-slate-100 text-slate-700 dark:bg-slate-800/40 dark:text-slate-200',
}
const SHIPMENT_STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  DISPATCHED: 'ارسال شد',
  IN_TRANSIT: 'در مسیر',
  DELIVERED: 'تحویل شد',
}

interface CustomerRef {
  id: string
  name: string
  family: string
  phone: string
}
interface MechanicRef {
  id: string
  name: string
  family: string
  shopName?: string | null
}
interface OrderItem {
  id: string
  partId: string
  partNameSnapshot: string
  quantity: number
  unitPriceUsd: number
  unitPriceIrr: number
  lineTotalUsd: number
  lineTotalIrr: number
  part?: { id: string; name: string; sku: string } | null
}
interface PaymentRef {
  id: string
  status: string
  amountIrr: number
  method: string
  gateway?: string | null
  refId?: string | null
  createdAt: string
}
interface ShipmentRef {
  id: string
  carrier: string
  trackingCode?: string | null
  status: string
  shippedAt?: string | null
  deliveredAt?: string | null
  note?: string | null
}
interface Order {
  id: string
  orderNumber: string
  status: string
  paymentStatus: string
  subtotalUsd: number
  shippingUsd: number
  discountIrr: number
  totalUsd: number
  totalIrr: number
  currencyRateAtOrder: number
  marginPercentAtOrder: number
  couponCode?: string | null
  shippingAddress?: string | null
  notes?: string | null
  createdAt: string
  customerId: string
  mechanicId?: string | null
  customer: CustomerRef
  mechanic?: MechanicRef | null
  items: OrderItem[]
  payments: PaymentRef[]
  shipment?: ShipmentRef | null
}

interface OrderDetail extends Order {
  customer: CustomerRef & {
    nationalCode?: string | null
    address?: string | null
    status?: string
  }
  mechanic?: MechanicRef & {
    specialty?: string | null
    city?: string | null
  }
  items: Array<
    OrderItem & {
      part?: { id: string; name: string; sku: string } | null
    }
  >
  payments: Array<
    PaymentRef & {
      reviewedBy?: { id: string; name: string } | null
    }
  >
  shipment: ShipmentRef | null
}

interface OrdersListResp {
  orders: Order[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}

interface MechanicOption {
  id: string
  name: string
  family: string
  shopName?: string | null
}

function faDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString('fa-IR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return iso
  }
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(20)
  const [totalPages, setTotalPages] = useState(1)
  const [q, setQ] = useState('')
  const [fStatus, setFStatus] = useState<string>('')
  const [fPayment, setFPayment] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [refreshKey, setRefreshKey] = useState(0)

  const [detail, setDetail] = useState<OrderDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)

  const [mechanics, setMechanics] = useState<MechanicOption[]>([])

  // Editable fields inside the dialog
  const [edStatus, setEdStatus] = useState<string>('')
  const [edMechanicId, setEdMechanicId] = useState<string>('')
  const [edNotes, setEdNotes] = useState<string>('')
  const [saving, setSaving] = useState(false)

  // Shipment fields
  const [shCarrier, setShCarrier] = useState<string>('پست')
  const [shTrackingCode, setShTrackingCode] = useState<string>('')
  const [shStatus, setShStatus] = useState<string>('PENDING')
  const [shNote, setShNote] = useState<string>('')
  const [savingShipment, setSavingShipment] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (q) params.set('q', q)
      if (fStatus) params.set('status', fStatus)
      if (fPayment) params.set('paymentStatus', fPayment)
      params.set('page', String(page))
      params.set('pageSize', String(pageSize))
      const d = await adminFetchJson<OrdersListResp>(
        `/api/admin/orders?${params.toString()}`,
      )
      setOrders(d.orders)
      setTotal(d.total)
      setTotalPages(d.totalPages)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری سفارش‌ها')
    } finally {
      setLoading(false)
    }
  }, [q, fStatus, fPayment, page, pageSize])

  useEffect(() => {
    void load()
  }, [load, refreshKey])

  // Load mechanics list for assignment
  useEffect(() => {
    void (async () => {
      try {
        const d = await adminFetchJson<{ mechanics: MechanicOption[] }>(
          '/api/admin/mechanics?pageSize=100',
        )
        setMechanics(d.mechanics ?? [])
      } catch {
        // silent
      }
    })()
  }, [])

  const openDetail = useCallback(async (order: Order) => {
    setDetailOpen(true)
    setDetail(null)
    setDetailLoading(true)
    try {
      const d = await adminFetchJson<OrderDetail>(
        `/api/admin/orders/${order.id}`,
      )
      setDetail(d)
      setEdStatus(d.status)
      setEdMechanicId(d.mechanicId ?? '__none__')
      setEdNotes(d.notes ?? '')
      if (d.shipment) {
        setShCarrier(d.shipment.carrier)
        setShTrackingCode(d.shipment.trackingCode ?? '')
        setShStatus(d.shipment.status)
        setShNote(d.shipment.note ?? '')
      } else {
        setShCarrier('پست')
        setShTrackingCode('')
        setShStatus('PENDING')
        setShNote('')
      }
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری جزئیات')
      setDetailOpen(false)
    } finally {
      setDetailLoading(false)
    }
  }, [])

  const saveOrder = useCallback(async () => {
    if (!detail) return
    setSaving(true)
    try {
      const body: Record<string, unknown> = {
        status: edStatus,
        mechanicId: edMechanicId === '__none__' ? null : edMechanicId,
        notes: edNotes,
      }
      const d = await adminFetchJson<{ ok: boolean; order: Order }>(
        `/api/admin/orders/${detail.id}`,
        { method: 'PATCH', json: body },
      )
      toast.success('سفارش بروزرسانی شد')
      setDetail({ ...detail, ...d.order })
      setRefreshKey((k) => k + 1)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره')
    } finally {
      setSaving(false)
    }
  }, [detail, edStatus, edMechanicId, edNotes])

  const saveShipment = useCallback(async () => {
    if (!detail) return
    setSavingShipment(true)
    try {
      const body = {
        carrier: shCarrier,
        trackingCode: shTrackingCode || null,
        status: shStatus,
        note: shNote || null,
      }
      const method = detail.shipment ? 'PUT' : 'POST'
      const d = await adminFetchJson<{ ok: boolean; shipment: ShipmentRef }>(
        `/api/admin/orders/${detail.id}/shipment`,
        { method, json: body },
      )
      toast.success(
        method === 'POST' ? 'محموله ثبت شد' : 'محموله بروزرسانی شد',
      )
      setDetail({ ...detail, shipment: d.shipment })
      setRefreshKey((k) => k + 1)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در ذخیره محموله')
    } finally {
      setSavingShipment(false)
    }
  }, [detail, shCarrier, shTrackingCode, shStatus, shNote])

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">سفارش‌ها</h1>
          <p className="text-sm text-muted-foreground">
            مدیریت سفارش‌ها، تخصیص مکانیک و ثبت محموله
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setRefreshKey((k) => k + 1)}>
          <RefreshCw className="ml-2 h-4 w-4" />
          بروزرسانی
        </Button>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div className="relative">
              <Search className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => {
                  setQ(e.target.value)
                  setPage(1)
                }}
                placeholder="شماره سفارش، نام یا موبایل مشتری..."
                className="pr-9"
              />
            </div>
            <Select
              value={fStatus}
              onValueChange={(v) => {
                setFStatus(v === '__all__' ? '' : v)
                setPage(1)
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="وضعیت سفارش" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه وضعیت‌ها</SelectItem>
                {Object.entries(ORDER_STATUS_LABEL).map(([k, v]) => (
                  <SelectItem key={k} value={k}>
                    {v}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={fPayment}
              onValueChange={(v) => {
                setFPayment(v === '__all__' ? '' : v)
                setPage(1)
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="وضعیت پرداخت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه وضعیت‌ها</SelectItem>
                {Object.entries(PAYMENT_STATUS_LABEL).map(([k, v]) => (
                  <SelectItem key={k} value={k}>
                    {v}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex items-center justify-end text-sm text-muted-foreground">
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <span>مجموع: {faNum(total)} سفارش</span>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto thin-scrollbar">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>شماره سفارش</TableHead>
                  <TableHead>مشتری</TableHead>
                  <TableHead>مبلغ</TableHead>
                  <TableHead>آیتم</TableHead>
                  <TableHead>مکانیک</TableHead>
                  <TableHead>وضعیت سفارش</TableHead>
                  <TableHead>وضعیت پرداخت</TableHead>
                  <TableHead>محموله</TableHead>
                  <TableHead>تاریخ</TableHead>
                  <TableHead className="text-left">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={`sk-${i}`}>
                      <TableCell colSpan={10}>
                        <Skeleton className="h-6 w-full" />
                      </TableCell>
                    </TableRow>
                  ))
                ) : orders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="py-12 text-center text-muted-foreground">
                      <Package className="mx-auto mb-2 h-8 w-8 opacity-50" />
                      سفارشی یافت نشد
                    </TableCell>
                  </TableRow>
                ) : (
                  orders.map((o) => {
                    const paidPayment = o.payments.find((p) => p.status === 'APPROVED')
                    const itemCount = o.items.reduce((s, i) => s + i.quantity, 0)
                    return (
                      <TableRow key={o.id} className="cursor-pointer hover:bg-muted/50" onClick={() => openDetail(o)}>
                        <TableCell className="font-mono font-medium ltr-content" dir="ltr">
                          {o.orderNumber}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium">
                              {o.customer.name} {o.customer.family}
                            </span>
                            <span className="text-xs text-muted-foreground ltr-content" dir="ltr">
                              {o.customer.phone}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium tabular-nums">{formatIrr(o.totalIrr)}</span>
                            <span className="text-xs text-muted-foreground ltr-content" dir="ltr">
                              {formatUsd(o.totalUsd)}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center tabular-nums">{faNum(itemCount)}</TableCell>
                        <TableCell>
                          {o.mechanic ? (
                            <span className="text-sm">
                              {o.mechanic.name} {o.mechanic.family}
                              {o.mechanic.shopName ? (
                                <span className="block text-xs text-muted-foreground">
                                  {o.mechanic.shopName}
                                </span>
                              ) : null}
                            </span>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge className={ORDER_STATUS_BADGE[o.status] ?? ''} variant="outline">
                            {ORDER_STATUS_LABEL[o.status] ?? o.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={PAYMENT_STATUS_BADGE[o.paymentStatus] ?? ''} variant="outline">
                            {PAYMENT_STATUS_LABEL[o.paymentStatus] ?? o.paymentStatus}
                          </Badge>
                          {paidPayment ? (
                            <span className="block text-xs text-muted-foreground mt-1">
                              {paidPayment.method === 'GATEWAY'
                                ? `درگاه${paidPayment.refId ? ` · ${paidPayment.refId}` : ''}`
                                : ''}
                            </span>
                          ) : null}
                        </TableCell>
                        <TableCell>
                          {o.shipment ? (
                            <div className="flex items-center gap-1.5 text-xs">
                              <Truck className="h-3.5 w-3.5 text-muted-foreground" />
                              <span>{SHIPMENT_STATUS_LABEL[o.shipment.status] ?? o.shipment.status}</span>
                              <span className="text-muted-foreground">· {o.shipment.carrier}</span>
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                          {faDate(o.createdAt)}
                        </TableCell>
                        <TableCell className="text-left">
                          <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); openDetail(o) }}>
                            <Eye className="ml-1 h-4 w-4" />
                            مشاهده
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 ? (
            <div className="flex items-center justify-between border-t p-3">
              <span className="text-xs text-muted-foreground">
                صفحه {faNum(page)} از {faNum(totalPages)}
              </span>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  <ChevronRight className="h-4 w-4" />
                  قبلی
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                >
                  بعدی
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {/* Order detail dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[92vh] overflow-y-auto thin-scrollbar">
          {detailLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : detail ? (
            <div className="space-y-5">
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2">
                  <span className="ltr-content" dir="ltr">{detail.orderNumber}</span>
                  <Badge className={ORDER_STATUS_BADGE[detail.status] ?? ''} variant="outline">
                    {ORDER_STATUS_LABEL[detail.status] ?? detail.status}
                  </Badge>
                  <Badge className={PAYMENT_STATUS_BADGE[detail.paymentStatus] ?? ''} variant="outline">
                    {PAYMENT_STATUS_LABEL[detail.paymentStatus] ?? detail.paymentStatus}
                  </Badge>
                </DialogTitle>
                <DialogDescription>جزئیات سفارش، آیتم‌ها و محموله</DialogDescription>
              </DialogHeader>

              {/* Customer & meta */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <div className="rounded-md border p-3">
                  <p className="mb-1 text-xs font-medium text-muted-foreground">مشتری</p>
                  <p className="font-medium">
                    {detail.customer.name} {detail.customer.family}
                  </p>
                  <p className="text-xs text-muted-foreground ltr-content" dir="ltr">
                    {detail.customer.phone}
                  </p>
                  {detail.customer.nationalCode ? (
                    <p className="text-xs text-muted-foreground">
                      کد ملی: <span className="ltr-content" dir="ltr">{detail.customer.nationalCode}</span>
                    </p>
                  ) : null}
                </div>
                <div className="rounded-md border p-3">
                  <p className="mb-1 text-xs font-medium text-muted-foreground">آدرس ارسال</p>
                  <p className="text-sm">{detail.shippingAddress || '—'}</p>
                  {detail.couponCode ? (
                    <p className="mt-2 text-xs">
                      کد تخفیف:{' '}
                      <Badge variant="secondary" className="ltr-content" dir="ltr">
                        {detail.couponCode}
                      </Badge>
                    </p>
                  ) : null}
                </div>
              </div>

              {/* Items table */}
              <div className="rounded-md border">
                <div className="overflow-x-auto thin-scrollbar">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>قطعه</TableHead>
                        <TableHead className="text-center">تعداد</TableHead>
                        <TableHead className="text-left">قیمت واحد ($)</TableHead>
                        <TableHead className="text-left">قیمت واحد (ت)</TableHead>
                        <TableHead className="text-left">جمع ردیف</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detail.items.map((it) => (
                        <TableRow key={it.id}>
                          <TableCell>
                            <span className="font-medium">{it.partNameSnapshot}</span>
                            {it.part ? (
                              <span className="block text-xs text-muted-foreground ltr-content" dir="ltr">
                                {it.part.sku}
                              </span>
                            ) : null}
                          </TableCell>
                          <TableCell className="text-center tabular-nums">{faNum(it.quantity)}</TableCell>
                          <TableCell className="text-left tabular-nums ltr-content" dir="ltr">{formatUsd(it.unitPriceUsd)}</TableCell>
                          <TableCell className="text-left tabular-nums">{formatIrr(it.unitPriceIrr)}</TableCell>
                          <TableCell className="text-left tabular-nums font-medium">{formatIrr(it.lineTotalIrr)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Totals */}
              <div className="rounded-md border p-3 space-y-1.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">جمع کل (USD)</span>
                  <span className="tabular-nums ltr-content" dir="ltr">{formatUsd(detail.subtotalUsd)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ارسال (USD)</span>
                  <span className="tabular-nums ltr-content" dir="ltr">{formatUsd(detail.shippingUsd)}</span>
                </div>
                {detail.discountIrr > 0 ? (
                  <div className="flex justify-between text-emerald-700 dark:text-emerald-400">
                    <span>تخفیف (تومان)</span>
                    <span className="tabular-nums">−{formatIrr(detail.discountIrr)}</span>
                  </div>
                ) : null}
                <Separator className="my-2" />
                <div className="flex justify-between text-base font-semibold">
                  <span>مبلغ نهایی</span>
                  <div className="flex flex-col items-end">
                    <span className="tabular-nums">{formatIrr(detail.totalIrr)}</span>
                    <span className="text-xs text-muted-foreground ltr-content" dir="ltr">{formatUsd(detail.totalUsd)}</span>
                  </div>
                </div>
                <p className="pt-1 text-xs text-muted-foreground">
                  نرخ ارز در زمان سفارش: <span className="tabular-nums">{faNum(detail.currencyRateAtOrder)}</span> تومان
                  · حاشیه: <span className="tabular-nums">{faNum(detail.marginPercentAtOrder)}</span>٪
                </p>
              </div>

              {/* Payments list */}
              {detail.payments.length > 0 ? (
                <div className="rounded-md border p-3">
                  <p className="mb-2 text-xs font-medium text-muted-foreground">پرداخت‌ها</p>
                  <div className="space-y-1.5 text-sm">
                    {detail.payments.map((p) => (
                      <div key={p.id} className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Badge className={PAYMENT_STATUS_BADGE[p.status] ?? ''} variant="outline">
                            {PAYMENT_STATUS_LABEL[p.status] ?? p.status}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {p.method === 'GATEWAY'
                              ? `درگاه آنلاین${p.gateway ? ` (${p.gateway})` : ''}`
                              : p.method === 'CARD'
                                ? 'کارت'
                                : p.method === 'WALLET'
                                  ? 'کیف پول'
                                  : p.method === 'CASH'
                                    ? 'نقدی'
                                    : p.method}
                          </span>
                          {p.refId ? (
                            <span className="text-xs ltr-content" dir="ltr">· refId: {p.refId}</span>
                          ) : null}
                        </div>
                        <span className="tabular-nums">{formatIrr(p.amountIrr)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}

              {/* Editable: status + mechanic + notes */}
              <div className="rounded-md border p-3 space-y-3">
                <p className="text-xs font-medium text-muted-foreground">مدیریت سفارش</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">وضعیت سفارش</Label>
                    <Select value={edStatus} onValueChange={setEdStatus}>
                      <SelectTrigger className="mt-1 w-full">
                        <SelectValue placeholder="وضعیت" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(ORDER_STATUS_LABEL).map(([k, v]) => (
                          <SelectItem key={k} value={k}>
                            {v}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">مکانیک</Label>
                    <Select value={edMechanicId} onValueChange={setEdMechanicId}>
                      <SelectTrigger className="mt-1 w-full">
                        <SelectValue placeholder="بدون مکانیک" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">— بدون مکانیک —</SelectItem>
                        {mechanics.map((m) => (
                          <SelectItem key={m.id} value={m.id}>
                            {m.name} {m.family}
                            {m.shopName ? ` · ${m.shopName}` : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label className="text-xs">یادداشت داخلی</Label>
                  <Textarea
                    value={edNotes}
                    onChange={(e) => setEdNotes(e.target.value)}
                    placeholder="یادداشت‌های داخلی سفارش..."
                    className="mt-1 min-h-[70px]"
                  />
                </div>
                <Button size="sm" disabled={saving} onClick={saveOrder}>
                  {saving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
                  ذخیره تغییرات
                </Button>
              </div>

              {/* Shipment section */}
              <div className="rounded-md border p-3 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium text-muted-foreground">محموله (ارسال)</p>
                  {detail.shipment ? (
                    <Badge variant="outline" className={ORDER_STATUS_BADGE[detail.shipment.status === 'DELIVERED' ? 'DELIVERED' : 'SHIPPED'] ?? ''}>
                      {SHIPMENT_STATUS_LABEL[detail.shipment.status] ?? detail.shipment.status}
                    </Badge>
                  ) : (
                    <span className="text-xs text-muted-foreground">بدون محموله</span>
                  )}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">حامل</Label>
                    <Select value={shCarrier} onValueChange={setShCarrier}>
                      <SelectTrigger className="mt-1 w-full">
                        <SelectValue placeholder="حامل" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="پست">پست</SelectItem>
                        <SelectItem value="تیپاکس">تیپاکس</SelectItem>
                        <SelectItem value="چاپار">چاپار</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">کد رهگیری</Label>
                    <Input
                      value={shTrackingCode}
                      onChange={(e) => setShTrackingCode(e.target.value)}
                      placeholder="مثال: 1234567890"
                      className="mt-1 ltr-content"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">وضعیت محموله</Label>
                    <Select value={shStatus} onValueChange={setShStatus}>
                      <SelectTrigger className="mt-1 w-full">
                        <SelectValue placeholder="وضعیت" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(SHIPMENT_STATUS_LABEL).map(([k, v]) => (
                          <SelectItem key={k} value={k}>
                            {v}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">یادداشت محموله</Label>
                    <Input
                      value={shNote}
                      onChange={(e) => setShNote(e.target.value)}
                      placeholder="اختیاری..."
                      className="mt-1"
                    />
                  </div>
                </div>
                <Button size="sm" variant="secondary" disabled={savingShipment} onClick={saveShipment}>
                  {savingShipment ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Truck className="ml-2 h-4 w-4" />}
                  {detail.shipment ? 'بروزرسانی محموله' : 'ثبت محموله'}
                </Button>
                {detail.shipment?.deliveredAt ? (
                  <p className="flex items-center gap-1.5 text-xs text-emerald-700 dark:text-emerald-400">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    تحویل شده در {faDate(detail.shipment.deliveredAt)}
                  </p>
                ) : null}
              </div>
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">سفارش یافت نشد</div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
