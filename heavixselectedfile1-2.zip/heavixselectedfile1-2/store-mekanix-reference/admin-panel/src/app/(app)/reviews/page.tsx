'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  RefreshCw,
  Loader2,
  Star,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Search,
  Clock,
} from 'lucide-react'
import { toast } from 'sonner'
import { adminFetchJson } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'

interface ReviewPart {
  id: string
  name: string
  sku: string
}
interface ReviewCustomer {
  id: string
  name: string
  family: string
  phone: string
  fullName: string
}
interface Review {
  id: string
  partId: string
  customerId: string
  rating: number
  title: string | null
  comment: string | null
  approved: boolean
  reviewedById: string | null
  createdAt: string
  part: ReviewPart | null
  customer: ReviewCustomer | null
}
interface ReviewsResp {
  reviews: Review[]
  total: number
  page: number
  pageSize: number
}

function faNum(n: number | null | undefined): string {
  if (n == null) return '—'
  return new Intl.NumberFormat('fa-IR').format(n)
}

function faDateTime(s: string): string {
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(s))
  } catch {
    return s
  }
}

export default function ReviewsPage() {
  const [status, setStatus] = useState<'pending' | 'approved' | 'all'>('pending')
  const [reviews, setReviews] = useState<Review[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [working, setWorking] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ status })
      if (q) params.set('q', q)
      const d = await adminFetchJson<ReviewsResp>(`/api/admin/reviews?${params.toString()}`)
      setReviews(d.reviews || [])
      setTotal(d.total || 0)
    } catch (err) {
      toast.error((err as Error).message || 'خطا در بارگذاری نظرات')
    } finally {
      setLoading(false)
    }
  }, [status, q])

  useEffect(() => {
    load()
  }, [load])

  async function approve(r: Review) {
    setWorking(r.id)
    try {
      await adminFetchJson(`/api/admin/reviews/${r.id}`, {
        method: 'PATCH',
        json: { action: 'approve' },
      })
      toast.success('نظر تایید شد')
      // If we're on "pending" tab, remove it from view; otherwise update locally
      setReviews((prev) =>
        status === 'pending' ? prev.filter((x) => x.id !== r.id) : prev.map((x) => (x.id === r.id ? { ...x, approved: true } : x)),
      )
      setTotal((t) => (status === 'pending' ? Math.max(0, t - 1) : t))
    } catch (err) {
      toast.error((err as Error).message || 'خطا در تایید نظر')
    } finally {
      setWorking(null)
    }
  }

  async function reject(r: Review) {
    setWorking(r.id)
    try {
      await adminFetchJson(`/api/admin/reviews/${r.id}`, {
        method: 'PATCH',
        json: { action: 'reject' },
      })
      toast.success('نظر رد شد')
      setReviews((prev) =>
        status === 'pending' ? prev.filter((x) => x.id !== r.id) : prev.map((x) => (x.id === r.id ? { ...x, approved: false } : x)),
      )
      setTotal((t) => (status === 'pending' ? Math.max(0, t - 1) : t))
    } catch (err) {
      toast.error((err as Error).message || 'خطا در رد نظر')
    } finally {
      setWorking(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">نظرات مشتریان</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            بررسی و تایید نظرات ثبت‌شده برای قطعات
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          بروزرسانی
        </Button>
      </div>

      <Tabs value={status} onValueChange={(v) => setStatus(v as typeof status)}>
        <TabsList>
          <TabsTrigger value="pending" className="gap-2">
            در انتظار تایید
          </TabsTrigger>
          <TabsTrigger value="approved" className="gap-2">
            تایید شده
          </TabsTrigger>
          <TabsTrigger value="all" className="gap-2">
            همه
          </TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="relative max-w-md">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="جستجو در نام، عنوان، متن نظر یا تلفن مشتری..."
          className="pr-9"
        />
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center text-muted-foreground">
            <MessageSquare className="h-10 w-10 opacity-30" />
            <p className="text-sm">
              {status === 'pending'
                ? 'هیچ نظری در انتظار بررسی وجود ندارد'
                : status === 'approved'
                  ? 'هیچ نظری تایید نشده است'
                  : 'هیچ نظری ثبت نشده است'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            {faNum(total)} نظر یافت شد
          </p>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto thin-scrollbar pr-1">
            {reviews.map((r) => (
              <Card key={r.id}>
                <CardContent className="p-4 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <RatingStars value={r.rating} />
                        {r.approved ? (
                          <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 hover:bg-emerald-100 gap-1">
                            <CheckCircle2 className="h-3 w-3" /> تایید شده
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="gap-1 text-amber-700 dark:text-amber-400">
                            <Clock className="h-3 w-3" /> در انتظار
                          </Badge>
                        )}
                      </div>
                      {r.title ? (
                        <p className="font-medium text-sm">{r.title}</p>
                      ) : null}
                      {r.comment ? (
                        <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
                          {r.comment}
                        </p>
                      ) : (
                        <p className="text-sm text-muted-foreground italic">بدون متن</p>
                      )}
                    </div>
                    <div className="flex flex-col gap-2 shrink-0">
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/30 dark:text-emerald-300 dark:border-emerald-900"
                        onClick={() => approve(r)}
                        disabled={!!working || r.approved}
                      >
                        {working === r.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <CheckCircle2 className="h-4 w-4" />
                        )}
                        تایید
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100 dark:bg-rose-950/30 dark:text-rose-300 dark:border-rose-900"
                        onClick={() => reject(r)}
                        disabled={!!working}
                      >
                        <XCircle className="h-4 w-4" />
                        رد
                      </Button>
                    </div>
                  </div>
                  <div className="border-t pt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                    <div className="flex flex-wrap items-center gap-3">
                      <span>
                        <span className="text-foreground/80">قطعه:</span>{' '}
                        {r.part?.name ?? '—'}
                      </span>
                      <span>
                        <span className="text-foreground/80">مشتری:</span>{' '}
                        {r.customer?.fullName ?? '—'}
                        {r.customer?.phone ? (
                          <span dir="ltr" className="ms-1 font-mono">
                            ({r.customer.phone})
                          </span>
                        ) : null}
                      </span>
                    </div>
                    <span>{faDateTime(r.createdAt)}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function RatingStars({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`امتیاز ${value} از ۵`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${
            i < value
              ? 'fill-amber-400 text-amber-400'
              : 'text-muted-foreground/40'
          }`}
        />
      ))}
      <span className="ms-1 text-xs text-muted-foreground tabular-nums">{faNum(value)}/۵</span>
    </div>
  )
}
