import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const url = new URL(req.url)
    const action = url.searchParams.get('action')?.trim() || ''
    const entity = url.searchParams.get('entity')?.trim() || ''
    const q = url.searchParams.get('q')?.trim() || ''
    const page = Math.max(1, Number(url.searchParams.get('page')) || 1)
    const pageSize = Math.min(
      100,
      Math.max(1, Number(url.searchParams.get('pageSize')) || 50),
    )

    const where: Record<string, unknown> = {}
    if (action) where.action = action
    if (entity) where.entity = entity
    if (q) {
      where.adminName = { contains: q }
    }

    const [total, logs] = await Promise.all([
      db.auditLog.count({ where }),
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { admin: { select: { username: true } } },
      }),
    ])

    return NextResponse.json({
      logs: logs.map((l) => ({
        id: l.id,
        adminId: l.adminId,
        adminName: l.adminName,
        adminUsername: l.admin?.username ?? null,
        action: l.action,
        entity: l.entity,
        entityId: l.entityId,
        before: l.before,
        after: l.after,
        ipAddress: l.ipAddress,
        createdAt: l.createdAt,
      })),
      total,
      page,
      pageSize,
    })
  } catch (err) {
    console.error('[audit] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
