import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export async function GET() {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const coupons = await db.coupon.findMany({
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({
      coupons: coupons.map((c) => ({
        id: c.id,
        code: c.code,
        type: c.type,
        value: c.value,
        expiresAt: c.expiresAt,
        usageLimit: c.usageLimit,
        usedCount: c.usedCount,
        active: c.active,
        minOrderIrr: c.minOrderIrr,
        createdAt: c.createdAt,
      })),
    })
  } catch (err) {
    console.error('[coupons] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const code = String(body?.code ?? '').trim().toUpperCase()
    const type = String(body?.type ?? '').toUpperCase() === 'FIXED' ? 'FIXED' : 'PERCENT'
    const value = Number(body?.value)

    if (!code) {
      return NextResponse.json({ error: 'کد تخفیف الزامی است' }, { status: 400 })
    }
    if (!Number.isFinite(value) || value <= 0) {
      return NextResponse.json({ error: 'مقدار تخفیف نامعتبر است' }, { status: 400 })
    }
    if (type === 'PERCENT' && value > 100) {
      return NextResponse.json(
        { error: 'درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد' },
        { status: 400 },
      )
    }

    const existing = await db.coupon.findUnique({ where: { code } })
    if (existing) {
      return NextResponse.json(
        { error: 'این کد قبلاً ثبت شده است' },
        { status: 400 },
      )
    }

    const expiresAt = body?.expiresAt ? new Date(body.expiresAt) : null
    if (expiresAt && isNaN(expiresAt.getTime())) {
      return NextResponse.json({ error: 'تاریخ انقضا نامعتبر است' }, { status: 400 })
    }

    const usageLimit = Math.max(0, Number(body?.usageLimit) || 0)
    const minOrderIrr = Math.max(0, Number(body?.minOrderIrr) || 0)
    const active = body?.active !== false

    const created = await db.coupon.create({
      data: {
        code,
        type,
        value,
        expiresAt,
        usageLimit,
        minOrderIrr,
        active,
      },
    })

    await logAudit({
      admin: session,
      action: 'CREATE',
      entity: 'Coupon',
      entityId: created.id,
      after: {
        code: created.code,
        type: created.type,
        value: created.value,
        expiresAt: created.expiresAt,
        usageLimit,
        minOrderIrr,
        active,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, coupon: created }, { status: 201 })
  } catch (err) {
    console.error('[coupons] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
