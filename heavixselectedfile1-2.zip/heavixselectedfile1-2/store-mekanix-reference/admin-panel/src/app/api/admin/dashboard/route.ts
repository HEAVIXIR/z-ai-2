import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { getEffectiveRate, todayTehran } from '@/lib/currency'
import { fetchTelegramRate } from '@/lib/telegram-rate'

export async function GET() {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const today = todayTehran()
    const setting = await db.currencySetting.findUnique({
      where: { id: 'singleton' },
    })

    const effective = await getEffectiveRate()

    // Live telegram rate (1-min cached) — for banner display
    const telegram = await fetchTelegramRate()

    const [
      parts,
      activeParts,
      lowStock,
      pendingPayments,
      pendingOrders,
      customers,
      mechanics,
      orders,
      pendingReviews,
      approvedPaymentsAgg,
    ] = await Promise.all([
      db.part.count(),
      db.part.count({ where: { active: true } }),
      db.part.count({ where: { stock: { lte: 5 } } }),
      db.payment.count({ where: { status: 'PENDING' } }),
      db.order.count({ where: { status: 'PENDING' } }),
      db.customer.count(),
      db.mechanic.count(),
      db.order.count(),
      db.review.count({ where: { approved: false } }),
      db.payment.aggregate({ _sum: { amountIrr: true }, where: { status: 'APPROVED' } }),
    ])

    const revenueIrr = approvedPaymentsAgg._sum.amountIrr ?? 0

    // Sales by day (last 7 days, by approved payments)
    const since = new Date()
    since.setDate(since.getDate() - 6)
    since.setHours(0, 0, 0, 0)
    const recentPayments = await db.payment.findMany({
      where: {
        status: 'APPROVED',
        createdAt: { gte: since },
      },
      select: { amountIrr: true, createdAt: true },
    })
    const dayMap = new Map<string, number>()
    for (let i = 0; i < 7; i++) {
      const d = new Date()
      d.setHours(0, 0, 0, 0)
      d.setDate(d.getDate() - i)
      const key = todayTehran(d)
      dayMap.set(key, 0)
    }
    for (const p of recentPayments) {
      const key = todayTehran(p.createdAt)
      if (dayMap.has(key)) dayMap.set(key, (dayMap.get(key) || 0) + (p.amountIrr || 0))
    }
    const salesByDay = Array.from(dayMap.entries())
      .map(([day, amount]) => ({ day, amount }))
      .sort((a, b) => (a.day < b.day ? -1 : 1))

    // Payments by status
    const paymentStatusGroups = await db.payment.groupBy({
      by: ['status'],
      _count: true,
    })
    const paymentsByStatus = paymentStatusGroups.map((g) => ({
      status: g.status,
      count: g._count,
    }))

    // Orders by status
    const orderStatusGroups = await db.order.groupBy({
      by: ['status'],
      _count: true,
    })
    const ordersByStatus = orderStatusGroups.map((g) => ({
      status: g.status,
      count: g._count,
    }))

    // Recent pending payments (6, with order + customer)
    const recentPendingPayments = await db.payment.findMany({
      where: { status: 'PENDING' },
      orderBy: { createdAt: 'desc' },
      take: 6,
      include: {
        order: { select: { orderNumber: true, totalIrr: true } },
        customer: { select: { name: true, family: true, phone: true } },
      },
    })

    // Low stock list (6, stock<=5)
    const lowStockList = await db.part.findMany({
      where: { stock: { lte: 5 } },
      orderBy: { stock: 'asc' },
      take: 6,
      select: {
        id: true,
        name: true,
        sku: true,
        stock: true,
        lowStockThreshold: true,
        active: true,
      },
    })

    // Recent pending reviews (5, pending approval)
    const recentPendingReviews = await db.review.findMany({
      where: { approved: false },
      orderBy: { createdAt: 'desc' },
      take: 5,
      include: {
        part: { select: { id: true, name: true } },
        customer: { select: { name: true, family: true } },
      },
    })

    return NextResponse.json({
      currency: {
        todayRate: effective.rate,
        source: effective.source,
        margin: effective.marginPercent,
        date: today,
        defaultRate: setting?.defaultRate ?? 230000,
        autoUpdateEnabled: setting?.autoUpdateEnabled ?? true,
        autoSource: setting?.autoSource ?? 'telegram',
        lastAutoRate: setting?.lastAutoRate ?? null,
        lastAutoStatus: setting?.lastAutoStatus ?? null,
        lastAutoFetchAt: setting?.lastAutoFetchAt ?? null,
        telegram: telegram
          ? {
              rate: telegram.rate,
              status: telegram.status,
              fetchedAt: telegram.fetchedAt,
            }
          : null,
      },
      counts: {
        parts,
        activeParts,
        lowStock,
        pendingPayments,
        pendingOrders,
        customers,
        mechanics,
        orders,
        pendingReviews,
      },
      revenueIrr,
      salesByDay,
      paymentsByStatus,
      ordersByStatus,
      recentPendingPayments: recentPendingPayments.map((p) => ({
        id: p.id,
        amountIrr: p.amountIrr,
        method: p.method,
        status: p.status,
        createdAt: p.createdAt,
        orderNumber: p.order?.orderNumber ?? null,
        orderTotalIrr: p.order?.totalIrr ?? null,
        customerName: p.customer
          ? `${p.customer.name} ${p.customer.family}`.trim()
          : null,
        customerPhone: p.customer?.phone ?? null,
      })),
      lowStockList,
      recentPendingReviews: recentPendingReviews.map((r) => ({
        id: r.id,
        rating: r.rating,
        title: r.title,
        comment: r.comment,
        createdAt: r.createdAt,
        partName: r.part?.name ?? null,
        customerName: r.customer
          ? `${r.customer.name} ${r.customer.family}`.trim()
          : null,
      })),
    })
  } catch (err) {
    console.error('[dashboard] error:', err)
    return NextResponse.json(
      { error: 'خطا در بارگذاری داشبورد' },
      { status: 500 },
    )
  }
}
