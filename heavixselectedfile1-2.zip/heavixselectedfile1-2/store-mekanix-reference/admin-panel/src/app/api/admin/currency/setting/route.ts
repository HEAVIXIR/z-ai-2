import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export async function PUT(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const data: Record<string, unknown> = {}

    if (body?.defaultRate != null && body.defaultRate !== '') {
      const v = Number(body.defaultRate)
      if (!Number.isFinite(v) || v <= 0) {
        return NextResponse.json(
          { error: 'نرخ پیش‌فرض نامعتبر است' },
          { status: 400 },
        )
      }
      data.defaultRate = v
    }
    if (body?.marginPercent != null && body.marginPercent !== '') {
      const v = Number(body.marginPercent)
      if (!Number.isFinite(v) || v < 0) {
        return NextResponse.json(
          { error: 'حاشیه سود نامعتبر است' },
          { status: 400 },
        )
      }
      data.marginPercent = v
    }
    if (typeof body?.autoUpdateEnabled === 'boolean') {
      data.autoUpdateEnabled = body.autoUpdateEnabled
    }
    if (typeof body?.autoSource === 'string' && body.autoSource) {
      data.autoSource = body.autoSource
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json(
        { error: 'هیچ فیلدی برای بروزرسانی ارسال نشده' },
        { status: 400 },
      )
    }

    const before = await db.currencySetting.findUnique({
      where: { id: 'singleton' },
    })

    // Upsert because the singleton row may not exist yet (default DB).
    const updated = await db.currencySetting.upsert({
      where: { id: 'singleton' },
      create: {
        id: 'singleton',
        defaultRate:
          (data.defaultRate as number) ?? before?.defaultRate ?? 230000,
        marginPercent:
          (data.marginPercent as number) ?? before?.marginPercent ?? 3,
        autoUpdateEnabled:
          (data.autoUpdateEnabled as boolean) ??
          before?.autoUpdateEnabled ??
          true,
        autoSource: (data.autoSource as string) ?? before?.autoSource ?? 'telegram',
      },
      update: data,
    })

    await logAudit({
      admin: session,
      action: 'UPDATE_CURRENCY_SETTING',
      entity: 'CurrencySetting',
      entityId: 'singleton',
      before,
      after: updated,
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, setting: updated })
  } catch (err) {
    console.error('[currency/setting] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
