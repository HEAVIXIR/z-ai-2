import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const r = await db.review.findUnique({
      where: { id },
      include: {
        part: { select: { id: true, name: true, sku: true } },
        customer: { select: { id: true, name: true, family: true, phone: true } },
        reviewedBy: { select: { id: true, name: true, username: true } },
      },
    })
    if (!r) {
      return NextResponse.json({ error: 'نظر یافت نشد' }, { status: 404 })
    }
    return NextResponse.json({
      id: r.id,
      partId: r.partId,
      customerId: r.customerId,
      rating: r.rating,
      title: r.title ?? null,
      comment: r.comment ?? null,
      approved: r.approved,
      reviewedById: r.reviewedById ?? null,
      createdAt: r.createdAt,
      part: r.part
        ? { id: r.part.id, name: r.part.name, sku: r.part.sku }
        : null,
      customer: r.customer
        ? {
            id: r.customer.id,
            name: r.customer.name,
            family: r.customer.family,
            phone: r.customer.phone,
            fullName: `${r.customer.name} ${r.customer.family}`.trim(),
          }
        : null,
      reviewedBy: r.reviewedBy
        ? { id: r.reviewedBy.id, name: r.reviewedBy.name, username: r.reviewedBy.username }
        : null,
    })
  } catch (err) {
    console.error('[review] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))
    const action = String(body?.action ?? '').toLowerCase()

    if (action !== 'approve' && action !== 'reject') {
      return NextResponse.json(
        { error: "action باید 'approve' یا 'reject' باشد" },
        { status: 400 },
      )
    }

    const existing = await db.review.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'نظر یافت نشد' }, { status: 404 })
    }

    const approved = action === 'approve'
    const updated = await db.review.update({
      where: { id },
      data: { approved, reviewedById: session.id },
    })

    await logAudit({
      admin: session,
      action: action === 'approve' ? 'APPROVE' : 'REJECT',
      entity: 'Review',
      entityId: id,
      before: {
        approved: existing.approved,
        rating: existing.rating,
        title: existing.title,
      },
      after: {
        approved: updated.approved,
        reviewedById: session.id,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, review: updated })
  } catch (err) {
    console.error('[review] PATCH error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
