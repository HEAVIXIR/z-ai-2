import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export async function GET(req: NextRequest) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const url = new URL(req.url)
    const q = url.searchParams.get('q')?.trim() || ''
    const status = url.searchParams.get('status')?.trim() || ''
    const verified =
      url.searchParams.get('verified') === 'true'
        ? true
        : url.searchParams.get('verified') === 'false'
          ? false
          : undefined
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1', 10) || 1)
    const pageSize = Math.min(
      100,
      Math.max(1, parseInt(url.searchParams.get('pageSize') || '20', 10) || 20),
    )

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (verified !== undefined) where.verified = verified
    if (q) {
      where.OR = [
        { phone: { contains: q } },
        { name: { contains: q } },
        { family: { contains: q } },
        { shopName: { contains: q } },
        { specialty: { contains: q } },
        { city: { contains: q } },
      ]
    }

    const [total, mechanics] = await Promise.all([
      db.mechanic.count({ where }),
      db.mechanic.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true,
          phone: true,
          name: true,
          family: true,
          shopName: true,
          specialty: true,
          city: true,
          address: true,
          rating: true,
          verified: true,
          status: true,
          totalOrders: true,
          notes: true,
          createdAt: true,
          _count: { select: { orders: true } },
        },
      }),
    ])

    return NextResponse.json({
      mechanics,
      total,
      page,
      pageSize,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    })
  } catch (err) {
    console.error('[mechanics] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const phone = String(body?.phone ?? '').trim()
    const name = String(body?.name ?? '').trim()
    const family = String(body?.family ?? '').trim()

    if (!phone || !name || !family) {
      return NextResponse.json(
        { error: 'شماره موبایل، نام و نام خانوادگی الزامی است' },
        { status: 400 },
      )
    }

    const existing = await db.mechanic.findUnique({ where: { phone } })
    if (existing) {
      return NextResponse.json(
        { error: 'مکانیکی با این شماره موبایل قبلاً ثبت شده است' },
        { status: 400 },
      )
    }

    const created = await db.mechanic.create({
      data: {
        phone,
        name,
        family,
        shopName: body?.shopName ? String(body.shopName) : null,
        specialty: body?.specialty ? String(body.specialty) : null,
        city: body?.city ? String(body.city) : null,
        address: body?.address ? String(body.address) : null,
        notes: body?.notes ? String(body.notes) : null,
        rating: 0,
        verified: false,
        status: 'ACTIVE',
        totalOrders: 0,
      },
      select: {
        id: true,
        phone: true,
        name: true,
        family: true,
        shopName: true,
        specialty: true,
        city: true,
        verified: true,
        status: true,
        rating: true,
        totalOrders: true,
        createdAt: true,
      },
    })

    await logAudit({
      admin: session,
      action: 'CREATE_MECHANIC',
      entity: 'Mechanic',
      entityId: created.id,
      after: {
        phone,
        name,
        family,
        shopName: created.shopName,
        specialty: created.specialty,
        city: created.city,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, mechanic: created })
  } catch (err) {
    console.error('[mechanics] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
