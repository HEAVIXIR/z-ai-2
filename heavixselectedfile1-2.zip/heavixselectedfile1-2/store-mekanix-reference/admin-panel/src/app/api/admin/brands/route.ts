import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export function brandSlugify(s: string): string {
  const out = s
    .trim()
    .toLowerCase()
    .replace(/[^\w\u0600-\u06FF]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return out || `brand-${Date.now()}`
}

export async function GET() {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const brands = await db.brand.findMany({
      orderBy: { name: 'asc' },
      include: { _count: { select: { parts: true } } },
    })

    return NextResponse.json({
      brands: brands.map((b) => ({
        id: b.id,
        name: b.name,
        slug: b.slug,
        logoUrl: b.logoUrl ?? null,
        country: b.country ?? null,
        partsCount: b._count.parts,
        createdAt: b.createdAt,
      })),
    })
  } catch (err) {
    console.error('[brands] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const name = String(body?.name ?? '').trim()
    if (!name) {
      return NextResponse.json({ error: 'نام برند الزامی است' }, { status: 400 })
    }

    const country =
      body?.country && String(body.country).trim()
        ? String(body.country).trim()
        : null
    const logoUrl =
      body?.logoUrl && String(body.logoUrl).trim()
        ? String(body.logoUrl).trim()
        : null

    const baseSlug = brandSlugify(name)
    let slug = baseSlug
    let n = 1
    while (await db.brand.findUnique({ where: { slug } })) {
      slug = `${baseSlug}-${n++}`
    }

    const created = await db.brand.create({
      data: { name, slug, country, logoUrl },
    })

    await logAudit({
      admin: session,
      action: 'CREATE',
      entity: 'Brand',
      entityId: created.id,
      after: {
        name: created.name,
        slug: created.slug,
        country,
        logoUrl,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, brand: created }, { status: 201 })
  } catch (err) {
    console.error('[brands] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
