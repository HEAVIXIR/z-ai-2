import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const payment = await db.payment.findUnique({
      where: { id },
      include: {
        order: {
          select: {
            id: true,
            orderNumber: true,
            totalIrr: true,
            totalUsd: true,
            status: true,
            paymentStatus: true,
            shippingAddress: true,
            notes: true,
            couponCode: true,
            currencyRateAtOrder: true,
            marginPercentAtOrder: true,
            subtotalUsd: true,
            shippingUsd: true,
            discountIrr: true,
            items: {
              include: {
                part: { select: { id: true, name: true, sku: true } },
              },
            },
            customer: {
              select: {
                id: true,
                name: true,
                family: true,
                phone: true,
                nationalCode: true,
                address: true,
              },
            },
          },
        },
        customer: {
          select: {
            id: true,
            name: true,
            family: true,
            phone: true,
            nationalCode: true,
            walletBalanceIrr: true,
            totalOrders: true,
            totalSpentIrr: true,
          },
        },
        reviewedBy: { select: { id: true, name: true, username: true } },
      },
    })
    if (!payment) {
      return NextResponse.json({ error: 'پرداخت یافت نشد' }, { status: 404 })
    }
    return NextResponse.json(payment)
  } catch (err) {
    console.error('[payment] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))
    const action = String(body?.action ?? '').toLowerCase()
    const note = body?.note ? String(body.note) : null

    if (action !== 'approve' && action !== 'reject') {
      return NextResponse.json(
        { error: 'اقدام نامعتبر است (approve/reject)' },
        { status: 400 },
      )
    }

    const payment = await db.payment.findUnique({
      where: { id },
      include: {
        order: { select: { id: true, status: true, paymentStatus: true, customerId: true } },
        customer: { select: { id: true, name: true, family: true, phone: true } },
      },
    })
    if (!payment) {
      return NextResponse.json({ error: 'پرداخت یافت نشد' }, { status: 404 })
    }

    if (payment.reviewedAt) {
      return NextResponse.json(
        { error: 'این پرداخت قبلاً بررسی شده' },
        { status: 400 },
      )
    }

    const ip =
      req.headers.get('x-forwarded-for') ||
      req.headers.get('x-real-ip') ||
      null

    if (action === 'approve') {
      const updated = await db.$transaction(async (tx) => {
        const now = new Date()
        const p = await tx.payment.update({
          where: { id },
          data: {
            status: 'APPROVED',
            reviewedById: session.id,
            reviewedAt: now,
            note,
          },
        })

        const orderUpdate: Record<string, unknown> = {
          paymentStatus: 'PAID',
        }
        // If the order is still PENDING, advance to CONFIRMED.
        if (payment.order!.status === 'PENDING') {
          orderUpdate.status = 'CONFIRMED'
        }
        const updatedOrder = await tx.order.update({
          where: { id: payment.orderId },
          data: orderUpdate,
        })

        // Increase customer totalSpentIrr.
        const updatedCustomer = await tx.customer.update({
          where: { id: payment.customerId },
          data: {
            totalSpentIrr: { increment: payment.amountIrr },
            totalOrders: { increment: 1 },
          },
        })

        return { p, updatedOrder, updatedCustomer }
      })

      await logAudit({
        admin: session,
        action: 'APPROVE_PAYMENT',
        entity: 'Payment',
        entityId: id,
        before: {
          status: payment.status,
          reviewedAt: payment.reviewedAt,
          orderStatus: payment.order!.status,
          orderPaymentStatus: payment.order!.paymentStatus,
          customerTotalSpentIrr: payment.customer ? payment.customer.id : null,
        },
        after: {
          status: updated.p.status,
          reviewedById: session.id,
          reviewedAt: updated.p.reviewedAt,
          orderStatus: updated.updatedOrder.status,
          orderPaymentStatus: updated.updatedOrder.paymentStatus,
          amountIrr: payment.amountIrr,
          customerTotalSpentIncrement: payment.amountIrr,
        },
        ipAddress: ip,
      })

      return NextResponse.json({
        ok: true,
        payment: updated.p,
        orderStatus: updated.updatedOrder.status,
        orderPaymentStatus: updated.updatedOrder.paymentStatus,
      })
    } else {
      // REJECT
      const updated = await db.$transaction(async (tx) => {
        const now = new Date()
        const p = await tx.payment.update({
          where: { id },
          data: {
            status: 'REJECTED',
            reviewedById: session.id,
            reviewedAt: now,
            note,
          },
        })

        const orderUpdate: Record<string, unknown> = {}
        if (payment.order!.paymentStatus === 'PENDING') {
          orderUpdate.paymentStatus = 'UNPAID'
        }
        let updatedOrder = payment.order!
        if (Object.keys(orderUpdate).length > 0) {
          updatedOrder = await tx.order.update({
            where: { id: payment.orderId },
            data: orderUpdate,
            select: { id: true, status: true, paymentStatus: true },
          })
        }

        return { p, updatedOrder }
      })

      await logAudit({
        admin: session,
        action: 'REJECT_PAYMENT',
        entity: 'Payment',
        entityId: id,
        before: {
          status: payment.status,
          reviewedAt: payment.reviewedAt,
          orderPaymentStatus: payment.order!.paymentStatus,
        },
        after: {
          status: updated.p.status,
          reviewedById: session.id,
          reviewedAt: updated.p.reviewedAt,
          orderPaymentStatus: updated.updatedOrder.paymentStatus,
        },
        ipAddress: ip,
      })

      return NextResponse.json({
        ok: true,
        payment: updated.p,
        orderPaymentStatus: updated.updatedOrder.paymentStatus,
      })
    }
  } catch (err) {
    console.error('[payment] PATCH error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
