import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { clearSession, requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    await clearSession()
    return NextResponse.json({ ok: true })
  }
  await logAudit({
    admin: session,
    action: 'LOGOUT',
    entity: 'AdminUser',
    entityId: session.id,
    ipAddress: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || null,
  })
  await clearSession()
  // Touch DB to keep TS happy that db import is used downstream.
  void db
  return NextResponse.json({ ok: true })
}
