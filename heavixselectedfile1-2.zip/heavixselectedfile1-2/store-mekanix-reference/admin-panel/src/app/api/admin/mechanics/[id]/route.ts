import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const mechanic = await db.mechanic.findUnique({
      where: { id },
      include: {
        orders: {
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            orderNumber: true,
            status: true,
            paymentStatus: true,
            totalIrr: true,
            totalUsd: true,
            createdAt: true,
            customer: {
              select: { id: true, name: true, family: true, phone: true },
            },
          },
        },
        _count: { select: { orders: true } },
      },
    })
    if (!mechanic) {
      return NextResponse.json({ error: 'مکانیک یافت نشد' }, { status: 404 })
    }
    return NextResponse.json(mechanic)
  } catch (err) {
    console.error('[mechanic] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.mechanic.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'مکانیک یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (body?.phone != null) {
      const phone = String(body.phone).trim()
      if (!phone) {
        return NextResponse.json(
          { error: 'شماره موبایل نمی‌تواند خالی باشد' },
          { status: 400 },
        )
      }
      const dupe = await db.mechanic.findUnique({ where: { phone } })
      if (dupe && dupe.id !== id) {
        return NextResponse.json(
          { error: 'این شماره موبایل قبلاً ثبت شده است' },
          { status: 400 },
        )
      }
      data.phone = phone
    }
    if (body?.name != null) data.name = String(body.name).trim()
    if (body?.family != null) data.family = String(body.family).trim()
    if (body?.shopName !== undefined) {
      data.shopName = body.shopName ? String(body.shopName) : null
    }
    if (body?.specialty !== undefined) {
      data.specialty = body.specialty ? String(body.specialty) : null
    }
    if (body?.city !== undefined) {
      data.city = body.city ? String(body.city) : null
    }
    if (body?.address !== undefined) {
      data.address = body.address ? String(body.address) : null
    }
    if (body?.notes !== undefined) {
      data.notes = body.notes ? String(body.notes) : null
    }
    if (body?.verified != null) data.verified = !!body.verified
    if (body?.status != null) {
      const s = String(body.status)
      if (s !== 'ACTIVE' && s !== 'SUSPENDED') {
        return NextResponse.json({ error: 'وضعیت نامعتبر است' }, { status: 400 })
      }
      data.status = s
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ ok: true, mechanic: existing })
    }

    const updated = await db.mechanic.update({
      where: { id },
      data,
      select: {
        id: true,
        phone: true,
        name: true,
        family: true,
        shopName: true,
        specialty: true,
        city: true,
        address: true,
        rating: true,
        verified: true,
        status: true,
        totalOrders: true,
        notes: true,
      },
    })

    await logAudit({
      admin: session,
      action: 'UPDATE_MECHANIC',
      entity: 'Mechanic',
      entityId: id,
      before: {
        phone: existing.phone,
        name: existing.name,
        family: existing.family,
        shopName: existing.shopName,
        specialty: existing.specialty,
        city: existing.city,
        verified: existing.verified,
        status: existing.status,
      },
      after: {
        phone: updated.phone,
        name: updated.name,
        family: updated.family,
        shopName: updated.shopName,
        specialty: updated.specialty,
        city: updated.city,
        verified: updated.verified,
        status: updated.status,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, mechanic: updated })
  } catch (err) {
    console.error('[mechanic] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

/** PATCH for quick toggles: { verified?, status? } */
export async function PATCH(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.mechanic.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'مکانیک یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (body?.verified != null) data.verified = !!body.verified
    if (body?.status != null) {
      const s = String(body.status)
      if (s !== 'ACTIVE' && s !== 'SUSPENDED') {
        return NextResponse.json({ error: 'وضعیت نامعتبر است' }, { status: 400 })
      }
      data.status = s
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ ok: true, mechanic: existing })
    }

    const updated = await db.mechanic.update({
      where: { id },
      data,
      select: {
        id: true,
        phone: true,
        name: true,
        family: true,
        shopName: true,
        specialty: true,
        city: true,
        verified: true,
        status: true,
        rating: true,
        totalOrders: true,
      },
    })

    const action =
      body?.verified != null
        ? data.verified
          ? 'VERIFY_MECHANIC'
          : 'UNVERIFY_MECHANIC'
        : body?.status != null
          ? data.status === 'SUSPENDED'
            ? 'SUSPEND_MECHANIC'
            : 'ACTIVATE_MECHANIC'
          : 'UPDATE_MECHANIC'

    await logAudit({
      admin: session,
      action,
      entity: 'Mechanic',
      entityId: id,
      before: { verified: existing.verified, status: existing.status },
      after: { verified: updated.verified, status: updated.status },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, mechanic: updated })
  } catch (err) {
    console.error('[mechanic] PATCH error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
