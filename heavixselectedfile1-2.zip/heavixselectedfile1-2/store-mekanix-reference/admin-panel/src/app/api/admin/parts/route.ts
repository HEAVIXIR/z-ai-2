import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { getEffectiveRate, usdToIrr } from '@/lib/currency'
import { logAudit } from '@/lib/audit'

export async function GET(req: NextRequest) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const url = new URL(req.url)
    const q = url.searchParams.get('q')?.trim() || ''
    const categoryId = url.searchParams.get('categoryId') || undefined
    const brandId = url.searchParams.get('brandId') || undefined
    const active =
      url.searchParams.get('active') === 'true'
        ? true
        : url.searchParams.get('active') === 'false'
          ? false
          : undefined

    const where: Record<string, unknown> = {}
    if (q) {
      where.OR = [
        { name: { contains: q } },
        { sku: { contains: q } },
        { nameFa: { contains: q } },
        { description: { contains: q } },
      ]
    }
    if (categoryId) where.categoryId = categoryId
    if (brandId) where.brandId = brandId
    if (active !== undefined) where.active = active

    const [parts, eff] = await Promise.all([
      db.part.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        include: {
          category: { select: { id: true, name: true } },
          brand: { select: { id: true, name: true } },
          carModels: { select: { id: true, brand: true, model: true, yearFrom: true, yearTo: true } },
        },
      }),
      getEffectiveRate(),
    ])

    const margin = eff.marginPercent
    return NextResponse.json({
      effectiveRate: eff,
      parts: parts.map((p) => ({
        ...p,
        images: safeParseArray(p.images),
        compatibleCars: safeParseArray(p.compatibleCars),
        priceIrr: usdToIrr(p.priceUsd, { rate: eff.rate, marginPercent: margin }),
        oldPriceIrr: p.oldPriceUsd
          ? usdToIrr(p.oldPriceUsd, { rate: eff.rate, marginPercent: margin })
          : null,
      })),
    })
  } catch (err) {
    console.error('[parts] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

function safeParseArray(s: string | null | undefined): string[] {
  if (!s) return []
  try {
    const v = JSON.parse(s)
    return Array.isArray(v) ? v.map((x) => String(x)) : []
  } catch {
    return s.split(',').map((x) => x.trim()).filter(Boolean)
  }
}

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const name = String(body?.name ?? '').trim()
    const sku = String(body?.sku ?? '').trim()
    const categoryId = String(body?.categoryId ?? '').trim()
    const priceUsd = Number(body?.priceUsd)

    if (!name || !sku || !categoryId || !Number.isFinite(priceUsd)) {
      return NextResponse.json(
        { error: 'فیلدهای نام، SKU، دسته و قیمت الزامی هستند' },
        { status: 400 },
      )
    }

    const existing = await db.part.findUnique({ where: { sku } })
    if (existing) {
      return NextResponse.json(
        { error: 'این SKU قبلاً ثبت شده است' },
        { status: 400 },
      )
    }

    const brandId = body?.brandId ? String(body.brandId) : undefined
    const images = Array.isArray(body?.images)
      ? body.images.map(String)
      : typeof body?.images === 'string'
        ? body.images.split(',').map((s) => s.trim()).filter(Boolean)
        : []
    const compatibleCars = Array.isArray(body?.compatibleCars)
      ? body.compatibleCars.map(String)
      : []
    const carModelIds: string[] = Array.isArray(body?.carModelIds)
      ? body.carModelIds.map(String).filter(Boolean)
      : []

    const created = await db.part.create({
      data: {
        name,
        nameFa: body?.nameFa ? String(body.nameFa) : null,
        sku,
        categoryId,
        brandId: brandId || undefined,
        description: body?.description ? String(body.description) : null,
        priceUsd,
        oldPriceUsd:
          body?.oldPriceUsd != null && body.oldPriceUsd !== ''
            ? Number(body.oldPriceUsd)
            : null,
        stock: Number(body?.stock ?? 0) || 0,
        lowStockThreshold: Number(body?.lowStockThreshold ?? 5) || 5,
        images: JSON.stringify(images),
        compatibleCars: JSON.stringify(compatibleCars),
        active: body?.active !== false,
        featured: !!body?.featured,
        carModels:
          carModelIds.length > 0
            ? { connect: carModelIds.map((id) => ({ id })) }
            : undefined,
      },
      include: {
        category: { select: { id: true, name: true } },
        brand: { select: { id: true, name: true } },
        carModels: { select: { id: true, brand: true, model: true, yearFrom: true, yearTo: true } },
      },
    })

    await logAudit({
      admin: session,
      action: 'CREATE_PART',
      entity: 'Part',
      entityId: created.id,
      after: {
        name: created.name,
        sku: created.sku,
        priceUsd: created.priceUsd,
        categoryId: created.categoryId,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, part: created })
  } catch (err) {
    console.error('[parts] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
