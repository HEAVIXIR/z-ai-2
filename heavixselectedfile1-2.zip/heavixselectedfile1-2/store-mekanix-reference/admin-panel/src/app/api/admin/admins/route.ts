import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, isSuperAdmin } from '@/lib/auth'
import { logAudit } from '@/lib/audit'
import { hashPassword } from '@/lib/password'

export async function GET() {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  if (!isSuperAdmin(session)) {
    return NextResponse.json(
      { error: 'این بخش فقط برای مدیر ارشد قابل دسترس است' },
      { status: 403 },
    )
  }

  try {
    const admins = await db.adminUser.findMany({
      orderBy: { createdAt: 'asc' },
      include: { _count: { select: { auditLogs: true } } },
    })

    return NextResponse.json({
      currentId: session.id,
      admins: admins.map((a) => ({
        id: a.id,
        username: a.username,
        name: a.name,
        role: a.role,
        active: a.active,
        lastLoginAt: a.lastLoginAt,
        createdAt: a.createdAt,
        auditLogsCount: a._count.auditLogs,
      })),
    })
  } catch (err) {
    console.error('[admins] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  if (!isSuperAdmin(session)) {
    return NextResponse.json(
      { error: 'این عملیات فقط برای مدیر ارشد مجاز است' },
      { status: 403 },
    )
  }

  try {
    const body = await req.json().catch(() => ({}))
    const username = String(body?.username ?? '').trim().toLowerCase()
    const password = String(body?.password ?? '')
    const name = String(body?.name ?? '').trim()
    const role = ['SUPER_ADMIN', 'ADMIN', 'OPERATOR'].includes(String(body?.role))
      ? String(body.role)
      : 'OPERATOR'

    if (!username || !name || !password) {
      return NextResponse.json(
        { error: 'نام کاربری، نام کامل و رمز عبور الزامی هستند' },
        { status: 400 },
      )
    }
    if (password.length < 6) {
      return NextResponse.json(
        { error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' },
        { status: 400 },
      )
    }

    const existing = await db.adminUser.findUnique({ where: { username } })
    if (existing) {
      return NextResponse.json(
        { error: 'این نام کاربری قبلاً ثبت شده است' },
        { status: 400 },
      )
    }

    const created = await db.adminUser.create({
      data: {
        username,
        name,
        role,
        passwordHash: hashPassword(password),
      },
    })

    await logAudit({
      admin: session,
      action: 'CREATE',
      entity: 'AdminUser',
      entityId: created.id,
      after: { username: created.username, name: created.name, role: created.role },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json(
      {
        ok: true,
        admin: {
          id: created.id,
          username: created.username,
          name: created.name,
          role: created.role,
          active: created.active,
          createdAt: created.createdAt,
        },
      },
      { status: 201 },
    )
  } catch (err) {
    console.error('[admins] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
