import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const url = new URL(req.url)
    const q = url.searchParams.get('q')?.trim() || ''
    const status = url.searchParams.get('status')?.trim() || ''
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1', 10) || 1)
    const pageSize = Math.min(
      100,
      Math.max(1, parseInt(url.searchParams.get('pageSize') || '20', 10) || 20),
    )

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (q) {
      where.OR = [
        { phone: { contains: q } },
        { name: { contains: q } },
        { family: { contains: q } },
        { nationalCode: { contains: q } },
      ]
    }

    const [total, customers] = await Promise.all([
      db.customer.count({ where }),
      db.customer.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true,
          phone: true,
          name: true,
          family: true,
          nationalCode: true,
          address: true,
          status: true,
          totalOrders: true,
          totalSpentIrr: true,
          walletBalanceIrr: true,
          notes: true,
          createdAt: true,
          _count: {
            select: {
              orders: true,
              payments: true,
              wishlists: true,
              reviews: true,
            },
          },
        },
      }),
    ])

    return NextResponse.json({
      customers,
      total,
      page,
      pageSize,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    })
  } catch (err) {
    console.error('[customers] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
