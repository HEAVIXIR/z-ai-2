import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

/**
 * Adjust a customer's wallet balance.
 * Body: { amount: number, type: 'CREDIT'|'DEBIT', description?: string }
 * - CREDIT: increases walletBalanceIrr by `amount`.
 * - DEBIT: decreases walletBalanceIrr by `amount`.
 * Records a WalletTransaction (signed: + for credit, - for debit).
 */
export async function POST(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))
    const amount = Number(body?.amount)
    const type = String(body?.type ?? '').toUpperCase()
    const description = body?.description ? String(body.description) : null

    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json(
        { error: 'مبلغ باید عددی مثبت باشد' },
        { status: 400 },
      )
    }
    if (type !== 'CREDIT' && type !== 'DEBIT') {
      return NextResponse.json(
        { error: 'نوع تراکنش باید CREDIT یا DEBIT باشد' },
        { status: 400 },
      )
    }

    const customer = await db.customer.findUnique({
      where: { id },
      select: { id: true, phone: true, name: true, family: true, walletBalanceIrr: true },
    })
    if (!customer) {
      return NextResponse.json({ error: 'مشتری یافت نشد' }, { status: 404 })
    }

    const signedAmount = type === 'CREDIT' ? amount : -amount

    const updated = await db.$transaction(async (tx) => {
      const txn = await tx.walletTransaction.create({
        data: {
          customerId: id,
          amount: signedAmount,
          type,
          description:
            description ||
            (type === 'CREDIT'
              ? 'افزایش موجودی توسط پنل مدیریت'
              : 'کاهش موجودی توسط پنل مدیریت'),
        },
      })
      const c = await tx.customer.update({
        where: { id },
        data: {
          walletBalanceIrr: { increment: signedAmount },
        },
        select: { id: true, walletBalanceIrr: true },
      })
      return { txn, c }
    })

    await logAudit({
      admin: session,
      action: 'WALLET_ADJUST',
      entity: 'Customer',
      entityId: id,
      before: { walletBalanceIrr: customer.walletBalanceIrr },
      after: {
        walletBalanceIrr: updated.c.walletBalanceIrr,
        type,
        amount,
        signedAmount,
        description,
        txnId: updated.txn.id,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({
      ok: true,
      walletBalanceIrr: updated.c.walletBalanceIrr,
      transaction: updated.txn,
    })
  } catch (err) {
    console.error('[wallet] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
