import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const url = new URL(req.url)
    const status = url.searchParams.get('status')?.trim() || ''
    const method = url.searchParams.get('method')?.trim() || ''
    const q = url.searchParams.get('q')?.trim() || ''
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1', 10) || 1)
    const pageSize = Math.min(
      100,
      Math.max(1, parseInt(url.searchParams.get('pageSize') || '50', 10) || 50),
    )

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (method) where.method = method
    if (q) {
      where.OR = [
        { referenceCode: { contains: q } },
        { payerName: { contains: q } },
        { payerCard: { contains: q } },
        { authority: { contains: q } },
        { refId: { contains: q } },
        { customer: { phone: { contains: q } } },
        { customer: { name: { contains: q } } },
        { customer: { family: { contains: q } } },
        { order: { orderNumber: { contains: q } } },
      ]
    }

    const [total, payments] = await Promise.all([
      db.payment.count({ where }),
      db.payment.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          order: {
            select: {
              id: true,
              orderNumber: true,
              totalIrr: true,
              totalUsd: true,
              status: true,
            },
          },
          customer: {
            select: {
              id: true,
              name: true,
              family: true,
              phone: true,
            },
          },
          reviewedBy: { select: { id: true, name: true } },
        },
      }),
    ])

    return NextResponse.json({
      payments,
      total,
      page,
      pageSize,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    })
  } catch (err) {
    console.error('[payments] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
