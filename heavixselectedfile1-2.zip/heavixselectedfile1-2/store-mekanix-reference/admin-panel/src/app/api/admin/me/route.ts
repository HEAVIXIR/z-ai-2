import { NextResponse } from 'next/server'
import { requireSession } from '@/lib/auth'

export async function GET() {
  try {
    const session = await requireSession()
    return NextResponse.json({ ok: true, admin: session })
  } catch {
    return NextResponse.json(
      { error: 'unauthorized' },
      { status: 401 },
    )
  }
}
