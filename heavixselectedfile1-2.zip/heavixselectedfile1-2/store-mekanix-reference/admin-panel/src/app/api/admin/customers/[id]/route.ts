import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const customer = await db.customer.findUnique({
      where: { id },
      include: {
        orders: {
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            orderNumber: true,
            status: true,
            paymentStatus: true,
            totalIrr: true,
            totalUsd: true,
            createdAt: true,
          },
        },
        payments: {
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            status: true,
            method: true,
            amountIrr: true,
            amountUsd: true,
            referenceCode: true,
            gateway: true,
            refId: true,
            createdAt: true,
            reviewedAt: true,
          },
          take: 50,
        },
        walletTxns: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
        _count: {
          select: {
            wishlists: true,
            reviews: true,
          },
        },
      },
    })
    if (!customer) {
      return NextResponse.json({ error: 'مشتری یافت نشد' }, { status: 404 })
    }
    return NextResponse.json(customer)
  } catch (err) {
    console.error('[customer] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.customer.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'مشتری یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (body?.name != null) data.name = String(body.name).trim() || existing.name
    if (body?.family != null) data.family = String(body.family).trim() || existing.family
    if (body?.address !== undefined) {
      data.address = body.address ? String(body.address) : null
    }
    if (body?.nationalCode !== undefined) {
      data.nationalCode = body.nationalCode ? String(body.nationalCode) : null
    }
    if (body?.notes !== undefined) {
      data.notes = body.notes ? String(body.notes) : null
    }
    if (body?.status != null) {
      const status = String(body.status)
      if (status !== 'ACTIVE' && status !== 'BLOCKED') {
        return NextResponse.json({ error: 'وضعیت نامعتبر است' }, { status: 400 })
      }
      data.status = status
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ ok: true, customer: existing })
    }

    const updated = await db.customer.update({
      where: { id },
      data,
      select: {
        id: true,
        phone: true,
        name: true,
        family: true,
        nationalCode: true,
        address: true,
        status: true,
        notes: true,
        walletBalanceIrr: true,
        totalSpentIrr: true,
        totalOrders: true,
      },
    })

    await logAudit({
      admin: session,
      action: 'UPDATE_CUSTOMER',
      entity: 'Customer',
      entityId: id,
      before: {
        name: existing.name,
        family: existing.family,
        nationalCode: existing.nationalCode,
        address: existing.address,
        status: existing.status,
        notes: existing.notes,
      },
      after: {
        name: updated.name,
        family: updated.family,
        nationalCode: updated.nationalCode,
        address: updated.address,
        status: updated.status,
        notes: updated.notes,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, customer: updated })
  } catch (err) {
    console.error('[customer] PATCH error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
