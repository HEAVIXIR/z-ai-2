import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, isSuperAdmin } from '@/lib/auth'
import { logAudit } from '@/lib/audit'
import { hashPassword } from '@/lib/password'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  if (!isSuperAdmin(session)) {
    return NextResponse.json(
      { error: 'این عملیات فقط برای مدیر ارشد مجاز است' },
      { status: 403 },
    )
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.adminUser.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'مدیر یافت نشد' }, { status: 404 })
    }

    const isSelf = id === session.id

    // Prevent self-demotion
    if (isSelf && body?.role != null && body.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { error: 'شما نمی‌توانید نقش خودتان را کاهش دهید' },
        { status: 400 },
      )
    }

    // Prevent self-deactivation
    if (isSelf && body?.active === false) {
      return NextResponse.json(
        { error: 'شما نمی‌توانید حساب کاربری خودتان را غیرفعال کنید' },
        { status: 400 },
      )
    }

    const data: Record<string, unknown> = {}
    if (body?.name != null) {
      const name = String(body.name).trim()
      if (!name) {
        return NextResponse.json({ error: 'نام خالی نیست' }, { status: 400 })
      }
      data.name = name
    }
    if (body?.role != null) {
      const r = String(body.role)
      if (!['SUPER_ADMIN', 'ADMIN', 'OPERATOR'].includes(r)) {
        return NextResponse.json({ error: 'نقش نامعتبر است' }, { status: 400 })
      }
      data.role = r
    }
    if (body?.active != null) {
      data.active = !!body.active
    }
    if (body?.password != null && String(body.password) !== '') {
      const pw = String(body.password)
      if (pw.length < 6) {
        return NextResponse.json(
          { error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' },
          { status: 400 },
        )
      }
      data.passwordHash = hashPassword(pw)
    }

    const updated = await db.adminUser.update({ where: { id }, data })

    await logAudit({
      admin: session,
      action: 'UPDATE',
      entity: 'AdminUser',
      entityId: id,
      before: {
        name: existing.name,
        role: existing.role,
        active: existing.active,
      },
      after: {
        name: updated.name,
        role: updated.role,
        active: updated.active,
        passwordChanged: !!data.passwordHash,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({
      ok: true,
      admin: {
        id: updated.id,
        username: updated.username,
        name: updated.name,
        role: updated.role,
        active: updated.active,
        lastLoginAt: updated.lastLoginAt,
      },
    })
  } catch (err) {
    console.error('[admin] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  if (!isSuperAdmin(session)) {
    return NextResponse.json(
      { error: 'این عملیات فقط برای مدیر ارشد مجاز است' },
      { status: 403 },
    )
  }

  try {
    const { id } = await ctx.params

    if (id === session.id) {
      return NextResponse.json(
        { error: 'شما نمی‌توانید حساب کاربری خودتان را حذف کنید' },
        { status: 400 },
      )
    }

    const existing = await db.adminUser.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'مدیر یافت نشد' }, { status: 404 })
    }

    // Clear auditLogs.adminId references so they don't get cascade-deleted
    await db.auditLog.updateMany({
      where: { adminId: id },
      data: { adminId: null },
    })

    await db.adminUser.delete({ where: { id } })

    await logAudit({
      admin: session,
      action: 'DELETE',
      entity: 'AdminUser',
      entityId: id,
      before: { username: existing.username, name: existing.name, role: existing.role },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[admin] DELETE error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
