import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export async function GET() {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const models = await db.carModel.findMany({
      orderBy: [{ brand: 'asc' }, { model: 'asc' }],
      include: { _count: { select: { parts: true } } },
    })

    // Group by brand for the parts form car selector
    const grouped: Record<
      string,
      Array<{
        id: string
        model: string
        yearFrom: number
        yearTo: number
        partsCount: number
      }>
    > = {}
    for (const m of models) {
      const b = m.brand
      if (!grouped[b]) grouped[b] = []
      grouped[b].push({
        id: m.id,
        model: m.model,
        yearFrom: m.yearFrom,
        yearTo: m.yearTo,
        partsCount: m._count.parts,
      })
    }

    return NextResponse.json({
      carModels: models.map((m) => ({
        id: m.id,
        brand: m.brand,
        model: m.model,
        yearFrom: m.yearFrom,
        yearTo: m.yearTo,
        partsCount: m._count.parts,
        createdAt: m.createdAt,
      })),
      grouped,
    })
  } catch (err) {
    console.error('[car-models] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const brand = String(body?.brand ?? '').trim()
    const model = String(body?.model ?? '').trim()
    const yearFrom = Number(body?.yearFrom)
    const yearTo = Number(body?.yearTo)

    if (!brand || !model) {
      return NextResponse.json(
        { error: 'برند و مدل خودرو الزامی هستند' },
        { status: 400 },
      )
    }
    if (
      !Number.isFinite(yearFrom) ||
      yearFrom < 1900 ||
      yearFrom > 2100 ||
      !Number.isFinite(yearTo) ||
      yearTo < 1900 ||
      yearTo > 2100 ||
      yearTo < yearFrom
    ) {
      return NextResponse.json(
        { error: 'سال شروع و پایان نامعتبر است' },
        { status: 400 },
      )
    }

    const created = await db.carModel.create({
      data: { brand, model, yearFrom, yearTo },
    })

    await logAudit({
      admin: session,
      action: 'CREATE',
      entity: 'CarModel',
      entityId: created.id,
      after: {
        brand: created.brand,
        model: created.model,
        yearFrom: created.yearFrom,
        yearTo: created.yearTo,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, carModel: created }, { status: 201 })
  } catch (err) {
    console.error('[car-models] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
