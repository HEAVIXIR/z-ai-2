import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const url = new URL(req.url)
    const q = url.searchParams.get('q')?.trim() || ''
    const status = url.searchParams.get('status')?.trim() || ''
    const paymentStatus = url.searchParams.get('paymentStatus')?.trim() || ''
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1', 10) || 1)
    const pageSize = Math.min(
      100,
      Math.max(1, parseInt(url.searchParams.get('pageSize') || '20', 10) || 20),
    )

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (paymentStatus) where.paymentStatus = paymentStatus
    if (q) {
      where.OR = [
        { orderNumber: { contains: q } },
        { customer: { phone: { contains: q } } },
        { customer: { name: { contains: q } } },
        { customer: { family: { contains: q } } },
      ]
    }

    const [total, orders] = await Promise.all([
      db.order.count({ where }),
      db.order.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          customer: {
            select: {
              id: true,
              name: true,
              family: true,
              phone: true,
            },
          },
          mechanic: {
            select: { id: true, name: true, family: true, shopName: true },
          },
          items: {
            select: {
              id: true,
              partId: true,
              partNameSnapshot: true,
              quantity: true,
              unitPriceUsd: true,
              unitPriceIrr: true,
              lineTotalUsd: true,
              lineTotalIrr: true,
              part: { select: { id: true, name: true, sku: true } },
            },
          },
          payments: {
            select: {
              id: true,
              status: true,
              amountIrr: true,
              method: true,
              gateway: true,
              refId: true,
              createdAt: true,
            },
            orderBy: { createdAt: 'desc' },
          },
          shipment: {
            select: {
              id: true,
              carrier: true,
              trackingCode: true,
              status: true,
              shippedAt: true,
              deliveredAt: true,
              note: true,
            },
          },
        },
      }),
    ])

    return NextResponse.json({
      orders,
      total,
      page,
      pageSize,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    })
  } catch (err) {
    console.error('[orders] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
