import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

const VALID_STATUS = [
  'PENDING',
  'CONFIRMED',
  'PROCESSING',
  'SHIPPED',
  'DELIVERED',
  'CANCELLED',
] as const

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const order = await db.order.findUnique({
      where: { id },
      include: {
        customer: {
          select: {
            id: true,
            name: true,
            family: true,
            phone: true,
            nationalCode: true,
            address: true,
            status: true,
          },
        },
        mechanic: {
          select: {
            id: true,
            name: true,
            family: true,
            shopName: true,
            specialty: true,
            city: true,
          },
        },
        items: {
          include: {
            part: { select: { id: true, name: true, sku: true } },
          },
        },
        payments: {
          orderBy: { createdAt: 'desc' },
          include: {
            reviewedBy: { select: { id: true, name: true } },
          },
        },
        shipment: true,
      },
    })
    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 })
    }
    return NextResponse.json(order)
  } catch (err) {
    console.error('[order] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.order.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (body?.status != null) {
      const status = String(body.status)
      if (!VALID_STATUS.includes(status as (typeof VALID_STATUS)[number])) {
        return NextResponse.json({ error: 'وضعیت نامعتبر است' }, { status: 400 })
      }
      data.status = status
    }
    if (body?.mechanicId !== undefined) {
      const mid = body.mechanicId ? String(body.mechanicId) : null
      if (mid) {
        const m = await db.mechanic.findUnique({ where: { id: mid } })
        if (!m) return NextResponse.json({ error: 'مکانیک یافت نشد' }, { status: 400 })
      }
      data.mechanicId = mid
    }
    if (body?.notes !== undefined) {
      data.notes = body.notes ? String(body.notes) : null
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ ok: true, order: existing })
    }

    const updated = await db.order.update({
      where: { id },
      data,
      include: {
        customer: {
          select: { id: true, name: true, family: true, phone: true },
        },
        mechanic: {
          select: { id: true, name: true, family: true, shopName: true },
        },
      },
    })

    await logAudit({
      admin: session,
      action: 'UPDATE_ORDER',
      entity: 'Order',
      entityId: id,
      before: {
        status: existing.status,
        mechanicId: existing.mechanicId,
        notes: existing.notes,
      },
      after: {
        status: updated.status,
        mechanicId: updated.mechanicId,
        notes: updated.notes,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, order: updated })
  } catch (err) {
    console.error('[order] PATCH error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
