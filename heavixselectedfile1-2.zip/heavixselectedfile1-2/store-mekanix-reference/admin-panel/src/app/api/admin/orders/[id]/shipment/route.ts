import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

const CARRIERS = ['پست', 'تیپاکس', 'چاپار'] as const
const SHIPMENT_STATUS = ['PENDING', 'DISPATCHED', 'IN_TRANSIT', 'DELIVERED'] as const

async function getIp(req: NextRequest) {
  return (
    req.headers.get('x-forwarded-for') ||
    req.headers.get('x-real-ip') ||
    null
  )
}

/** Create a new shipment for the order. */
export async function POST(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const order = await db.order.findUnique({
      where: { id },
      include: { shipment: true },
    })
    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 })
    }
    if (order.shipment) {
      return NextResponse.json(
        { error: 'این سفارش قبلاً محموله ثبت شده است. از ویرایش استفاده کنید.' },
        { status: 400 },
      )
    }

    const carrier = String(body?.carrier ?? '').trim()
    if (!CARRIERS.includes(carrier as (typeof CARRIERS)[number])) {
      return NextResponse.json({ error: 'حامل نامعتبر است' }, { status: 400 })
    }
    const status = String(body?.status ?? 'PENDING')
    if (!SHIPMENT_STATUS.includes(status as (typeof SHIPMENT_STATUS)[number])) {
      return NextResponse.json({ error: 'وضعیت نامعتبر است' }, { status: 400 })
    }
    const trackingCode = body?.trackingCode ? String(body.trackingCode).trim() : null
    const note = body?.note ? String(body.note) : null

    const now = new Date()
    const shippedAt = status === 'DISPATCHED' || status === 'IN_TRANSIT' || status === 'DELIVERED' ? now : null
    const deliveredAt = status === 'DELIVERED' ? now : null

    const shipment = await db.shipment.create({
      data: {
        orderId: id,
        carrier,
        trackingCode,
        status,
        shippedAt,
        deliveredAt,
        note,
      },
    })

    // If delivered, advance the order status too.
    let orderStatusUpdate: string | null = null
    if (status === 'DELIVERED' && order.status !== 'DELIVERED') {
      orderStatusUpdate = 'DELIVERED'
      await db.order.update({ where: { id }, data: { status: 'DELIVERED' } })
    } else if (
      (status === 'DISPATCHED' || status === 'IN_TRANSIT') &&
      order.status === 'PENDING'
    ) {
      orderStatusUpdate = 'PROCESSING'
      await db.order.update({ where: { id }, data: { status: 'PROCESSING' } })
    }

    await logAudit({
      admin: session,
      action: 'CREATE_SHIPMENT',
      entity: 'Shipment',
      entityId: shipment.id,
      after: {
        orderId: id,
        carrier,
        trackingCode,
        status,
        orderStatusChangedTo: orderStatusUpdate,
      },
      ipAddress: await getIp(req),
    })

    return NextResponse.json({ ok: true, shipment, orderStatusChangedTo: orderStatusUpdate })
  } catch (err) {
    console.error('[shipment] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

/** Update the existing shipment for the order. */
export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const order = await db.order.findUnique({
      where: { id },
      include: { shipment: true },
    })
    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 })
    }
    if (!order.shipment) {
      return NextResponse.json(
        { error: 'محموله‌ای برای این سفارش ثبت نشده است. ابتدا ایجاد کنید.' },
        { status: 404 },
      )
    }

    const data: Record<string, unknown> = {}
    if (body?.carrier != null) {
      const carrier = String(body.carrier).trim()
      if (!CARRIERS.includes(carrier as (typeof CARRIERS)[number])) {
        return NextResponse.json({ error: 'حامل نامعتبر است' }, { status: 400 })
      }
      data.carrier = carrier
    }
    if (body?.trackingCode !== undefined) {
      data.trackingCode = body.trackingCode ? String(body.trackingCode).trim() : null
    }
    if (body?.note !== undefined) {
      data.note = body.note ? String(body.note) : null
    }
    if (body?.status != null) {
      const status = String(body.status)
      if (!SHIPMENT_STATUS.includes(status as (typeof SHIPMENT_STATUS)[number])) {
        return NextResponse.json({ error: 'وضعیت نامعتبر است' }, { status: 400 })
      }
      data.status = status
      const now = new Date()
      const prevStatus = order.shipment.status
      // Set shippedAt when first moving to DISPATCHED/IN_TRANSIT/DELIVERED.
      if (
        !order.shipment.shippedAt &&
        (status === 'DISPATCHED' || status === 'IN_TRANSIT' || status === 'DELIVERED')
      ) {
        data.shippedAt = now
      }
      // Set deliveredAt when moving to DELIVERED.
      if (!order.shipment.deliveredAt && status === 'DELIVERED') {
        data.deliveredAt = now
      }
      // If reverting back to PENDING, clear timestamps.
      if (status === 'PENDING') {
        data.shippedAt = null
        data.deliveredAt = null
      }
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ ok: true, shipment: order.shipment })
    }

    const updated = await db.shipment.update({
      where: { orderId: id },
      data,
    })

    // Side effects on order status:
    let orderStatusChangedTo: string | null = null
    if (updated.status === 'DELIVERED' && order.status !== 'DELIVERED') {
      orderStatusChangedTo = 'DELIVERED'
      await db.order.update({ where: { id }, data: { status: 'DELIVERED' } })
    } else if (
      (updated.status === 'DISPATCHED' || updated.status === 'IN_TRANSIT') &&
      order.status === 'PENDING'
    ) {
      orderStatusChangedTo = 'PROCESSING'
      await db.order.update({ where: { id }, data: { status: 'PROCESSING' } })
    }

    await logAudit({
      admin: session,
      action: 'UPDATE_SHIPMENT',
      entity: 'Shipment',
      entityId: updated.id,
      before: {
        carrier: order.shipment.carrier,
        trackingCode: order.shipment.trackingCode,
        status: order.shipment.status,
        note: order.shipment.note,
      },
      after: {
        carrier: updated.carrier,
        trackingCode: updated.trackingCode,
        status: updated.status,
        note: updated.note,
        orderStatusChangedTo,
      },
      ipAddress: await getIp(req),
    })

    return NextResponse.json({
      ok: true,
      shipment: updated,
      orderStatusChangedTo,
    })
  } catch (err) {
    console.error('[shipment] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
