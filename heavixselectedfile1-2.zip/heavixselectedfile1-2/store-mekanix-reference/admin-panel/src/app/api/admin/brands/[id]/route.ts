import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.brand.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'برند یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}

    if (body?.name != null) {
      const name = String(body.name).trim()
      if (!name) {
        return NextResponse.json({ error: 'نام نمی‌تواند خالی باشد' }, { status: 400 })
      }
      data.name = name
      // Re-slugify on rename
      const newSlug = (() => {
        const out = name
          .trim()
          .toLowerCase()
          .replace(/[^\w\u0600-\u06FF]+/g, '-')
          .replace(/^-+|-+$/g, '')
        return out || `brand-${Date.now()}`
      })()
      if (newSlug !== existing.slug) {
        const dupe = await db.brand.findUnique({ where: { slug: newSlug } })
        if (dupe && dupe.id !== id) {
          return NextResponse.json(
            { error: 'این نام (slug) قبلاً استفاده شده است' },
            { status: 400 },
          )
        }
        data.slug = newSlug
      }
    }

    if (body?.country !== undefined) {
      data.country =
        body.country && String(body.country).trim()
          ? String(body.country).trim()
          : null
    }
    if (body?.logoUrl !== undefined) {
      data.logoUrl =
        body.logoUrl && String(body.logoUrl).trim()
          ? String(body.logoUrl).trim()
          : null
    }

    const updated = await db.brand.update({ where: { id }, data })

    await logAudit({
      admin: session,
      action: 'UPDATE',
      entity: 'Brand',
      entityId: id,
      before: {
        name: existing.name,
        slug: existing.slug,
        country: existing.country,
        logoUrl: existing.logoUrl,
      },
      after: {
        name: updated.name,
        slug: updated.slug,
        country: updated.country,
        logoUrl: updated.logoUrl,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, brand: updated })
  } catch (err) {
    console.error('[brand] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const existing = await db.brand.findUnique({
      where: { id },
      include: { _count: { select: { parts: true } } },
    })
    if (!existing) {
      return NextResponse.json({ error: 'برند یافت نشد' }, { status: 404 })
    }
    if (existing._count.parts > 0) {
      return NextResponse.json(
        {
          error: `این برند به ${existing._count.parts} قطعه متصل است و قابل حذف نیست. ابتدا قطعات را به برند دیگری منتقل کنید.`,
        },
        { status: 400 },
      )
    }

    await db.brand.delete({ where: { id } })

    await logAudit({
      admin: session,
      action: 'DELETE',
      entity: 'Brand',
      entityId: id,
      before: { name: existing.name, slug: existing.slug },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[brand] DELETE error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
