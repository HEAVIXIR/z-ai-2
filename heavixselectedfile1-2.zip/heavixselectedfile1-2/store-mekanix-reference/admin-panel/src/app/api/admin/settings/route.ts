import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export async function GET() {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const [settings, stats] = await Promise.all([
      db.setting.findMany(),
      Promise.all([
        db.part.count(),
        db.customer.count(),
        db.mechanic.count(),
        db.order.count(),
        db.payment.count(),
        db.auditLog.count(),
        db.adminUser.count(),
        db.coupon.count(),
        db.review.count(),
      ]),
    ])

    const settingsMap: Record<string, string> = {}
    for (const s of settings) {
      settingsMap[s.id] = s.value
    }

    const [
      parts,
      customers,
      mechanics,
      orders,
      payments,
      auditLogs,
      adminUsers,
      coupons,
      reviews,
    ] = stats

    return NextResponse.json({
      settings: settingsMap,
      stats: {
        parts,
        customers,
        mechanics,
        orders,
        payments,
        auditLogs,
        adminUsers,
        coupons,
        reviews,
      },
    })
  } catch (err) {
    console.error('[settings] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function PUT(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      return NextResponse.json({ error: 'بدنه نامعتبر است' }, { status: 400 })
    }

    // Fetch existing settings for diff
    const existing = await db.setting.findMany()
    const existingMap = new Map(existing.map((s) => [s.id, s.value]))

    const changes: Array<{ key: string; before: string | null; after: string }> = []
    const ops: Promise<unknown>[] = []

    for (const [key, value] of Object.entries(body)) {
      if (typeof key !== 'string') continue
      const valStr = value == null ? '' : String(value)
      const before = existingMap.get(key) ?? null
      if (before === valStr) continue // no change
      changes.push({ key, before, after: valStr })
      ops.push(
        db.setting.upsert({
          where: { id: key },
          update: { value: valStr },
          create: { id: key, value: valStr },
        }),
      )
    }

    if (ops.length === 0) {
      return NextResponse.json({ ok: true, changes: [] })
    }

    await Promise.all(ops)

    await logAudit({
      admin: session,
      action: 'UPDATE',
      entity: 'Setting',
      after: { changes },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, changes })
  } catch (err) {
    console.error('[settings] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
