import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { todayTehran } from '@/lib/currency'
import { logAudit } from '@/lib/audit'

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const rate = Number(body?.rate)
    if (!Number.isFinite(rate) || rate <= 0) {
      return NextResponse.json(
        { error: 'نرخ نامعتبر است' },
        { status: 400 },
      )
    }
    const marginPercent =
      body?.marginPercent != null && body.marginPercent !== ''
        ? Number(body.marginPercent)
        : null

    const note = body?.note ? String(body.note).slice(0, 500) : null

    const today = todayTehran()
    const existing = await db.currencyRate.findUnique({ where: { date: today } })

    const setting = await db.currencySetting.findUnique({
      where: { id: 'singleton' },
    })
    const effectiveMargin =
      marginPercent != null && Number.isFinite(marginPercent)
        ? marginPercent
        : setting?.marginPercent ?? 0

    const upserted = await db.currencyRate.upsert({
      where: { date: today },
      create: {
        date: today,
        rate,
        marginPercent: effectiveMargin,
        source: 'MANUAL',
        note,
        setById: session.id,
      },
      update: {
        rate,
        marginPercent: effectiveMargin,
        source: 'MANUAL',
        note,
        setById: session.id,
      },
      include: {
        setBy: { select: { id: true, name: true, username: true } },
      },
    })

    await logAudit({
      admin: session,
      action: 'SET_TODAY_RATE',
      entity: 'CurrencyRate',
      entityId: upserted.id,
      before: existing
        ? { rate: existing.rate, source: existing.source }
        : null,
      after: { rate, source: 'MANUAL', marginPercent: effectiveMargin },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, rate: upserted })
  } catch (err) {
    console.error('[currency/rate] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const today = todayTehran()
    const existing = await db.currencyRate.findUnique({
      where: { date: today },
    })
    if (!existing) {
      return NextResponse.json({ ok: true, deleted: false })
    }
    await db.currencyRate.delete({ where: { date: today } })
    await logAudit({
      admin: session,
      action: 'DELETE_TODAY_RATE',
      entity: 'CurrencyRate',
      entityId: existing.id,
      before: { rate: existing.rate, source: existing.source, date: today },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })
    return NextResponse.json({ ok: true, deleted: true })
  } catch (err) {
    console.error('[currency/rate] DELETE error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
