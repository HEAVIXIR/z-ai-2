import { NextRequest, NextResponse } from 'next/server'
import { requireSession } from '@/lib/auth'
import { refreshTelegramRateInDB } from '@/lib/telegram-rate'

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const rate = await refreshTelegramRateInDB()
    if (!rate) {
      return NextResponse.json(
        { error: 'دریافت نرخ از تلگرام ناموفق بود' },
        { status: 502 },
      )
    }
    // best-effort audit
    try {
      const { logAudit } = await import('@/lib/audit')
      await logAudit({
        admin: session,
        action: 'REFRESH_TELEGRAM_RATE',
        entity: 'CurrencySetting',
        entityId: 'singleton',
        after: { rate: rate.rate, status: rate.status },
        ipAddress:
          req.headers.get('x-forwarded-for') ||
          req.headers.get('x-real-ip') ||
          null,
      })
    } catch {
      // ignore
    }

    return NextResponse.json({ ok: true, rate })
  } catch (err) {
    console.error('[currency/refresh] error:', err)
    return NextResponse.json(
      { error: 'خطا در بروزرسانی نرخ از تلگرام' },
      { status: 500 },
    )
  }
}
