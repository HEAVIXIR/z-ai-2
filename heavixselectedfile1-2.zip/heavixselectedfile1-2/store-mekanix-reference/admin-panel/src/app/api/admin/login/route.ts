import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSession } from '@/lib/auth'
import { verifyPassword } from '@/lib/password'
import { logAudit } from '@/lib/audit'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const username = String(body?.username ?? '').trim()
    const password = String(body?.password ?? '')

    if (!username || !password) {
      return NextResponse.json(
        { error: 'نام کاربری و رمز عبور الزامی است' },
        { status: 400 },
      )
    }

    const admin = await db.adminUser.findUnique({
      where: { username },
      select: {
        id: true,
        username: true,
        name: true,
        role: true,
        active: true,
        passwordHash: true,
      },
    })

    if (!admin || !admin.active || !admin.passwordHash) {
      return NextResponse.json(
        { error: 'کاربری با این مشخصات یافت نشد' },
        { status: 401 },
      )
    }

    const ok = verifyPassword(password, admin.passwordHash)
    if (!ok) {
      return NextResponse.json(
        { error: 'رمز عبور نادرست است' },
        { status: 401 },
      )
    }

    await db.adminUser.update({
      where: { id: admin.id },
      data: { lastLoginAt: new Date() },
    })

    const payload = {
      id: admin.id,
      username: admin.username,
      name: admin.name,
      role: admin.role as 'SUPER_ADMIN' | 'ADMIN' | 'OPERATOR',
    }
    await createSession(payload)

    await logAudit({
      admin: payload,
      action: 'LOGIN',
      entity: 'AdminUser',
      entityId: admin.id,
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, admin: payload })
  } catch (err) {
    console.error('[admin/login] error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({ error: 'method not allowed' }, { status: 405 })
}
