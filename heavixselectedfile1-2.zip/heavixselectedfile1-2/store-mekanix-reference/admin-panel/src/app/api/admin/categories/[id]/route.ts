import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.category.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'دسته یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}

    if (body?.name != null) {
      const name = String(body.name).trim()
      if (!name) {
        return NextResponse.json({ error: 'نام نمی‌تواند خالی باشد' }, { status: 400 })
      }
      data.name = name
      // Re-slugify when name changes (only if no other category uses it)
      const newSlug = (() => {
        const out = name
          .trim()
          .toLowerCase()
          .replace(/[^\w\u0600-\u06FF]+/g, '-')
          .replace(/^-+|-+$/g, '')
        return out || `cat-${Date.now()}`
      })()
      if (newSlug !== existing.slug) {
        const dupe = await db.category.findUnique({ where: { slug: newSlug } })
        if (dupe && dupe.id !== id) {
          return NextResponse.json(
            { error: 'این نام (slug) قبلاً استفاده شده است' },
            { status: 400 },
          )
        }
        data.slug = newSlug
      }
    }

    if (body?.icon !== undefined) {
      data.icon = body.icon && String(body.icon).trim() ? String(body.icon).trim() : null
    }

    if (body?.parentId !== undefined) {
      const parentId =
        body.parentId && String(body.parentId).trim()
          ? String(body.parentId).trim()
          : null

      // Prevent self-parenting
      if (parentId && parentId === id) {
        return NextResponse.json(
          { error: 'دسته نمی‌تواند والد خودش باشد' },
          { status: 400 },
        )
      }
      // Prevent parenting to one of own descendants
      if (parentId) {
        const parent = await db.category.findUnique({ where: { id: parentId } })
        if (!parent) {
          return NextResponse.json(
            { error: 'دسته والد یافت نشد' },
            { status: 400 },
          )
        }
        if (parent.parentId) {
          return NextResponse.json(
            { error: 'حداکثر عمق دسته‌بندی ۲ سطح مجاز است' },
            { status: 400 },
          )
        }
        if (parent.parentId === id) {
          return NextResponse.json(
            { error: 'چرخه در ساختار دسته‌بندی ایجاد می‌شود' },
            { status: 400 },
          )
        }
      }
      data.parentId = parentId
    }

    const updated = await db.category.update({
      where: { id },
      data,
    })

    await logAudit({
      admin: session,
      action: 'UPDATE',
      entity: 'Category',
      entityId: id,
      before: {
        name: existing.name,
        slug: existing.slug,
        icon: existing.icon,
        parentId: existing.parentId,
      },
      after: {
        name: updated.name,
        slug: updated.slug,
        icon: updated.icon,
        parentId: updated.parentId,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, category: updated })
  } catch (err) {
    console.error('[category] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const existing = await db.category.findUnique({
      where: { id },
      include: { _count: { select: { parts: true, children: true } } },
    })
    if (!existing) {
      return NextResponse.json({ error: 'دسته یافت نشد' }, { status: 404 })
    }
    if (existing._count.parts > 0) {
      return NextResponse.json(
        {
          error: `این دسته شامل ${existing._count.parts} قطعه است و قابل حذف نیست. ابتدا قطعات را به دسته دیگری منتقل کنید.`,
        },
        { status: 400 },
      )
    }
    if (existing._count.children > 0) {
      return NextResponse.json(
        {
          error: `این دسته شامل ${existing._count.children} زیردسته است و قابل حذف نیست. ابتدا زیردسته‌ها را حذف یا منتقل کنید.`,
        },
        { status: 400 },
      )
    }

    await db.category.delete({ where: { id } })

    await logAudit({
      admin: session,
      action: 'DELETE',
      entity: 'Category',
      entityId: id,
      before: { name: existing.name, slug: existing.slug },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[category] DELETE error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
