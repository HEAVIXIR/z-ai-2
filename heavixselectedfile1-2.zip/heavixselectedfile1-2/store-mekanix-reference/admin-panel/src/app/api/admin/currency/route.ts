import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { getEffectiveRate, todayTehran } from '@/lib/currency'
import { fetchTelegramRate } from '@/lib/telegram-rate'

export async function GET() {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const today = todayTehran()
    const [setting, todayRate, history, telegram] = await Promise.all([
      db.currencySetting.findUnique({ where: { id: 'singleton' } }),
      db.currencyRate.findUnique({
        where: { date: today },
        include: { setBy: { select: { id: true, name: true, username: true } } },
      }),
      db.currencyRate.findMany({
        orderBy: { date: 'desc' },
        take: 30,
        include: { setBy: { select: { id: true, name: true, username: true } } },
      }),
      fetchTelegramRate(),
    ])

    const effective = await getEffectiveRate()

    return NextResponse.json({
      date: today,
      effective,
      setting: setting
        ? {
            defaultRate: setting.defaultRate,
            marginPercent: setting.marginPercent,
            autoUpdateEnabled: setting.autoUpdateEnabled,
            autoSource: setting.autoSource,
            lastAutoRate: setting.lastAutoRate,
            lastAutoStatus: setting.lastAutoStatus,
            lastAutoFetchAt: setting.lastAutoFetchAt,
            updatedAt: setting.updatedAt,
          }
        : null,
      todayRate: todayRate
        ? {
            date: todayRate.date,
            rate: todayRate.rate,
            marginPercent: todayRate.marginPercent,
            source: todayRate.source,
            note: todayRate.note,
            setBy: todayRate.setBy
              ? {
                  id: todayRate.setBy.id,
                  name: todayRate.setBy.name,
                  username: todayRate.setBy.username,
                }
              : null,
            createdAt: todayRate.createdAt,
          }
        : null,
      telegram: telegram
        ? {
            rate: telegram.rate,
            status: telegram.status,
            fetchedAt: telegram.fetchedAt,
          }
        : null,
      history: history.map((h) => ({
        id: h.id,
        date: h.date,
        rate: h.rate,
        marginPercent: h.marginPercent,
        source: h.source,
        note: h.note,
        setBy: h.setBy
          ? { id: h.setBy.id, name: h.setBy.name, username: h.setBy.username }
          : null,
        createdAt: h.createdAt,
      })),
    })
  } catch (err) {
    console.error('[currency] GET error:', err)
    return NextResponse.json(
      { error: 'خطا در بارگذاری نرخ ارز' },
      { status: 500 },
    )
  }
}
