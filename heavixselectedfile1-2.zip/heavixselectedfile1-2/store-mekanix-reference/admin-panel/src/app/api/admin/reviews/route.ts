import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const url = new URL(req.url)
    const status = (url.searchParams.get('status') || 'pending').toLowerCase()
    const partId = url.searchParams.get('partId') || undefined
    const q = url.searchParams.get('q')?.trim() || ''
    const page = Math.max(1, Number(url.searchParams.get('page')) || 1)
    const pageSize = Math.min(
      100,
      Math.max(1, Number(url.searchParams.get('pageSize')) || 50),
    )

    const where: Record<string, unknown> = {}
    if (status === 'pending') where.approved = false
    else if (status === 'approved') where.approved = true
    // status === 'rejected' is not directly supported by our schema
    // (only approved boolean exists). Treat 'rejected' as pending-and-reviewed
    // i.e. show pending; the UI shows approve/reject which both go via PATCH.
    // For 'all' we apply no filter.
    if (partId) where.partId = partId
    if (q) {
      where.OR = [
        { title: { contains: q } },
        { comment: { contains: q } },
        { part: { name: { contains: q } } },
        { customer: { name: { contains: q } } },
        { customer: { phone: { contains: q } } },
      ]
    }

    const [total, reviews] = await Promise.all([
      db.review.count({ where }),
      db.review.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          part: { select: { id: true, name: true, sku: true } },
          customer: { select: { id: true, name: true, family: true, phone: true } },
        },
      }),
    ])

    return NextResponse.json({
      reviews: reviews.map((r) => ({
        id: r.id,
        partId: r.partId,
        customerId: r.customerId,
        rating: r.rating,
        title: r.title ?? null,
        comment: r.comment ?? null,
        approved: r.approved,
        reviewedById: r.reviewedById ?? null,
        createdAt: r.createdAt,
        part: r.part
          ? { id: r.part.id, name: r.part.name, sku: r.part.sku }
          : null,
        customer: r.customer
          ? {
              id: r.customer.id,
              name: r.customer.name,
              family: r.customer.family,
              phone: r.customer.phone,
              fullName: `${r.customer.name} ${r.customer.family}`.trim(),
            }
          : null,
      })),
      total,
      page,
      pageSize,
    })
  } catch (err) {
    console.error('[reviews] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
