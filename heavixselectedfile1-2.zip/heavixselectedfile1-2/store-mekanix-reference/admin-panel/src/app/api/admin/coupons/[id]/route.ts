import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.coupon.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'کد تخفیف یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}

    if (body?.code != null) {
      const code = String(body.code).trim().toUpperCase()
      if (!code) {
        return NextResponse.json({ error: 'کد نمی‌تواند خالی باشد' }, { status: 400 })
      }
      const dupe = await db.coupon.findUnique({ where: { code } })
      if (dupe && dupe.id !== id) {
        return NextResponse.json(
          { error: 'این کد قبلاً استفاده شده است' },
          { status: 400 },
        )
      }
      data.code = code
    }
    if (body?.type != null) {
      const t = String(body.type).toUpperCase()
      if (t !== 'PERCENT' && t !== 'FIXED') {
        return NextResponse.json({ error: 'نوع تخفیف نامعتبر است' }, { status: 400 })
      }
      data.type = t
    }
    if (body?.value != null) {
      const v = Number(body.value)
      if (!Number.isFinite(v) || v <= 0) {
        return NextResponse.json({ error: 'مقدار نامعتبر است' }, { status: 400 })
      }
      if (data.type === 'PERCENT' && v > 100) {
        return NextResponse.json(
          { error: 'درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد' },
          { status: 400 },
        )
      }
      // Also check if existing type is PERCENT (in case type not provided)
      const effectiveType =
        (data.type as string | undefined) || existing.type
      if (effectiveType === 'PERCENT' && v > 100) {
        return NextResponse.json(
          { error: 'درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد' },
          { status: 400 },
        )
      }
      data.value = v
    }
    if (body?.expiresAt !== undefined) {
      if (body.expiresAt === null || body.expiresAt === '') {
        data.expiresAt = null
      } else {
        const d = new Date(body.expiresAt)
        if (isNaN(d.getTime())) {
          return NextResponse.json(
            { error: 'تاریخ انقضا نامعتبر است' },
            { status: 400 },
          )
        }
        data.expiresAt = d
      }
    }
    if (body?.usageLimit != null) {
      data.usageLimit = Math.max(0, Number(body.usageLimit) || 0)
    }
    if (body?.minOrderIrr != null) {
      data.minOrderIrr = Math.max(0, Number(body.minOrderIrr) || 0)
    }
    if (body?.active != null) {
      data.active = !!body.active
    }

    const updated = await db.coupon.update({ where: { id }, data })

    await logAudit({
      admin: session,
      action: 'UPDATE',
      entity: 'Coupon',
      entityId: id,
      before: {
        code: existing.code,
        type: existing.type,
        value: existing.value,
        expiresAt: existing.expiresAt,
        usageLimit: existing.usageLimit,
        minOrderIrr: existing.minOrderIrr,
        active: existing.active,
      },
      after: {
        code: updated.code,
        type: updated.type,
        value: updated.value,
        expiresAt: updated.expiresAt,
        usageLimit: updated.usageLimit,
        minOrderIrr: updated.minOrderIrr,
        active: updated.active,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, coupon: updated })
  } catch (err) {
    console.error('[coupon] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const existing = await db.coupon.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'کد تخفیف یافت نشد' }, { status: 404 })
    }
    if (existing.usedCount > 0) {
      return NextResponse.json(
        {
          error: `این کد ${existing.usedCount} بار استفاده شده و قابل حذف نیست. به‌جای حذف، آن را غیرفعال کنید.`,
        },
        { status: 400 },
      )
    }

    await db.coupon.delete({ where: { id } })

    await logAudit({
      admin: session,
      action: 'DELETE',
      entity: 'Coupon',
      entityId: id,
      before: { code: existing.code, type: existing.type, value: existing.value },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[coupon] DELETE error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
