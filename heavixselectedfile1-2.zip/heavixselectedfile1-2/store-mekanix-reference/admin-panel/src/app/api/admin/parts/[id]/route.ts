import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { getEffectiveRate, usdToIrr } from '@/lib/currency'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

function safeParseArray(s: string | null | undefined): string[] {
  if (!s) return []
  try {
    const v = JSON.parse(s)
    return Array.isArray(v) ? v.map((x) => String(x)) : []
  } catch {
    return s.split(',').map((x) => x.trim()).filter(Boolean)
  }
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const part = await db.part.findUnique({
      where: { id },
      include: {
        category: { select: { id: true, name: true } },
        brand: { select: { id: true, name: true } },
        carModels: { select: { id: true, brand: true, model: true, yearFrom: true, yearTo: true } },
      },
    })
    if (!part) {
      return NextResponse.json({ error: 'قطعه یافت نشد' }, { status: 404 })
    }
    const eff = await getEffectiveRate()
    const priceIrr = usdToIrr(part.priceUsd, { rate: eff.rate, marginPercent: eff.marginPercent })
    return NextResponse.json({
      ...part,
      images: safeParseArray(part.images),
      compatibleCars: safeParseArray(part.compatibleCars),
      priceIrr,
      oldPriceIrr: part.oldPriceUsd
        ? usdToIrr(part.oldPriceUsd, { rate: eff.rate, marginPercent: eff.marginPercent })
        : null,
      effectiveRate: eff,
    })
  } catch (err) {
    console.error('[part] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.part.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'قطعه یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (body?.name != null) data.name = String(body.name).trim()
    if (body?.nameFa != null) data.nameFa = body.nameFa ? String(body.nameFa) : null
    if (body?.sku != null) {
      const sku = String(body.sku).trim()
      const dupe = await db.part.findUnique({ where: { sku } })
      if (dupe && dupe.id !== id) {
        return NextResponse.json({ error: 'این SKU قبلاً ثبت شده است' }, { status: 400 })
      }
      data.sku = sku
    }
    if (body?.categoryId != null) data.categoryId = String(body.categoryId)
    if (body?.brandId !== undefined) {
      data.brandId = body.brandId ? String(body.brandId) : null
    }
    if (body?.description !== undefined) {
      data.description = body.description ? String(body.description) : null
    }
    if (body?.priceUsd != null) {
      const v = Number(body.priceUsd)
      if (!Number.isFinite(v) || v < 0) {
        return NextResponse.json({ error: 'قیمت نامعتبر است' }, { status: 400 })
      }
      data.priceUsd = v
    }
    if (body?.oldPriceUsd !== undefined) {
      data.oldPriceUsd =
        body.oldPriceUsd === null || body.oldPriceUsd === ''
          ? null
          : Number(body.oldPriceUsd)
    }
    if (body?.stock != null) {
      const v = Number(body.stock)
      if (!Number.isFinite(v) || v < 0) {
        return NextResponse.json({ error: 'موجودی نامعتبر است' }, { status: 400 })
      }
      data.stock = v
    }
    if (body?.lowStockThreshold != null) {
      data.lowStockThreshold = Number(body.lowStockThreshold) || 5
    }
    if (body?.images !== undefined) {
      const imgs = Array.isArray(body.images)
        ? body.images.map(String)
        : typeof body.images === 'string'
          ? body.images.split(',').map((s: string) => s.trim()).filter(Boolean)
          : []
      data.images = JSON.stringify(imgs)
    }
    if (body?.compatibleCars !== undefined) {
      const arr = Array.isArray(body.compatibleCars)
        ? body.compatibleCars.map(String)
        : []
      data.compatibleCars = JSON.stringify(arr)
    }
    if (body?.active != null) data.active = !!body.active
    if (body?.featured != null) data.featured = !!body.featured

    // Car models — sync via set/disconnect.
    if (Array.isArray(body?.carModelIds)) {
      const newIds = body.carModelIds.map(String).filter(Boolean)
      const current = await db.part.findUnique({
        where: { id },
        select: { carModels: { select: { id: true } } },
      })
      const currentIds = (current?.carModels ?? []).map((c) => c.id)
      const toDisconnect = currentIds.filter((cid) => !newIds.includes(cid))
      const toConnect = newIds.filter((nid) => !currentIds.includes(nid))
      data.carModels = {
        disconnect: toDisconnect.map((cid) => ({ id: cid })),
        connect: toConnect.map((nid) => ({ id: nid })),
      }
    }

    const updated = await db.part.update({
      where: { id },
      data,
      include: {
        category: { select: { id: true, name: true } },
        brand: { select: { id: true, name: true } },
        carModels: { select: { id: true, brand: true, model: true, yearFrom: true, yearTo: true } },
      },
    })

    await logAudit({
      admin: session,
      action: 'UPDATE_PART',
      entity: 'Part',
      entityId: id,
      before: {
        name: existing.name,
        sku: existing.sku,
        priceUsd: existing.priceUsd,
        stock: existing.stock,
        active: existing.active,
        featured: existing.featured,
      },
      after: {
        name: updated.name,
        sku: updated.sku,
        priceUsd: updated.priceUsd,
        stock: updated.stock,
        active: updated.active,
        featured: updated.featured,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, part: updated })
  } catch (err) {
    console.error('[part] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const existing = await db.part.findUnique({
      where: { id },
      include: { _count: { select: { orderItems: true } } },
    })
    if (!existing) {
      return NextResponse.json({ error: 'قطعه یافت نشد' }, { status: 404 })
    }
    if (existing._count.orderItems > 0) {
      return NextResponse.json(
        {
          error: `این قطعه در ${existing._count.orderItems} آیتم سفارش استفاده شده و قابل حذف نیست. به جای آن، قطعه را غیرفعال کنید.`,
        },
        { status: 400 },
      )
    }

    await db.part.delete({ where: { id } })

    await logAudit({
      admin: session,
      action: 'DELETE_PART',
      entity: 'Part',
      entityId: id,
      before: { name: existing.name, sku: existing.sku },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[part] DELETE error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
