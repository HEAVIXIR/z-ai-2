import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

export function slugify(s: string): string {
  const out = s
    .trim()
    .toLowerCase()
    .replace(/[^\w\u0600-\u06FF]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return out || `cat-${Date.now()}`
}

export async function GET() {
  try {
    await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const [categories, partsCount] = await Promise.all([
      db.category.findMany({
        orderBy: { name: 'asc' },
        include: {
          _count: { select: { parts: true, children: true } },
          children: {
            include: {
              _count: { select: { parts: true, children: true } },
            },
          },
        },
      }),
      db.part.groupBy({
        by: ['categoryId'],
        _count: true,
      }),
    ])

    const countByCat = new Map<string, number>()
    for (const g of partsCount) {
      countByCat.set(g.categoryId, g._count)
    }

    const tree = categories.map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      icon: c.icon ?? null,
      parentId: c.parentId,
      partsCount: c._count.parts,
      childrenCount: c._count.children,
      children: c.children.map((ch) => ({
        id: ch.id,
        name: ch.name,
        slug: ch.slug,
        icon: ch.icon ?? null,
        parentId: ch.parentId,
        partsCount: ch._count.parts,
        childrenCount: ch._count.children,
      })),
    }))

    const flat = categories.flatMap((c) => [
      {
        id: c.id,
        name: c.name,
        slug: c.slug,
        parentId: c.parentId,
        partsCount: c._count.parts,
      },
      ...c.children.map((ch) => ({
        id: ch.id,
        name: ch.name,
        slug: ch.slug,
        parentId: ch.parentId,
        partsCount: ch._count.parts,
      })),
    ])

    return NextResponse.json({ tree, flat, countByCat: Object.fromEntries(countByCat) })
  } catch (err) {
    console.error('[categories] GET error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const name = String(body?.name ?? '').trim()
    if (!name) {
      return NextResponse.json({ error: 'نام دسته الزامی است' }, { status: 400 })
    }

    const parentId =
      body?.parentId && String(body.parentId).trim()
        ? String(body.parentId).trim()
        : null

    // Validate parent if provided
    if (parentId) {
      const parent = await db.category.findUnique({ where: { id: parentId } })
      if (!parent) {
        return NextResponse.json({ error: 'دسته والد یافت نشد' }, { status: 400 })
      }
      // Prevent a 3rd level (parent must not itself have a parent) — keep tree 2-level
      if (parent.parentId) {
        return NextResponse.json(
          { error: 'نمی‌توان زیردسته‌ی زیردسته ایجاد کرد (حداکثر ۲ سطح)' },
          { status: 400 },
        )
      }
    }

    const icon =
      body?.icon && String(body.icon).trim() ? String(body.icon).trim() : null

    // Build unique slug
    const baseSlug = slugify(name)
    let slug = baseSlug
    let n = 1
    while (await db.category.findUnique({ where: { slug } })) {
      slug = `${baseSlug}-${n++}`
    }

    const created = await db.category.create({
      data: {
        name,
        slug,
        icon,
        parentId,
      },
    })

    await logAudit({
      admin: session,
      action: 'CREATE',
      entity: 'Category',
      entityId: created.id,
      after: { name: created.name, slug: created.slug, parentId, icon },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, category: created }, { status: 201 })
  } catch (err) {
    console.error('[categories] POST error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
