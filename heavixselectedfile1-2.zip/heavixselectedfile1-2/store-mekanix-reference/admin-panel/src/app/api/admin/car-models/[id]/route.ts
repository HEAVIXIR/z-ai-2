import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSession } from '@/lib/auth'
import { logAudit } from '@/lib/audit'

interface Ctx {
  params: Promise<{ id: string }>
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const body = await req.json().catch(() => ({}))

    const existing = await db.carModel.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'مدل خودرو یافت نشد' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (body?.brand != null) {
      const brand = String(body.brand).trim()
      if (!brand) {
        return NextResponse.json({ error: 'برند خالی نیست' }, { status: 400 })
      }
      data.brand = brand
    }
    if (body?.model != null) {
      const model = String(body.model).trim()
      if (!model) {
        return NextResponse.json({ error: 'مدل خالی نیست' }, { status: 400 })
      }
      data.model = model
    }
    if (body?.yearFrom != null) {
      const yf = Number(body.yearFrom)
      if (!Number.isFinite(yf) || yf < 1900 || yf > 2100) {
        return NextResponse.json({ error: 'سال شروع نامعتبر است' }, { status: 400 })
      }
      data.yearFrom = yf
    }
    if (body?.yearTo != null) {
      const yt = Number(body.yearTo)
      if (!Number.isFinite(yt) || yt < 1900 || yt > 2100) {
        return NextResponse.json({ error: 'سال پایان نامعتبر است' }, { status: 400 })
      }
      data.yearTo = yt
    }
    if (
      (data.yearFrom as number | undefined) !== undefined &&
      (data.yearTo as number | undefined) !== undefined &&
      (data.yearFrom as number) > (data.yearTo as number)
    ) {
      return NextResponse.json(
        { error: 'سال پایان باید بزرگ‌تر یا مساوی سال شروع باشد' },
        { status: 400 },
      )
    }

    const updated = await db.carModel.update({ where: { id }, data })

    await logAudit({
      admin: session,
      action: 'UPDATE',
      entity: 'CarModel',
      entityId: id,
      before: {
        brand: existing.brand,
        model: existing.model,
        yearFrom: existing.yearFrom,
        yearTo: existing.yearTo,
      },
      after: {
        brand: updated.brand,
        model: updated.model,
        yearFrom: updated.yearFrom,
        yearTo: updated.yearTo,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true, carModel: updated })
  } catch (err) {
    console.error('[car-model] PUT error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  let session
  try {
    session = await requireSession()
  } catch {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await ctx.params
    const existing = await db.carModel.findUnique({
      where: { id },
      include: { _count: { select: { parts: true } } },
    })
    if (!existing) {
      return NextResponse.json({ error: 'مدل خودرو یافت نشد' }, { status: 404 })
    }
    if (existing._count.parts > 0) {
      return NextResponse.json(
        {
          error: `این مدل به ${existing._count.parts} قطعه متصل است و قابل حذف نیست. ابتدا قطعات را ویرایش کنید.`,
        },
        { status: 400 },
      )
    }

    await db.carModel.delete({ where: { id } })

    await logAudit({
      admin: session,
      action: 'DELETE',
      entity: 'CarModel',
      entityId: id,
      before: {
        brand: existing.brand,
        model: existing.model,
        yearFrom: existing.yearFrom,
        yearTo: existing.yearTo,
      },
      ipAddress:
        req.headers.get('x-forwarded-for') ||
        req.headers.get('x-real-ip') ||
        null,
    })

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[car-model] DELETE error:', err)
    return NextResponse.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
