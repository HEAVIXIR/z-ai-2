'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Loader2, Lock, User, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'
import { adminFetch } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'

export default function LoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  // Already logged in? skip to dashboard.
  useEffect(() => {
    adminFetch('/api/admin/me')
      .then((r) => (r.ok ? router.replace('/dashboard') : null))
      .catch(() => {})
  }, [router])

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!username || !password) {
      toast.error('نام کاربری و رمز عبور را وارد کنید')
      return
    }
    setLoading(true)
    try {
      const res = await adminFetch('/api/admin/login', {
        method: 'POST',
        json: { username, password },
      })
      const data = await res.json().catch(() => null)
      if (!res.ok) {
        toast.error(data?.error || 'ورود ناموفق بود')
        return
      }
      toast.success('خوش آمدید')
      router.replace('/dashboard')
    } catch (err) {
      toast.error((err as Error).message || 'خطای شبکه')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-muted via-background to-muted/60 p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">پنل مدیریت</h1>
          <p className="text-sm text-muted-foreground">
            بازار قطعات خودرو
          </p>
        </div>

        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl">ورود به حساب مدیریت</CardTitle>
            <CardDescription>
              برای ادامه، نام کاربری و رمز عبور خود را وارد کنید.
            </CardDescription>
          </CardHeader>
          <form onSubmit={onSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">نام کاربری</Label>
                <div className="relative">
                  <User className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="username"
                    dir="ltr"
                    autoComplete="username"
                    className="pr-9 text-left"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="admin"
                    disabled={loading}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">رمز عبور</Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    dir="ltr"
                    type="password"
                    autoComplete="current-password"
                    className="pr-9 text-left"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    disabled={loading}
                    autoFocus
                  />
                </div>
              </div>
              <Alert>
                <AlertDescription className="text-xs">
                  برای ورود نمایشی از <code className="font-mono">admin</code> /
                  <code className="font-mono"> admin12345</code> استفاده کنید.
                </AlertDescription>
              </Alert>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    در حال ورود...
                  </>
                ) : (
                  'ورود'
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
        <p className="mt-6 text-center text-xs text-muted-foreground">
          هر تغییری که در این پنل اعمال می‌کنید، بلافاصله در اپلیکیشن اصلی
          اعمال می‌شود.
        </p>
      </div>
    </div>
  )
}
