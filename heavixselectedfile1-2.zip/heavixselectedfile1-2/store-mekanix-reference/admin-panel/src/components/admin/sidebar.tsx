'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import {
  LayoutDashboard,
  DollarSign,
  Package,
  Tags,
  ShoppingCart,
  CreditCard,
  Users,
  Wrench,
  Ticket,
  Star,
  UserCog,
  Settings,
  ScrollText,
  ShieldCheck,
  Menu,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import type { SessionPayload } from '@/lib/auth'

interface NavItem {
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  superOnly?: boolean
}

const NAV: NavItem[] = [
  { href: '/dashboard', label: 'داشبورد', icon: LayoutDashboard },
  { href: '/currency', label: 'نرخ ارز', icon: DollarSign },
  { href: '/parts', label: 'قطعات', icon: Package },
  { href: '/categories', label: 'دسته‌ها و برندها', icon: Tags },
  { href: '/orders', label: 'سفارش‌ها', icon: ShoppingCart },
  { href: '/payments', label: 'تایید پرداخت‌ها', icon: CreditCard },
  { href: '/customers', label: 'مشتریان', icon: Users },
  { href: '/mechanics', label: 'مکانیک‌ها', icon: Wrench },
  { href: '/coupons', label: 'کدهای تخفیف', icon: Ticket },
  { href: '/reviews', label: 'نظرات', icon: Star },
  { href: '/admins', label: 'مدیران', icon: UserCog, superOnly: true },
  { href: '/settings', label: 'تنظیمات', icon: Settings },
  { href: '/audit', label: 'لاگ رویدادها', icon: ScrollText },
]

export function Sidebar({ session }: { session: SessionPayload | null }) {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)

  const items = NAV.filter((it) => !it.superOnly || session?.role === 'SUPER_ADMIN')

  const nav = (
    <nav className="flex flex-col gap-1">
      {items.map((it) => {
        const active =
          pathname === it.href || pathname?.startsWith(it.href + '/')
        const Icon = it.icon
        return (
          <Link
            key={it.href}
            href={it.href}
            onClick={() => setMobileOpen(false)}
            className={cn(
              'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
              active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            <span className="truncate">{it.label}</span>
          </Link>
        )
      })}
    </nav>
  )

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:w-64 md:flex-col md:shrink-0 md:border-l md:bg-sidebar md:text-sidebar-foreground">
        <div className="flex h-16 items-center gap-2 border-b px-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-bold">پنل مدیریت</span>
            <span className="text-[11px] text-muted-foreground">بازار قطعات خودرو</span>
          </div>
        </div>
        <div className="thin-scrollbar flex-1 overflow-y-auto p-3">{nav}</div>
      </aside>

      {/* Mobile top bar with menu button */}
      <div className="md:hidden sticky top-0 z-40 flex h-14 items-center gap-3 border-b bg-sidebar px-4">
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setMobileOpen(true)}
          aria-label="باز کردن منو"
        >
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary" />
          <span className="text-sm font-bold">پنل مدیریت</span>
        </div>
      </div>

      {/* Mobile nav drawer */}
      {mobileOpen && (
        <div
          className="md:hidden fixed inset-0 z-50 bg-background/80 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        >
          <div
            className="absolute right-0 top-0 h-full w-72 max-w-[80%] border-l bg-sidebar p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm font-bold">منوی مدیریت</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setMobileOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            {nav}
          </div>
        </div>
      )}

      {/* Mobile horizontal scroll nav (always visible under top bar) */}
      <div className="md:hidden -mt-px border-b bg-sidebar/50">
        <div className="thin-scrollbar flex gap-1 overflow-x-auto px-3 py-2">
          {items.map((it) => {
            const active =
              pathname === it.href || pathname?.startsWith(it.href + '/')
            const Icon = it.icon
            return (
              <Link
                key={it.href}
                href={it.href}
                className={cn(
                  'flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-colors',
                  active
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:bg-accent',
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {it.label}
              </Link>
            )
          })}
        </div>
      </div>
    </>
  )
}
