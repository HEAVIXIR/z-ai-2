'use client'

import { useRouter } from 'next/navigation'
import { Loader2, LogOut, ShieldCheck } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { adminFetch } from '@/lib/client'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import type { SessionPayload } from '@/lib/auth'

const ROLE_LABEL: Record<string, string> = {
  SUPER_ADMIN: 'مدیر ارشد',
  ADMIN: 'مدیر',
  OPERATOR: 'اپراتور',
}

export function Topbar({ session }: { session: SessionPayload | null }) {
  const router = useRouter()
  const [out, setOut] = useState(false)

  if (!session) return null

  async function logout() {
    setOut(true)
    try {
      await adminFetch('/api/admin/logout', { method: 'POST' })
    } catch {
      // ignore — clear client-side regardless
    }
    toast.success('از حساب خود خارج شدید')
    router.replace('/login')
  }

  const initials = (session.name || session.username)
    .split(' ')
    .slice(0, 2)
    .map((s) => s[0])
    .join('')

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b bg-background/95 px-4 backdrop-blur md:px-6">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <ShieldCheck className="h-4 w-4 text-emerald-600" />
        <span className="hidden sm:inline">
          هر تغییری که در این پنل اعمال می‌کنید، بلافاصله در اپلیکیشن اصلی اعمال
          می‌شود.
        </span>
        <span className="sm:hidden">تغییرات بلافاصله اعمال می‌شود</span>
      </div>

      <div className="flex items-center gap-2 md:gap-3">
        <div className="hidden sm:flex flex-col items-end leading-tight">
          <span className="text-sm font-medium">{session.name}</span>
          <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
            {ROLE_LABEL[session.role] || session.role}
          </Badge>
        </div>
        <Avatar className="h-9 w-9">
          <AvatarFallback className="bg-primary text-primary-foreground text-xs">
            {initials || 'A'}
          </AvatarFallback>
        </Avatar>
        <Button
          variant="ghost"
          size="sm"
          onClick={logout}
          disabled={out}
          className="text-destructive hover:text-destructive"
        >
          {out ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <LogOut className="h-4 w-4" />
          )}
          <span className="hidden sm:inline">خروج</span>
        </Button>
      </div>
    </header>
  )
}
