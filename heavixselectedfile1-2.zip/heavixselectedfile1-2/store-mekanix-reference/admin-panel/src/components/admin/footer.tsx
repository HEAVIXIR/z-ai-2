import { ShieldCheck } from 'lucide-react'

export function Footer() {
  return (
    <footer className="mt-auto border-t bg-background px-4 py-4 md:px-6">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 text-xs text-muted-foreground sm:flex-row">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
          <span>پنل مدیریت بازار قطعات خودرو</span>
        </div>
        <span className="text-[11px]">
          © {new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric' }).format(new Date())} — نسخه نمایشی
        </span>
      </div>
    </footer>
  )
}
