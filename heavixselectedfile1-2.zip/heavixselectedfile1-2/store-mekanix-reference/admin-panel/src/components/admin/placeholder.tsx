'use client'

import { Construction } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'

export function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-16 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">
            <Construction className="h-7 w-7" />
          </div>
          <div>
            <p className="text-lg font-medium">این بخش در حال توسعه است</p>
            <p className="mt-1 text-sm text-muted-foreground">
              این صفحه توسط یک عامل دیگر در حال ساخت است و به‌زودی تکمیل می‌شود.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
