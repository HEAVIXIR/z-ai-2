import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

const ACCENTS = {
  emerald: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30',
  amber: 'text-amber-600 bg-amber-50 dark:bg-amber-950/30',
  rose: 'text-rose-600 bg-rose-50 dark:bg-rose-950/30',
  violet: 'text-violet-600 bg-violet-50 dark:bg-violet-950/30',
  cyan: 'text-cyan-600 bg-cyan-50 dark:bg-cyan-950/30',
  slate: 'text-slate-600 bg-slate-100 dark:bg-slate-800/40',
} as const

export type StatAccent = keyof typeof ACCENTS

export interface StatCardProps {
  title: string
  value: React.ReactNode
  sub?: React.ReactNode
  icon?: React.ComponentType<{ className?: string }>
  accent?: StatAccent
}

export function StatCard({
  title,
  value,
  sub,
  icon: Icon,
  accent = 'slate',
}: StatCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4 md:p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-xs font-medium text-muted-foreground">
              {title}
            </p>
            <p className="mt-1.5 text-2xl font-bold tracking-tight tabular-nums">
              {value}
            </p>
            {sub ? (
              <p className="mt-1 truncate text-xs text-muted-foreground">{sub}</p>
            ) : null}
          </div>
          {Icon ? (
            <div
              className={cn(
                'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                ACCENTS[accent],
              )}
            >
              <Icon className="h-5 w-5" />
            </div>
          ) : null}
        </div>
      </CardContent>
    </Card>
  )
}
