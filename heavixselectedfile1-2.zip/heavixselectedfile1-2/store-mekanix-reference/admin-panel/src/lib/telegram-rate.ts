import { db } from './db'
import { todayTehran } from './currency'

/**
 * REAL Telegram channel currency rate fetcher.
 *
 * Reads the public web preview of https://t.me/s/NerkhDollarIRT (no bot token
 * required), parses the latest "دلار تهران" messages, and extracts the live
 * USD->IRR (Toman) rate.
 *
 * Message format on this channel:
 *   دلار تهران | ⛳️ | : 232,500 معامله | ✅ |
 *
 * Statuses: معامله (trade/deal ✅), خرید (buy 🔵), فروش (sell 🔴)
 * We prefer the latest "معامله" (deal) rate as the reference; if none found we
 * fall back to the latest message of any status.
 */

export interface TelegramRate {
  rate: number // raw USD->IRR (Toman), e.g. 232500
  status: string // معامله | خرید | فروش
  fetchedAt: Date
  source: 'telegram'
}

const CHANNEL_URL = 'https://t.me/s/NerkhDollarIRT'
const CACHE_TTL_MS = 60 * 1000 // 1-minute in-memory cache to avoid hammering Telegram

let cache: { rate: TelegramRate | null; at: number } | null = null

/** Parse a message text and extract {rate, status} if it matches the dollar pattern. */
function parseMessage(text: string): { rate: number; status: string } | null {
  const m = text.match(/دلار\s*تهران[^:]*:\s*([\d\u06F0-\u06F9,.۰-۹]+)\s*(معامله|خرید|فروش)/)
  if (!m) return null
  let numStr = m[1].replace(/[,.]/g, '').replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
  numStr = numStr.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
  const rate = parseInt(numStr, 10)
  if (!Number.isFinite(rate) || rate <= 0) return null
  return { rate, status: m[2] }
}

/** Fetch the latest rate from the Telegram channel (with 1-min in-memory cache). */
export async function fetchTelegramRate(force = false): Promise<TelegramRate | null> {
  if (!force && cache && Date.now() - cache.at < CACHE_TTL_MS) {
    return cache.rate
  }
  try {
    const res = await fetch(CHANNEL_URL, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
        'Accept-Language': 'fa,en;q=0.9',
      },
      signal: AbortSignal.timeout(10000),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const html = await res.text()

    const msgRegex = /<div class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/g
    const messages: string[] = []
    let match: RegExpExecArray | null
    while ((match = msgRegex.exec(html)) !== null) {
      const text = match[1]
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<[^>]+>/g, '\n')
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
        .replace(/\n+/g, ' | ')
        .trim()
      messages.push(text)
    }
    if (messages.length === 0) throw new Error('no messages parsed')

    let dealRate: { rate: number; status: string } | null = null
    let anyRate: { rate: number; status: string } | null = null
    for (let i = messages.length - 1; i >= 0; i--) {
      const parsed = parseMessage(messages[i])
      if (!parsed) continue
      if (!anyRate) anyRate = parsed
      if (parsed.status === 'معامله') { dealRate = parsed; break }
    }
    const chosen = dealRate || anyRate
    const result: TelegramRate | null = chosen
      ? { rate: chosen.rate, status: chosen.status, fetchedAt: new Date(), source: 'telegram' }
      : null

    cache = { rate: result, at: Date.now() }
    return result
  } catch (err) {
    if (cache && Date.now() - cache.at < 5 * CACHE_TTL_MS) return cache.rate
    console.error('[telegram] fetch failed:', (err as Error).message)
    return null
  }
}

/**
 * Fetch the live rate and persist it to CurrencySetting (lastAutoRate).
 * If autoUpdateEnabled and no manual override exists for today, also upsert
 * today's CurrencyRate with source=TELEGRAM.
 */
export async function refreshTelegramRateInDB(): Promise<TelegramRate | null> {
  const rate = await fetchTelegramRate(true)
  if (!rate) return null

  const setting = await db.currencySetting.findUnique({ where: { id: 'singleton' } })
  await db.currencySetting.update({
    where: { id: 'singleton' },
    data: {
      lastAutoRate: rate.rate,
      lastAutoStatus: rate.status,
      lastAutoFetchAt: rate.fetchedAt,
    },
  })

  const today = todayTehran()
  const existing = await db.currencyRate.findUnique({ where: { date: today } })
  if (setting?.autoUpdateEnabled && !existing) {
    await db.currencyRate.create({
      data: { date: today, rate: rate.rate, marginPercent: setting.marginPercent, source: 'TELEGRAM', note: `نرخ خودکار تلگرام (${rate.status})` },
    })
  } else if (setting?.autoUpdateEnabled && existing && existing.source === 'TELEGRAM') {
    // Update today's auto rate to the freshest value
    await db.currencyRate.update({
      where: { date: today },
      data: { rate: rate.rate, note: `نرخ خودکار تلگرام (${rate.status})` },
    })
  }
  return rate
}
