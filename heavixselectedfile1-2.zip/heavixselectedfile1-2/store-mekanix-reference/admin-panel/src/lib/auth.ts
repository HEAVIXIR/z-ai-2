import { cookies } from 'next/headers'
import { createHmac } from 'crypto'
import { db } from './db'

/**
 * Signed httpOnly cookie session for the admin panel.
 *
 * Cookie: `ap_admin_session`
 * Signing: HMAC-SHA256(payload, SECRET). Payload is base64url(JSON).
 * Lifetime: 7 days. sameSite=lax, secure in production.
 */

const COOKIE_NAME = 'ap_admin_session'
const MAX_AGE_SECONDS = 60 * 60 * 24 * 7 // 7 days

const SECRET =
  process.env.ADMIN_PANEL_SECRET ||
  process.env.ADMIN_SECRET ||
  'auto-parts-admin-panel-dev-secret-change-me'

export type AdminRole = 'SUPER_ADMIN' | 'ADMIN' | 'OPERATOR'

export interface SessionPayload {
  id: string
  username: string
  name: string
  role: AdminRole
}

function b64url(input: Buffer | string): string {
  return Buffer.from(input).toString('base64url')
}

function fromB64url(s: string): string {
  return Buffer.from(s, 'base64url').toString('utf8')
}

function sign(payloadB64: string): string {
  return createHmac('sha256', SECRET).update(payloadB64).digest('base64url')
}

export async function createSession(payload: SessionPayload): Promise<void> {
  const payloadB64 = b64url(JSON.stringify(payload))
  const sig = sign(payloadB64)
  const token = `${payloadB64}.${sig}`
  const store = await cookies()
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: MAX_AGE_SECONDS,
    path: '/',
    secure: process.env.NODE_ENV === 'production',
  })
}

export async function clearSession(): Promise<void> {
  const store = await cookies()
  store.delete(COOKIE_NAME)
}

export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies()
  const token = store.get(COOKIE_NAME)?.value
  if (!token) return null
  const [payloadB64, sig] = token.split('.')
  if (!payloadB64 || !sig) return null
  const expectedSig = sign(payloadB64)
  if (sig !== expectedSig) return null
  try {
    const json = fromB64url(payloadB64)
    const parsed = JSON.parse(json) as SessionPayload
    if (!parsed.id || !parsed.username || !parsed.role) return null
    return parsed
  } catch {
    return null
  }
}

/**
 * Require an authenticated, active admin session.
 * Throws 'UNAUTHORIZED' if missing or invalid.
 */
export async function requireSession(): Promise<SessionPayload> {
  const session = await getSession()
  if (!session) throw new Error('UNAUTHORIZED')
  // Verify the admin still exists and is active in DB.
  const admin = await db.adminUser.findUnique({
    where: { id: session.id },
    select: { id: true, username: true, name: true, role: true, active: true },
  })
  if (!admin || !admin.active) throw new Error('UNAUTHORIZED')
  return {
    id: admin.id,
    username: admin.username,
    name: admin.name,
    role: admin.role as AdminRole,
  }
}

export function isSuperAdmin(session: SessionPayload | null): boolean {
  return session?.role === 'SUPER_ADMIN'
}

export { COOKIE_NAME }
