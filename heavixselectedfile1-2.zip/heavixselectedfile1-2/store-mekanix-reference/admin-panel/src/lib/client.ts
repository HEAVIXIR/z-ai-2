'use client'

/**
 * Client-side fetch helper for the admin panel.
 * Every request targets the admin API on port 3001 via the gateway's
 * `XTransformPort` query parameter.
 */

export const ADMIN_PORT = 3001

/** Append `XTransformPort=3001` to a path, preserving any existing query. */
export function withPort(path: string, port: number = ADMIN_PORT): string {
  if (!path) return `/?XTransformPort=${port}`
  if (path.startsWith('http://') || path.startsWith('https://')) return path
  const [pathname, search = ''] = path.split('?')
  const sep = search ? '&' : ''
  const prefix = pathname || '/'
  return `${prefix}?${search}${sep}XTransformPort=${port}`
}

export interface AdminFetchOptions extends RequestInit {
  /** Send the body as JSON (sets Content-Type automatically). */
  json?: unknown
}

/** Fetch wrapper that auto-appends XTransformPort=3001 and JSON-encodes bodies. */
export async function adminFetch(
  path: string,
  opts: AdminFetchOptions = {},
): Promise<Response> {
  const { json, headers, ...rest } = opts
  const finalHeaders = new Headers(headers)
  let body = rest.body
  if (json !== undefined) {
    body = JSON.stringify(json)
    if (!finalHeaders.has('Content-Type')) {
      finalHeaders.set('Content-Type', 'application/json')
    }
  }
  return fetch(withPort(path), {
    ...rest,
    headers: finalHeaders,
    body,
    credentials: 'same-origin',
  })
}

/** Convenience helper: adminFetch + parsed JSON + thrown error on !ok. */
export async function adminFetchJson<T = unknown>(
  path: string,
  opts: AdminFetchOptions = {},
): Promise<T> {
  const res = await adminFetch(path, opts)
  const text = await res.text()
  const data = text ? JSON.parse(text) : null
  if (!res.ok) {
    const message =
      (data && typeof data === 'object' && 'error' in data && String((data as any).error)) ||
      `HTTP ${res.status}`
    throw new Error(message)
  }
  return data as T
}
