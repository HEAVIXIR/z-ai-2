import { randomBytes, scryptSync, timingSafeEqual } from 'crypto'

const KEY_LEN = 64
const SCRYPT_N = 16384

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, KEY_LEN, { N: SCRYPT_N }).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  const test = scryptSync(password, salt, KEY_LEN, { N: SCRYPT_N })
  const expected = Buffer.from(hash, 'hex')
  if (test.length !== expected.length) return false
  return timingSafeEqual(test, expected)
}
