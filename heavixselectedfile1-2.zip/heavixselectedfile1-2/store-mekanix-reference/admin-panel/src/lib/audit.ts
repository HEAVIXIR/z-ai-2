import { db } from './db'

export interface AuditInput {
  admin: { id: string; name: string } | null | undefined
  action: string
  entity: string
  entityId?: string | null
  before?: unknown
  after?: unknown
  ipAddress?: string | null
}

/**
 * Best-effort audit log entry. Never throws — audits are non-blocking.
 */
export async function logAudit(input: AuditInput): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        adminId: input.admin?.id ?? null,
        adminName: input.admin?.name ?? '—',
        action: input.action,
        entity: input.entity,
        entityId: input.entityId ?? null,
        before: input.before ? JSON.stringify(input.before) : null,
        after: input.after ? JSON.stringify(input.after) : null,
        ipAddress: input.ipAddress ?? null,
      },
    })
  } catch (err) {
    console.error('[audit] failed to write log:', (err as Error).message)
  }
}
