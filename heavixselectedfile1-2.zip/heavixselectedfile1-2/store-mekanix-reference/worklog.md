# Worklog — Auto-Parts Marketplace + Admin Panel (v3, with real Telegram rates + payment gateway)

## Project Overview
Two independent applications sharing ONE Prisma/SQLite database
(`file:/home/z/my-project/db/custom.db`):

1. **Main app** — Next.js 16 on port 3000. Customer/mechanic auto-parts marketplace.
2. **Admin panel** — SEPARATE Next.js 16 app at `/home/z/my-project/admin-panel/` on port 3001. Full DB access.

Plus a **mini-service** (`mini-services/telegram-rate-fetcher`, port 3010) that
polls the Telegram channel @NerkhDollarIRT every 2 minutes and writes the live
USD→IRR rate to the shared DB.

The gateway (Caddyfile) routes `?XTransformPort=<port>` to each app.

## Key features (this rebuild)
- **REAL currency rate from Telegram**: `src/lib/telegram-rate.ts` fetches
  `https://t.me/s/NerkhDollarIRT`, parses `دلار تهران | ⛳️ | : 232,500 معامله` messages,
  extracts the live Toman rate. Mini-service polls every 2 min; admin can also
  force-refresh; main app reads effective rate from DB.
- **Payment gateway (Zarinpal)**: `src/lib/zarinpal.ts` implements full
  request/verify flow. When `ZARINPAL_MERCHANT_ID` env is unset → local mock
  gateway (fully demoable). Set the env to go live.
- **Extra features for parity with auto-parts sites**: car model selector
  (CarModel table), reviews & ratings, wishlist, coupons, wallet, notifications,
  shipment tracking, featured parts, discount (oldPriceUsd), view/sold counts.

## Shared schema (prisma/schema.prisma)
AdminUser, Customer, Mechanic, CarModel, Category, Brand, Part, Order, OrderItem,
Payment (+gateway fields), Shipment, CurrencyRate, CurrencySetting, Setting,
Review, Wishlist, Coupon, WalletTransaction, Notification, AuditLog.

## Pricing logic
- Parts priced in USD (`priceUsd`).
- Effective rate = today's manual rate → else auto (Telegram) → else defaultRate.
- Rial price = `priceUsd × effectiveRate × (1 + marginPercent/100)`.
- `marginPercent` (default 3%) is the shop markup.

## Admin credentials (seeded)
- `admin` / `admin12345` (SUPER_ADMIN)
- `operator` / `operator123` (OPERATOR)

## CONVENTIONS (admin panel)
- Server Components read DB via `db`. Client mutations via `adminFetch('/api/admin/<resource>')` (auto-appends XTransformPort=3001).
- Every API route: `try { await requireSession() } catch { 401 }`.
- Every mutation: `logAudit(...)`.
- Pages: `src/app/(app)/<section>/page.tsx`. APIs: `src/app/api/admin/<section>/...`.

## Telegram rate fetcher
- Mini-service: `mini-services/telegram-rate-fetcher` (port 3010). Run: `bun run dev` in that dir.
- Lib: `src/lib/telegram-rate.ts` → `fetchTelegramRate(force?)`, `refreshTelegramRateInDB()`.
- Also exposed via admin API: POST `/api/admin/currency/refresh` (calls refreshTelegramRateInDB).

---
Task ID: 1
Agent: orchestrator
Task: Rebuild foundation after 3rd sandbox reset — comprehensive schema, real Telegram rate fetcher, Zarinpal gateway, expanded features.

Work Log:
- Wrote comprehensive prisma/schema.prisma (added CarModel, Review, Wishlist, Coupon, WalletTransaction, Notification, Shipment; extended Part with featured/views/soldCount/oldPriceUsd; extended Customer with walletBalanceIrr; extended Payment with gateway/authority/refId).
- db:generate + db:push successful.
- Wrote src/lib/currency.ts (getEffectiveRate with MANUAL > TELEGRAM > DEFAULT priority).
- Wrote src/lib/password.ts (scrypt).
- Wrote src/lib/telegram-rate.ts — REAL fetcher for t.me/s/NerkhDollarIRT. Parses `دلار تهران | : <num> <status>` messages. 1-min in-memory cache. refreshTelegramRateInDB() persists to DB.
- Wrote src/lib/zarinpal.ts — full Zarinpal request/verify. Mock mode when no ZARINPAL_MERCHANT_ID.
- Wrote prisma/seed.ts — fetches live Telegram rate at seed time, seeds 12 parts (with car models, featured, discounts), 7 categories, 5 brands, 5 car models, 2 coupons, customers/mechanics, 1 pending payment, shop settings.
- Ran seed: Telegram rate 232,500 تومان (معامله) successfully fetched and stored.
- Created mini-services/telegram-rate-fetcher (port 3010) — polls Telegram every 2 min, writes to DB. GET /status, POST /refresh.

Stage Summary:
- Foundation complete. Real Telegram rate (232,500) live in DB. Ready to rebuild main app + admin panel with all features.
- Next: dispatch subagents for main app (car selector, reviews, wishlist, payment gateway, order tracking) and admin panel (all sections + Telegram auto + gateway transactions).

---
Task ID: 5
Agent: full-stack-developer
Task: Rebuild admin panel scaffold (port 3001) + auth + layout + dashboard + currency (real Telegram) + parts

Work Log:
- Created `/home/z/my-project/admin-panel/` as a SEPARATE Next.js 16 app (port 3001). Shares parent `node_modules` via Node upward resolution; no separate install. Wrote `package.json` (name auto-parts-admin-panel, scripts dev=`next dev -p 3001`, lint=`eslint .`), `next.config.ts` (output standalone, ignoreBuildErrors, reactStrictMode false), `tsconfig.json` (paths `@/*`→`./src/*`, ES2017, jsx react-jsx, strict, moduleResolution bundler), `postcss.config.mjs`, `.env` (DATABASE_URL=file:/home/z/my-project/db/custom.db + ADMIN_PANEL_SECRET), `.gitignore`, copied `eslint.config.mjs` from parent.
- Copied shared assets from parent: all 48 `src/components/ui/*` shadcn primitives, `src/lib/utils.ts`, `src/app/globals.css` (then edited: replaced `var(--font-geist-sans)` with `var(--font-vazirmatn)` + system fallbacks, added `.thin-scrollbar` style for long admin lists), `src/lib/telegram-rate.ts`, `src/lib/zarinpal.ts`, `src/lib/password.ts`, `src/lib/currency.ts`, `src/lib/db.ts` (changed log to `['error','warn']`), `public/logo.svg`, `public/robots.txt`, `src/hooks/use-mobile.ts` + `use-toast.ts`.
- Created shared libs in `admin-panel/src/lib/`:
  - `auth.ts` — signed httpOnly cookie session. HMAC-SHA256 signing with `ADMIN_PANEL_SECRET` env (default `auto-parts-admin-panel-dev-secret-change-me`). Cookie `ap_admin_session`, 7-day maxAge, sameSite=lax, httpOnly, secure in prod. `SessionPayload {id, username, name, role: 'SUPER_ADMIN'|'ADMIN'|'OPERATOR'}`. Exports `createSession`, `clearSession`, `getSession`, `requireSession()` (throws 'UNAUTHORIZED', also verifies admin exists+active in DB), `isSuperAdmin`.
  - `audit.ts` — `logAudit({admin, action, entity, entityId?, before?, after?, ipAddress?})` best-effort (never throws).
  - `client.ts` — `'use client'` `adminFetch(path, init)` auto-appends `XTransformPort=3001` to every request. Also exports `withPort`, `adminFetchJson` convenience helper.
  - `password.ts`, `db.ts`, `currency.ts`, `telegram-rate.ts`, `zarinpal.ts`, `utils.ts` — copied from parent.
- Auth API routes (all under `src/app/api/admin/`):
  - `login/route.ts` (POST): verifies password with scrypt, checks admin exists+active, updates lastLoginAt, calls `createSession`, logs LOGIN audit. Returns 401 with Persian error on bad creds.
  - `logout/route.ts` (POST): logs LOGOUT audit + `clearSession`.
  - `me/route.ts` (GET): returns session or 401.
- Root layout + login:
  - `src/app/layout.tsx`: `<html lang="fa" dir="rtl" suppressHydrationWarning>`, Vazirmatn (subsets arabic+latin) font variable, `<Toaster richColors position="top-center" />` (sonner), `ThemeProvider` from next-themes, metadata title "پنل مدیریت — بازار قطعات خودرو", robots noindex.
  - `src/app/page.tsx`: server-side redirect — `redirect(session ? '/dashboard' : '/login')`.
  - `src/app/login/page.tsx` (client): login form, username prefilled "admin", password, hint "admin/admin12345", POST /api/admin/login → redirect /dashboard.
- App shell (`src/app/(app)/layout.tsx` server + protected): `getSession()`, redirect /login if none. Renders Sidebar + Topbar + children + sticky Footer (mt-auto).
- Components:
  - `components/admin/sidebar.tsx`: 13 nav items — داشبورد، نرخ ارز، قطعات، دسته‌ها و برندها، سفارش‌ها، تایید پرداخت‌ها، مشتریان، مکانیک‌ها، کدهای تخفیف، نظرات، مدیران (superOnly)، تنظیمات، لاگ رویدادها. Desktop md+ sidebar + MobileNav horizontal scroll + mobile drawer.
  - `components/admin/topbar.tsx`: session name + role Badge + Avatar + logout button. Banner: "هر تغییری که در این پنل اعمال می‌کنید، بلافاصله در اپلیکیشن اصلی اعمال می‌شود."
  - `components/admin/stat-card.tsx`: `StatCard({title, value, sub, icon, accent})` with 6 accent colors (emerald, amber, rose, violet, cyan, slate).
  - `components/admin/footer.tsx`: sticky footer.
  - `components/admin/placeholder.tsx`: shared "در حال توسعه" placeholder for pages other agents will build.
  - `components/theme-provider.tsx`: next-themes wrapper.
- Dashboard (`api/admin/dashboard` + `(app)/dashboard/page.tsx`): currency banner showing LIVE telegram rate prominently ("نرخ لحظه‌ای تلگرام: X تومان" + status + last fetch + "بروزرسانی از تلگرام" button that POSTs /api/admin/currency/refresh), 8 stat cards (revenue, pending payments, pending orders, parts, low stock, customers, mechanics, pending reviews), 7-day sales BarChart (recharts), payments PieChart, pending-payments list (max-h-96 overflow-y-auto thin-scrollbar), low-stock list, recent pending reviews list. Uses `adminFetch`. Skeletons during load, refresh button.
- Currency management — REAL TELEGRAM:
  - `api/admin/currency` (GET): setting + today's rate + effective + last 30 history (with setBy) + live `telegram` field (cached 1 min via `fetchTelegramRate()`).
  - `api/admin/currency/rate` (POST upsert today's MANUAL rate {rate, marginPercent?, note?}; DELETE today's rate → falls back to telegram/default).
  - `api/admin/currency/setting` (PUT {defaultRate?, marginPercent?, autoUpdateEnabled?, autoSource?}).
  - `api/admin/currency/refresh` (POST): calls `refreshTelegramRateInDB()` and returns the live rate. This is the manual "fetch from Telegram now" button.
  - `(app)/currency/page.tsx` (client): Live Telegram rate banner (big), Today's effective rate card with source badge (دستی/تلگرام/پیش‌فرض) + margin + live preview "۱ دلار = X تومان (با حاشیه Y٪)", Set today's manual rate form (rate, margin, note) + delete-today AlertDialog, Default & auto settings card (defaultRate, marginPercent, autoUpdateEnabled Switch, autoSource Select) — saved via PUT, History table (30 days, scrollable) with date/rate/margin/source badge/setBy/note.
- Parts management:
  - `api/admin/parts` (GET list with filters q/categoryId/brandId/active, computed priceIrr using getEffectiveRate; POST create with carModels connect, featured, oldPriceUsd).
  - `api/admin/parts/[id]` (GET, PUT partial incl. carModels sync, DELETE — refuses with 400 if has OrderItems).
  - `(app)/parts/page.tsx` (client): toolbar (search, category, brand, active filter, add button); table (name+thumbnail, sku, category, brand, $USD + old strike, IRR + old strike, stock badge, featured star, active badge, views, soldCount, edit/delete); add/edit Dialog with live IRR preview, images (comma-separated URLs), oldPriceUsd (for discounts), featured Switch, carModels multi-select (checkboxes grouped by brand), compatibleCars textarea; delete AlertDialog (surfaces 400 refusals). Responsive overflow-x-auto + thin-scrollbar.
- Read-only list APIs (other agents add CRUD later):
  - `api/admin/categories` (GET): nested tree with partsCount + childrenCount, also flat list, countByCat map.
  - `api/admin/brands` (GET): list with partsCount.
  - `api/admin/car-models` (GET): flat list + grouped by brand (for the parts form car selector).
- Placeholder pages created for sections other agents will build: categories, orders, payments, customers, mechanics, coupons, reviews, admins, settings, audit — all render "این بخش در حال توسعه است" via `PlaceholderPage` component.
- Conventions enforced: every API route wraps `try { await requireSession() } catch { return NextResponse.json({error:'unauthorized'},{status:401}) }`. Every mutation calls `logAudit({...})`. Dynamic routes use `ctx: { params: Promise<{ id: string }> }` and `const { id } = await ctx.params`. RTL Persian UI, shadcn, Vazirmatn, NO indigo/blue (used emerald/amber/violet/cyan/rose/slate accents).

Stage Summary:
- Admin panel scaffold rebuilt on port 3001, fully functional. Started with: `cd /home/z/my-project/admin-panel && (setsid bash -c 'cd /home/z/my-project/admin-panel && exec bun run dev' </dev/null >dev.log 2>&1 &) && sleep 7` — dev server running on port 3001.
- Verified all required endpoints via curl:
  - `POST /api/admin/login` with admin/admin12345 → 200 `{ok:true, admin:{...SUPER_ADMIN}}`.
  - Operator login also works.
  - `GET /api/admin/dashboard` → 200 with full payload (currency todayRate=232300 source=TELEGRAM, telegram={rate:232300,status:'معامله'}, 8 counts, revenue, 7-day sales, payments/orders by status, 6 recent pending payments, low stock list, pending reviews).
  - `GET /api/admin/currency` → 200 (effective, setting, todayRate, live telegram, 30-day history).
  - `POST /api/admin/currency/refresh` → 200 `{ok:true, rate:{rate:232300, status:'معامله', fetchedAt:...}}` — Telegram refresh writes to DB successfully.
  - `GET /api/admin/parts` → 200 (effectiveRate + parts with computed priceIrr).
  - Tested full parts CRUD (POST create → PUT update stock/featured → DELETE → 200).
  - Tested currency rate POST (set 240000 MANUAL → effective source switched to MANUAL) and DELETE (reverted to TELEGRAM).
  - Tested setting PUT (margin 5 → 3 reverted) — both 200.
  - `POST /api/admin/logout` → 200 + Set-Cookie Expires=1970; subsequent dashboard → 401.
  - All 14 page routes return 200: /login, /dashboard, /currency, /parts, /categories, /orders, /payments, /customers, /mechanics, /coupons, /reviews, /admins, /settings, /audit.
- ESLint clean (0 errors, 0 warnings after removing unused eslint-disable directive). `bun run lint` → clean.
- Files created: 4 config files (package.json, next.config.ts, tsconfig.json, postcss.config.mjs, .env, .gitignore, eslint.config.mjs), 9 src/lib/* files (auth, audit, client, password, db, currency, telegram-rate, zarinpal, utils), 7 src/components/admin/* (sidebar, topbar, footer, stat-card, placeholder, theme-provider), 11 API routes (login, logout, me, dashboard, currency + currency/rate + currency/setting + currency/refresh, parts + parts/[id], categories, brands, car-models), 4 pages (layout, root page redirect, login, (app)/layout), 3 dashboard/currency/parts pages, 10 placeholder pages.
- Real Telegram rate is live in admin: `232,300 تومان (معامله)` as of verification time, fetched on demand via /refresh endpoint.
- Did NOT touch /home/z/my-project/src, schema, prisma, mini-services. Left room (no [id] routes for categories/brands/car-models, no orders/payments/etc pages) for other agents to extend.

---
Task ID: 7
Agent: full-stack-developer
Task: Build admin Categories/Brands + Coupons + Reviews moderation + Settings + Audit + Admin users pages

Work Log:
- Read existing GET routes for categories, brands, car-models and shared libs (auth, audit, client, password, currency) before any changes. Confirmed parent admin dev server was not running and started it (`bun run dev` on port 3001).
- API — Categories (kept GET, added POST + [id] PUT/DELETE):
  - `src/app/api/admin/categories/route.ts` — added `slugify` helper (`s.trim().toLowerCase().replace(/[^\w\u0600-\u06FF]+/g,'-').replace(/^-+|-+$/g,'') || \`cat-${Date.now()}\``), POST `{name, parentId?, icon?}` validates name, validates parent (404 + 3-level guard), unique-slug loop, logAudit CREATE Category, returns 201. GET left untouched.
  - `src/app/api/admin/categories/[id]/route.ts` — PUT `{name?, parentId?, icon?}` re-slugifies on rename with duplicate guard, prevents self-parenting (parentId===id → 400), prevents cycles, enforces 2-level depth. DELETE refuses with 400 when `_count.parts>0` or `_count.children>0`. All mutations logAudit UPDATE/DELETE Category.
- API — Brands (kept GET, added POST + [id] PUT/DELETE):
  - `src/app/api/admin/brands/route.ts` — added `brandSlugify`, POST `{name, country?, logoUrl?}` with unique-slug loop, logAudit CREATE Brand, 201. GET untouched.
  - `src/app/api/admin/brands/[id]/route.ts` — PUT `{name?, country?, logoUrl?}`, DELETE refuses with 400 if `_count.parts>0`. Audit.
- API — Car models (kept GET, added POST + [id] PUT/DELETE):
  - `src/app/api/admin/car-models/route.ts` — GET untouched. Added POST `{brand, model, yearFrom, yearTo}` validates ranges and yearTo >= yearFrom, audit, 201.
  - `src/app/api/admin/car-models/[id]/route.ts` — PUT partial, DELETE refuses with 400 if `_count.parts>0`. Audit.
- API — Coupons:
  - `src/app/api/admin/coupons/route.ts` — GET list all; POST `{code (uppercased), type (PERCENT|FIXED), value, expiresAt?, usageLimit?, minOrderIrr?, active?}` validates value>0, percent≤100, unique code, logAudit CREATE Coupon, 201.
  - `src/app/api/admin/coupons/[id]/route.ts` — PUT partial (re-uses effective type to enforce percent≤100), DELETE refuses with 400 if `usedCount>0` (recommends deactivation). Audit.
- API — Reviews moderation:
  - `src/app/api/admin/reviews/route.ts` — GET with query `status` (pending|approved|rejected|all, default pending), `partId`, `q` (matches title/comment/part name/customer name/phone), pagination `page`/`pageSize`. Includes part (name, sku) + customer (fullName, phone).
  - `src/app/api/admin/reviews/[id]/route.ts` — GET one with relations; PATCH `{action:'approve'|'reject'}` sets approved=true/false and reviewedById=session.id. logAudit APPROVE/REJECT Review.
- API — Settings:
  - `src/app/api/admin/settings/route.ts` — GET returns `settings` map (id→value) + `stats` (parts, customers, mechanics, orders, payments, auditLogs, adminUsers, coupons, reviews counts) in a single round-trip. PUT body is a key→string map; upserts each changed key, computes diff against existing, logAudit UPDATE Setting with `{changes:[{key,before,after}]}`. Returns `{ok:true, changes}` (empty array if no diff).
- API — Audit:
  - `src/app/api/admin/audit/route.ts` — GET with `action`, `entity`, `q` (adminName contains), `page`/`pageSize` (default 50, max 100). Returns `{logs, total, page, pageSize}`. Includes `admin: {select: {username}}`, ordered by createdAt desc. Each log row carries adminName + adminUsername + entity + entityId + truncated before/after JSON.
- API — Admins (RBAC, super-admin only):
  - `src/app/api/admin/admins/route.ts` — GET requires super-admin (403 if not), returns admins with `_count.auditLogs` and `currentId`. POST `{username, password, name, role?}` requires super-admin, validates username uniqueness + password≥6, role defaults OPERATOR, hashPassword via scrypt, audit, 201.
  - `src/app/api/admin/admins/[id]/route.ts` — PUT requires super. Self-demotion (id==session.id and role!=SUPER_ADMIN → 400). Self-deactivation (id==session.id and active===false → 400). Optional password change. DELETE prevents self-delete (id==session.id → 400); clears `auditLogs.adminId` to null before delete so historical logs are preserved with adminName only. Audit.
- UI — `src/app/(app)/categories/page.tsx` (client, replaced placeholder): Tabs (دسته‌ها / برندها / خودروها).
  - دسته‌ها tab: "دسته جدید" button, nested tree (parent row + indented children with depth-aware padding), each node shows name, slug (mono ltr), icon badge, partsCount badge, childrenCount badge, edit/delete buttons. Add/Edit Dialog (name, parent select — disabled self/children to prevent cycles, icon). Delete AlertDialog surfaces 400 refuse messages (parts/children).
  - برندها tab: "برند جدید", table (initials avatar, name+slug, country, partsCount, edit/delete). Add/Edit Dialog (name, country, logoUrl). Delete AlertDialog.
  - خودروها tab: "مدل خودرو جدید", table (brand, model, yearFrom–yearTo ltr, partsCount, edit/delete). Add/Edit Dialog with year grid. Delete AlertDialog.
- UI — `src/app/(app)/coupons/page.tsx` (client, replaced placeholder): "کد تخفیف جدید" button; table (code mono ltr, type badge — violet "درصد" for PERCENT / cyan "مبلغ ثابت" for FIXED, value with % or تومان suffix, minOrderIrr formatted, usedCount/usageLimit (with ∞ when 0), expiresAt fa-IR with "(منقضی)" suffix if expired, active Switch (disabled if expired), edit/delete). Add/Edit Dialog with code (uppercased ltr), type Select, value, min/limit grid, expiresAt date, active Switch. Delete AlertDialog refuses used coupons with helpful message.
- UI — `src/app/(app)/reviews/page.tsx` (client, replaced placeholder): Tabs (در انتظار تایید / تایید شده / همه). Each review renders as a Card with: 5-star rating (amber filled), title, comment (whitespace-pre-wrap), approved badge (emerald) or pending badge (amber), part name, customer fullName+phone (mono ltr), createdAt (fa-IR date+time). Actions: "تایید" (emerald outline button, disabled if already approved) + "رد" (rose outline button) → PATCH. Removes item from list when on pending tab. Empty state per tab. Search input.
- UI — `src/app/(app)/settings/page.tsx` (client, replaced placeholder): Two-column layout. Main column = 3 cards (اطلاعات فروشگاه with shopName/shopPhone/shopAddress Textarea; هزینه ارسال و حداقل سفارش with shippingFlatFeeUsd/minOrderUsd number inputs and helper text; شبکه‌های اجتماعی with socialInstagram/socialTelegram/socialWhatsapp inputs). Save button at top — only diffs changed keys. Sidebar = "نرخ ارز" shortcut card linking to /currency + "نمای دیتابیس" card with 9 stat tiles (parts, customers, mechanics, orders, payments, coupons, reviews, admins, auditLogs) each with accent-colored icon. Skeletons during load.
- UI — `src/app/(app)/audit/page.tsx` (client, replaced placeholder): Filters row (q input for admin name, action Select, entity Select — both with "همه" + Persian label + English code). Table in scrollable container (`max-h-[70vh] overflow-y-auto thin-scrollbar`) with sticky header. Columns: زمان (fa-IR datetime), مدیر (name + @username mono ltr), عملیات Badge (variant by action — CREATE/UPDATE/DELETE/LOGIN/LOGOUT/APPROVE/REJECT with Persian labels and emerald/amber/rose/violet/slate colors), موجودیت (Persian label + English code), شناسه (last 8 chars of entityId in mono ltr), تغییرات (truncated JSON of `after` or `before`, scrollable pre with thin-scrollbar). Pagination controls with fa-IR page numbers.
- UI — `src/app/(app)/admins/page.tsx` (client, replaced placeholder): "مدیر جدید" button. Table: avatar with initial, name + "شما" badge if id==currentId, username (mono ltr), role Badge (SUPER_ADMIN shows ShieldCheck icon + violet), active Switch (disabled if self), last login (fa-IR, hidden on small screens), auditLogsCount, edit/delete (delete disabled if self). Add/Edit Dialog: name, username (disabled if editing), role Select (disabled if self), active Switch (disabled if self), password (optional if edit, with min-length validation hint). Delete AlertDialog.
- Conventions enforced: every API route `try { await requireSession() } catch { return NextResponse.json({error:'unauthorized'},{status:401}) }`. Every mutation calls `logAudit`. Dynamic routes use `ctx: { params: Promise<{ id: string }> }` + `const { id } = await ctx.params`. RTL Persian UI, shadcn, no indigo/blue (used emerald/amber/violet/cyan/rose/slate accents). All long tables wrapped in `max-h-[70vh] overflow-y-auto thin-scrollbar`.

Stage Summary:
- All 6 placeholder pages replaced with full implementations; all 13 API files created/extended.
- Verified via curl: all 6 pages return 200 (categories, coupons, reviews, settings, audit, admins); all 8 GET APIs return 200 (categories, brands, car-models, coupons, reviews, settings, audit, admins); POST endpoints return 201 (categories, brands, car-models, coupons, admins).
- Tested full CRUD cycles: category create→PUT rename→DELETE; brand create→PUT→DELETE; coupon create→PUT→DELETE; admin create→PUT (promote OPERATOR→ADMIN)→DELETE; settings PUT (changes diff returned). Refuse-with-400 paths verified: DELETE category with parts → 400 Persian message; self-demotion → 400; self-deactivation → 400; self-delete → 400; operator accessing /api/admin/admins → 403.
- Reviews moderation flow verified: seeded a test review via bun script (no @prisma/client in path — used shared `@/lib/db`), GET /api/admin/reviews (pending tab) shows it; PATCH action=approve moves it to approved tab; PATCH action=reject moves it back to pending. Test review cleaned up afterwards.
- Audit log filters verified: `?action=CREATE&entity=Coupon` returns matching entries with adminUsername populated from relation.
- `bun run lint` → 0 errors, 0 warnings. Dev log shows zero compile errors across all new routes/pages.
- Did NOT touch /home/z/my-project/src, prisma schema, mini-services, or any of the parallel agent's files (orders/payments/customers/mechanics GET routes, dashboard, currency, parts, login, layout, sidebar, topbar).
- Note: GET routes for categories/brands/car-models were preserved exactly as the other agent wrote them; only POST handlers + dynamic PUT/DELETE were added.
- Files modified: 2 (categories/route.ts, brands/route.ts, car-models/route.ts). Files created: 13 (categories/[id], brands/[id], car-models/[id], coupons + coupons/[id], reviews + reviews/[id], settings, audit, admins + admins/[id], plus 6 page replacements).

---
Task ID: 6
Agent: full-stack-developer
Task: Build admin Orders + Payments (gateway) + Customers (wallet) + Mechanics pages

Work Log:
- Replaced 4 placeholder pages (`(app)/{orders,payments,customers,mechanics}/page.tsx`) with full client implementations and added 8 new API routes. Followed existing conventions: `try { await requireSession() } catch { return 401 }` on every route, `logAudit` on every mutation, dynamic routes via `ctx: { params: Promise<{ id: string }> }` with `await ctx.params`, RTL Persian UI, shadcn/ui, neutral + amber/emerald/rose/violet/cyan accents (no indigo/blue).

- ORDERS — `src/app/api/admin/orders/route.ts` (GET, paginated, filters: `status`, `paymentStatus`, `q` over orderNumber + customer phone/name/family; includes customer, mechanic, items.part, payments {id,status,amountIrr,method,gateway,refId}, shipment). `src/app/api/admin/orders/[id]/route.ts` (GET full detail with items+payments+reviewedBy; PATCH `{status, mechanicId, notes}` with status whitelist + mechanic existence check + audit). `src/app/api/admin/orders/[id]/shipment/route.ts` (POST create, PUT update): carrier whitelist (پست/تیپاکس/چاپار), status whitelist (PENDING/DISPATCHED/IN_TRANSIT/DELIVERED); on DISPATCHED/IN_TRANSIT sets shippedAt and advances order PENDING→PROCESSING; on DELIVERED sets deliveredAt and forces order.status=DELIVERED; reverting to PENDING clears timestamps; full before/after audit. Page: toolbar (search + status + payment-status Selects), table (order number, customer name+phone, amount formatIrr + $USD small, item count, mechanic, status+payment badges, shipment status+carrier, date, view action), row click opens Dialog with items table (qty/unitUSD/unitIRR/lineTotal), totals (subtotal, shipping, discount, total + currency rate + margin), payments list, customer info + shipping address + coupon, inline editor (status Select, mechanic Select, notes Textarea, save→PATCH), and shipment section (carrier Select, trackingCode input ltr, status Select, note, save→POST or PUT depending on existing). Pagination controls. Responsive overflow-x-auto + thin-scrollbar.

- PAYMENTS (most critical) — `src/app/api/admin/payments/route.ts` (GET, filters: `status` default PENDING, `method`, `q` over referenceCode/phone/payerName/payerCard/authority/refId/orderNumber; ordered by createdAt desc; includes order {orderNumber,totalIrr,totalUsd,status}, customer {name,family,phone}, reviewedBy {name}). `src/app/api/admin/payments/[id]/route.ts` (GET full detail with order items+items.part + customer; PATCH `{action:'approve'|'reject', note?}`):
    * Guard: `if payment.reviewedAt` → 400 "این پرداخت قبلاً بررسی شده".
    * approve (in `$transaction`): payment.status=APPROVED, reviewedById=session.id, reviewedAt=now, note. order.paymentStatus=PAID, if order.status==PENDING advance to CONFIRMED. customer.totalSpentIrr += payment.amountIrr, customer.totalOrders += 1. Audit `APPROVE_PAYMENT`.
    * reject: payment.status=REJECTED, reviewedById, reviewedAt, note. If order.paymentStatus==PENDING → set to UNPAID. Audit `REJECT_PAYMENT`.
    * Returns `{ok, payment, orderStatus?, orderPaymentStatus?}` so UI can surface the side-effect.
  Page: Tabs (در انتظار/تایید شده/رد شده/همه), toolbar (search + method Select), table (order, customer, amount formatIrr + $USD, method badge with MIcon per method, referenceCode ltr, payerName + masked payerCard, receipt link, date, view action). Row click → Dialog showing full payment + order items + totals + customer info. For GATEWAY payments shows read-only box with gateway/authority/refId/gatewayUrl + note that they're auto-approved by gateway. For PENDING manual payments: amber-bordered action panel with note Textarea + two buttons "تایید پرداخت" (emerald, calls approve) and "رد پرداخت" (rose destructive, calls reject), spinner during action, toast on success + closes dialog + refreshes list. Empty state "پرداخت در انتظاری وجود ندارد 🎉" with PartyPopper icon.

- CUSTOMERS (wallet) — `src/app/api/admin/customers/route.ts` (GET, filters: `q` over phone/name/family/nationalCode, `status`; paginated; returns _count of orders/payments/wishlists/reviews + totalSpentIrr + walletBalanceIrr). `src/app/api/admin/customers/[id]/route.ts` (GET with orders {orderNumber,status,paymentStatus,totalIrr,totalUsd,createdAt}, payments {id,status,method,amountIrr,referenceCode,gateway,refId,reviewedAt}, walletTxns, _count wishlists/reviews; PATCH `{name,family,address,nationalCode,notes,status}` with ACTIVE|BLOCKED whitelist + audit `UPDATE_CUSTOMER`). `src/app/api/admin/customers/[id]/wallet/route.ts` (POST `{amount, type:'CREDIT'|'DEBIT', description?}`): validates amount>0 + type whitelist; in `$transaction` creates WalletTransaction (signed: +amount for CREDIT, -amount for DEBIT) and increments customer.walletBalanceIrr by signedAmount; returns updated balance + new transaction; audit `WALLET_ADJUST`. Page: toolbar (search + status), table (name, phone ltr, nationalCode ltr, status badge, order count, total spent formatIrr, wallet balance formatIrr in violet, join date, view action). Row click → Dialog: stats grid (4 cards), editable profile (name, family, nationalCode, address Textarea, notes Textarea, status Switch active/blocked), wallet adjustment form (amount + type CREDIT/DEBIT Select + description + submit→POST /wallet updates local balance + prepends new txn), then 3 scrollable tables (max-h-72 overflow-y-auto thin-scrollbar): orders list, payments list, wallet transactions list (with CREDIT green / DEBIT red badges + signed amounts).

- MECHANICS — `src/app/api/admin/mechanics/route.ts` (GET, filters: `q` over phone/name/family/shopName/specialty/city, `status`, `verified`; paginated; returns _count of orders. POST `{phone,name,family,shopName?,specialty?,city?,address?,notes?}`: validates required fields + unique phone, creates with status=ACTIVE, verified=false, rating=0; audit `CREATE_MECHANIC`). `src/app/api/admin/mechanics/[id]/route.ts` (GET with assigned orders + customer of each; PUT full update incl. verified/status with phone uniqueness check + audit `UPDATE_MECHANIC`; PATCH `{verified?, status?}` for quick toggles, with action-aware audit labels VERIFY_MECHANIC / UNVERIFY_MECHANIC / SUSPEND_MECHANIC / ACTIVATE_MECHANIC). Page: toolbar (search + status Select + verified Select + "افزودن مکانیک" emerald button), table (name, phone ltr, shopName, specialty, city, rating with star, verified toggle button — green ShieldCheck / slate ShieldAlert — that calls PATCH, status badge, order count, view + edit ghost buttons). Add/Edit Dialog: full form (name*, family*, phone*, shopName, specialty, city, address Textarea, notes Textarea; in edit mode also status Select + verified checkbox). Detail Dialog: stats grid (rating, orders, city, shop), profile card, scrollable assigned-orders table (max-h-80), footer with "ویرایش" + verify-toggle button. Pagination controls.

- Conventions enforced across all 8 routes: every GET/POST/PATCH/PUT wraps `try { await requireSession() } catch { return NextResponse.json({error:'unauthorized'},{status:401}) }`. Every mutation calls `logAudit({admin:session, action, entity, entityId, before?, after?, ipAddress})` with the real before/after payloads. All dynamic routes use `ctx: { params: Promise<{ id: string }> }` and `const { id } = await ctx.params`. Status labels and badge colors are inline per page (Persian) following the worklog's mapping. Cards aligned with `p-4` / `p-6`, tables wrapped in `overflow-x-auto thin-scrollbar` for responsive, long lists use `max-h-72/80 overflow-y-auto thin-scrollbar`. Mobile-first grid (`grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`). Touch targets ≥ 36px.

- ESLint: clean (0 errors, 0 warnings). `cd /home/z/my-project/admin-panel && bun run lint` → "$ eslint ." with no output. Hot-reload dev server (port 3001) recompiled every new file without errors — verified in `dev.log` (all 200/400/401/404 responses, no compile errors).

- End-to-end curl tests (admin/admin12345 cookie auth):
    * `GET /api/admin/orders` → 200 (1 seeded order, full payload).
    * `GET /api/admin/payments` → 200 (1 seeded PENDING payment).
    * `GET /api/admin/customers` → 200 (2 seeded customers).
    * `GET /api/admin/mechanics` → 200 (2 seeded mechanics).
    * `GET /orders`, `/payments`, `/customers`, `/mechanics` → all 200 (compiled cleanly).
    * PAYMENT APPROVAL: PATCH `/api/admin/payments/cmu9u450a001mnm4hqubl7zhy` `{action:'approve',note:'رسید تایید شد - تست'}` → 200 `{ok:true, payment.status:APPROVED, orderStatus:CONFIRMED, orderPaymentStatus:PAID}`. Verified Order.status=PENDING→CONFIRMED, Order.paymentStatus=PENDING→PAID, Customer.totalSpentIrr=0→9,147,945, Customer.totalOrders=0→1, Payment.reviewedById+reviewedAt+note set.
    * RE-APPROVE GUARD: PATCH same payment again → 400 `{error:"این پرداخت قبلاً بررسی شده"}`.
    * WALLET CREDIT: POST `/api/admin/customers/.../wallet` `{amount:500000,type:CREDIT}` → 200, walletBalanceIrr=500000, WalletTransaction(amount:+500000, type:CREDIT) created.
    * WALLET DEBIT: POST `{amount:100000,type:DEBIT}` → 200, walletBalanceIrr=400000, WalletTransaction(amount:-100000, type:DEBIT) created.
    * SHIPMENT CREATE: POST `/api/admin/orders/.../shipment` `{carrier:'پست',trackingCode,status:DISPATCHED}` → 200, shipment.shippedAt set.
    * SHIPMENT DELIVERED: PUT same with `{status:'DELIVERED}` → 200, shipment.deliveredAt set + `orderStatusChangedTo:'DELIVERED'` + Order.status auto-advanced to DELIVERED.
    * ORDER PATCH: assign mechanic + change status + notes → 200 with full before/after audit.
    * CUSTOMER PATCH: rename + notes → 200.
    * MECHANIC CREATE: POST with unique phone → 200, audit CREATE_MECHANIC. Duplicate phone → 400.
    * MECHANIC PATCH toggle verified → 200, audit VERIFY_MECHANIC.
    * MECHANIC PATCH status→SUSPENDED → 200, audit SUSPEND_MECHANIC.
    * MECHANIC PUT full update → 200, audit UPDATE_MECHANIC.
    * CUSTOMER SEARCH: `q=مریم` → 1 result; `q=علی` → 1 result; total 2 customers.
    * AUDIT LOG: GET `/api/admin/audit?pageSize=20` shows entries for APPROVE_PAYMENT, WALLET_ADJUST (x2), CREATE_SHIPMENT, UPDATE_SHIPMENT, CREATE_MECHANIC (x2), VERIFY_MECHANIC, SUSPEND_MECHANIC, UPDATE_MECHANIC, UPDATE_ORDER (x2), UPDATE_CUSTOMER — every mutation audited.
    * UNAUTHENTICATED: GET `/api/admin/{orders,payments,customers,mechanics}` without cookie → all 401.

Stage Summary:
- All 4 placeholder pages replaced with full implementations; 8 new API routes created. Payment approval flow (the most critical workflow) verified end-to-end: PENDING→APPROVED → order.status CONFIRMED + paymentStatus PAID + customer.totalSpentIrr += amount. Wallet adjustments verified (CREDIT/DEBIT signed amounts). Shipment workflow verified (POST create → PUT update; auto side-effects on order status). Mechanic CRUD + verify toggle verified. All pages return 200, all APIs return correct data, all mutations audited. ESLint clean. Did NOT touch /home/z/my-project/src, prisma/schema.prisma, mini-services, root layout, sidebar, topbar, dashboard, currency, parts pages, or other agents' pages (categories/coupons/reviews/settings/audit/admins).
- Files created (8 API + 4 pages):
    * `admin-panel/src/app/api/admin/orders/route.ts`
    * `admin-panel/src/app/api/admin/orders/[id]/route.ts`
    * `admin-panel/src/app/api/admin/orders/[id]/shipment/route.ts`
    * `admin-panel/src/app/api/admin/payments/route.ts`
    * `admin-panel/src/app/api/admin/payments/[id]/route.ts`
    * `admin-panel/src/app/api/admin/customers/route.ts`
    * `admin-panel/src/app/api/admin/customers/[id]/route.ts`
    * `admin-panel/src/app/api/admin/customers/[id]/wallet/route.ts`
    * `admin-panel/src/app/api/admin/mechanics/route.ts`
    * `admin-panel/src/app/api/admin/mechanics/[id]/route.ts`
    * `admin-panel/src/app/(app)/orders/page.tsx` (replaced placeholder)
    * `admin-panel/src/app/(app)/payments/page.tsx` (replaced placeholder)
    * `admin-panel/src/app/(app)/customers/page.tsx` (replaced placeholder)
    * `admin-panel/src/app/(app)/mechanics/page.tsx` (replaced placeholder)
- No issues. Ready for the next agent (categories/coupons/reviews/settings/audit/admins pages).

---
Task ID: 8
Agent: orchestrator
Task: Final verification — Telegram rate + payment gateway + all services.

Work Log:
- All 3 services verified: main app (3000), admin panel (3001), telegram-rate-fetcher mini-service (3010).
- REAL Telegram rate fetched & stored: 232,200 تومان (status: معامله) from @NerkhDollarIRT. Mini-service polls every 2 min and writes to DB. Both apps read it live.
- Admin currency refresh (POST /api/admin/currency/refresh) re-fetches live rate → confirmed returns 232,200.
- Integration test: admin sets manual override 235,000/4% → main app /api/currency immediately shows 235,000 source=MANUAL; admin deletes override → main app reverts to 232,200 source=TELEGRAM. Sync confirmed.
- Payment gateway E2E: created order ORD-1004 (7,174,980 تومان, rate 232,200) → POST gateway/request → got MOCK authority + gatewayUrl → mock-gateway page → callback Status=OK → verify → payment AUTO-APPROVED, order AUTO CONFIRMED+PAID. Full flow works without admin intervention.
- Agent Browser main app (3000): 22 cards, car selector, Telegram rate badge, wishlist, footer, NO errors.
- Agent Browser admin (3001): login OK, dashboard shows live Telegram rate, revenue, pending payments, full 11-item sidebar, charts. NO "Failed to fetch", NO errors. Screenshot saved.
- All 13 admin pages return 200: dashboard, currency, parts, categories, orders, payments, customers, mechanics, coupons, reviews, admins, settings, audit.

Stage Summary:
- REBUILD COMPLETE with all requested features:
  1. REAL Telegram currency rate (not simulated) from @NerkhDollarIRT, auto-updating every 2 min via mini-service.
  2. Payment gateway (Zarinpal) with full request/verify flow + mock gateway for sandbox demo. Auto-approves on success.
  3. Feature parity with auto-parts sites: car selector, reviews, wishlist, coupons, wallet, shipment tracking, featured parts, discounts, view/sold counts.
  4. Admin panel: 13 sections all functional (dashboard, currency, parts, categories/brands/car-models, orders+shipments, payments+gateway, customers+wallet, mechanics, coupons, reviews moderation, admins RBAC, settings, audit log).
- Payment gateway: manual receipt (needs admin approval) + online gateway (auto-approved). Set ZARINPAL_MERCHANT_ID env for live Zarinpal.

---
Task ID: 9 (v4 fixes)
Agent: orchestrator
Task: Fix dollar rate display, remove source badge, add heavy machinery + full Iranian car list.

Work Log:
- Extended CarModel schema with `type` field (PASSENGER | HEAVY) + pushed.
- Wrote comprehensive seed with 66 car models (40 passenger Iranian-assembled + imports, 26 heavy trucks/machinery) and 89 parts (passenger + heavy machinery catalog).
- Iranian cars: Peugeot 206/207/Pars/405, Samand/Soren, Dena/DenaPlus, Rana, Tara, Shahin, Pride 131/132/141, Quick, Saina, Tiba, Chery E5, S200/S300, K132, Aris, Maxi, L90, Changan, MVM 110/315/530, Mazda3, Haima5/7, Toyota Corolla/Yaris, Hyundai Elantra/Tucson, Kia Sportage/Cerato, Benz C200, BMW 3.
- Heavy machinery: Volvo FH16/FMX, Scania R500/G440, MAN TGX, Actros, Hyundai HD, Maz 180, Eksan, Sameh, Faraz, Khavar 126, Zil 130, Cat 320/966/D6/14M, Komatsu PC200/WA380/GD655, Volvo L120, Liebherr L574, Hyundai HL740, tractor MTZ, Claas combine, John Deere.
- Heavy parts catalog: diesel oil/air/fuel filters, hydraulic filters, 15W-40 diesel oil, turbocharger, diesel injector, fuel pump, cylinder liner kit, piston rings, engine valves, 24V starter/alternator, 200Ah battery, heavy brake pads/drums/chambers, air compressor, leaf springs, heavy shock absorbers, wheel bearings, axle shafts, hydraulic pump/cylinder/hose/seal kit/control valve, heavy clutch, gearbox bearings, transmission oil, heavy radiator, intercooler, fan clutch.
- Fixed "ناعدد" bug: `toFa(currency.rate.toLocaleString('en-US'))` was passing "231,900" (string with comma) → `Number("231,900")` = NaN → "ناعدد". Fixed by (a) Header passes `currency.rate` (number) directly, (b) `toFa` now strips commas/space before parsing + returns "—" on non-finite.
- Removed source badge ("تلگرام"/"دستی"/"پیش‌فرض") and "زنده" word from main app header — source is now admin-only info. Rate bar shows just "نرخ روز دلار: ۲۳۱٬۹۰۰ تومان".
- Added vehicle type toggle (خودروی سواری / ماشین‌آلات سنگین) to CarSelector; page.tsx refetches car-models by type; car-models API supports ?type=PASSENGER|HEAVY filter.
- Verified end-to-end: switching to heavy → heading "قطعات ماشین‌آلات سنگین", selecting Volvo → 9 heavy parts shown. Telegram rate 231,900 تومان (معامله) live in DB.

Stage Summary:
- All 3 user requests resolved: (1) rate displays correctly as ۲۳۱٬۹۰۰ تومان not "ناعدد"; (2) no source/Telegram mention in main app; (3) heavy machinery section with full Iranian car + heavy machinery catalog.
- Catalog: 66 vehicles (40 passenger + 26 heavy), 89 parts, 22 categories, 25 brands. All 3 services alive.
