import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const type = searchParams.get('type') // PASSENGER | HEAVY
    const where = type ? { type } : {}
    const models = await db.carModel.findMany({
      where,
      orderBy: [{ brand: 'asc' }, { yearFrom: 'asc' }],
    })
    // group by brand
    const grouped: Record<string, any[]> = {}
    for (const m of models) {
      if (!grouped[m.brand]) grouped[m.brand] = []
      grouped[m.brand].push({
        id: m.id,
        brand: m.brand,
        model: m.model,
        yearFrom: m.yearFrom,
        yearTo: m.yearTo,
        type: m.type,
      })
    }
    const out = Object.entries(grouped).map(([brand, models]) => ({ brand, models }))
    return NextResponse.json({ carModels: models, grouped: out })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در دریافت مدل‌ها', detail: (e as Error).message }, { status: 500 })
  }
}
