import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getEffectiveRate, usdToIrr } from '@/lib/currency'

export const dynamic = 'force-dynamic'

interface ValidateBody {
  code?: string
  subtotalIrr?: number
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as ValidateBody
    const code = String(body.code || '').trim().toUpperCase()
    const subtotalIrr = Number(body.subtotalIrr)
    if (!code) return NextResponse.json({ valid: false, error: 'کد تخفیف را وارد کنید' }, { status: 400 })
    if (!Number.isFinite(subtotalIrr) || subtotalIrr < 0) {
      return NextResponse.json({ valid: false, error: 'مبلغ سبد نامعتبر است' }, { status: 400 })
    }

    const coupon = await db.coupon.findUnique({ where: { code } })
    if (!coupon || !coupon.active) {
      return NextResponse.json({ valid: false, error: 'کد تخفیف نامعتبر است' })
    }
    if (coupon.expiresAt && coupon.expiresAt.getTime() < Date.now()) {
      return NextResponse.json({ valid: false, error: 'این کد تخفیف منقضی شده است' })
    }
    if (coupon.usageLimit > 0 && coupon.usedCount >= coupon.usageLimit) {
      return NextResponse.json({ valid: false, error: 'سقف استفاده از این کد تکمیل شده است' })
    }
    if (subtotalIrr < coupon.minOrderIrr) {
      return NextResponse.json({
        valid: false,
        error: `حداقل خرید برای این کد ${new Intl.NumberFormat('fa-IR').format(coupon.minOrderIrr)} تومان است`,
      })
    }

    let discountIrr = 0
    if (coupon.type === 'PERCENT') {
      discountIrr = Math.round((subtotalIrr * coupon.value) / 100)
    } else {
      // FIXED amount off (in IRR)
      discountIrr = Math.min(coupon.value, subtotalIrr)
    }

    // For diagnostics only — fresh effective rate (so frontend can show $ equiv if needed)
    const eff = await getEffectiveRate()
    const totalAfterDiscount = Math.max(0, subtotalIrr - discountIrr)

    return NextResponse.json({
      valid: true,
      code: coupon.code,
      type: coupon.type,
      value: coupon.value,
      discountIrr,
      subtotalIrr,
      totalAfterDiscount,
      usdToIrrSample: usdToIrr(1, eff),
    })
  } catch (e) {
    console.error('[POST /api/coupons/validate]', e)
    return NextResponse.json({ valid: false, error: 'خطای سرور', detail: (e as Error).message }, { status: 500 })
  }
}
