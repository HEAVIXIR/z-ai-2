import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const brands = await db.brand.findMany({
      orderBy: { name: 'asc' },
      include: { _count: { select: { parts: true } } },
    })
    return NextResponse.json({
      brands: brands.map((b) => ({
        id: b.id,
        name: b.name,
        slug: b.slug,
        country: b.country,
        logoUrl: b.logoUrl,
        partsCount: b._count.parts,
      })),
    })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در دریافت برندها', detail: (e as Error).message }, { status: 500 })
  }
}
