import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getEffectiveRate, usdToIrr } from '@/lib/currency'

export const dynamic = 'force-dynamic'

interface OrderItemInput {
  partId: string
  quantity: number
}

interface CreateOrderBody {
  phone?: string
  name?: string
  family?: string
  address?: string
  items?: OrderItemInput[]
  mechanicId?: string
  couponCode?: string
  notes?: string
}

export async function GET(req: NextRequest) {
  try {
    const phone = new URL(req.url).searchParams.get('phone') || ''
    if (!phone) return NextResponse.json({ orders: [] })
    const orders = await db.order.findMany({
      where: { customer: { phone } },
      orderBy: { createdAt: 'desc' },
      include: {
        items: {
          include: {
            part: { select: { id: true, name: true, nameFa: true, sku: true, images: true, active: true } },
          },
        },
        payments: true,
        shipment: true,
        mechanic: { select: { id: true, shopName: true, name: true, family: true, phone: true } },
      },
    })
    return NextResponse.json({
      orders: orders.map((o) => ({
        id: o.id,
        orderNumber: o.orderNumber,
        status: o.status,
        paymentStatus: o.paymentStatus,
        subtotalUsd: o.subtotalUsd,
        shippingUsd: o.shippingUsd,
        discountIrr: o.discountIrr,
        totalUsd: o.totalUsd,
        totalIrr: o.totalIrr,
        currencyRateAtOrder: o.currencyRateAtOrder,
        marginPercentAtOrder: o.marginPercentAtOrder,
        couponCode: o.couponCode,
        shippingAddress: o.shippingAddress,
        notes: o.notes,
        createdAt: o.createdAt,
        updatedAt: o.updatedAt,
        items: o.items.map((it) => ({
          id: it.id,
          partId: it.partId,
          partNameSnapshot: it.partNameSnapshot,
          quantity: it.quantity,
          unitPriceUsd: it.unitPriceUsd,
          unitPriceIrr: it.unitPriceIrr,
          lineTotalUsd: it.lineTotalUsd,
          lineTotalIrr: it.lineTotalIrr,
          part: it.part,
        })),
        payments: o.payments.map((p) => ({
          id: p.id,
          amountIrr: p.amountIrr,
          amountUsd: p.amountUsd,
          method: p.method,
          status: p.status,
          referenceCode: p.referenceCode,
          payerName: p.payerName,
          payerCard: p.payerCard,
          gateway: p.gateway,
          refId: p.refId,
          authority: p.authority,
          note: p.note,
          createdAt: p.createdAt,
          reviewedAt: p.reviewedAt,
        })),
        shipment: o.shipment
          ? {
              id: o.shipment!.id,
              carrier: o.shipment!.carrier,
              trackingCode: o.shipment!.trackingCode,
              status: o.shipment!.status,
              shippedAt: o.shipment!.shippedAt,
              deliveredAt: o.shipment!.deliveredAt,
              note: o.shipment!.note,
            }
          : null,
        mechanic: o.mechanic,
      })),
    })
  } catch (e) {
    console.error('[GET /api/orders]', e)
    return NextResponse.json({ error: 'خطا در دریافت سفارش‌ها', detail: (e as Error).message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as CreateOrderBody
    const phone = String(body.phone || '').trim()
    const name = String(body.name || '').trim()
    const family = String(body.family || '').trim()
    const address = String(body.address || '').trim()
    const items = Array.isArray(body.items) ? body.items : []
    const mechanicId = body.mechanicId || undefined
    const couponCode = body.couponCode ? String(body.couponCode).trim().toUpperCase() : undefined
    const notes = body.notes ? String(body.notes).trim().slice(0, 1000) : null

    if (!phone || phone.length < 8) return NextResponse.json({ error: 'شماره موبایل معتبر وارد کنید' }, { status: 400 })
    if (!name) return NextResponse.json({ error: 'نام را وارد کنید' }, { status: 400 })
    if (!address) return NextResponse.json({ error: 'آدرس را وارد کنید' }, { status: 400 })
    if (!items.length) return NextResponse.json({ error: 'سبد خرید خالی است' }, { status: 400 })

    // fetch parts
    const partIds = items.map((i) => String(i.partId))
    const parts = await db.part.findMany({ where: { id: { in: partIds }, active: true } })
    if (parts.length !== partIds.length) {
      return NextResponse.json({ error: 'یکی از اقلام سبد دیگر موجود نیست' }, { status: 400 })
    }

    // validate stock
    for (const it of items) {
      const p = parts.find((x) => x.id === it.partId)!
      const qty = Math.max(1, Math.floor(Number(it.quantity) || 1))
      if (p.stock < qty) {
        return NextResponse.json({ error: `موجودی کافی نیست: ${p.nameFa || p.name} (موجودی ${p.stock} عدد)` }, { status: 400 })
      }
    }

    // effective rate + margin
    const eff = await getEffectiveRate()

    // subtotal (USD)
    let subtotalUsd = 0
    const orderItemData: any[] = []
    for (const it of items) {
      const p = parts.find((x) => x.id === it.partId)!
      const qty = Math.max(1, Math.floor(Number(it.quantity) || 1))
      const lineTotalUsd = p.priceUsd * qty
      subtotalUsd += lineTotalUsd
      const unitIrr = usdToIrr(p.priceUsd, eff)
      orderItemData.push({
        partId: p.id,
        partNameSnapshot: p.nameFa || p.name,
        quantity: qty,
        unitPriceUsd: p.priceUsd,
        unitPriceIrr: unitIrr,
        lineTotalUsd,
        lineTotalIrr: unitIrr * qty,
      })
    }

    // shipping flat (USD)
    const shippingSetting = await db.setting.findUnique({ where: { id: 'shippingFlatFeeUsd' } })
    const shippingUsd = shippingSetting ? Number(shippingSetting.value) || 2 : 2
    const grandUsdBeforeDiscount = subtotalUsd + shippingUsd
    const subtotalIrr = usdToIrr(grandUsdBeforeDiscount, eff)

    // coupon
    let discountIrr = 0
    let appliedCouponCode: string | null = null
    if (couponCode) {
      const coupon = await db.coupon.findUnique({ where: { code: couponCode } })
      if (!coupon || !coupon.active) {
        return NextResponse.json({ error: 'کد تخفیف نامعتبر است' }, { status: 400 })
      }
      if (coupon.expiresAt && coupon.expiresAt.getTime() < Date.now()) {
        return NextResponse.json({ error: 'کد تخفیف منقضی شده است' }, { status: 400 })
      }
      if (coupon.usageLimit > 0 && coupon.usedCount >= coupon.usageLimit) {
        return NextResponse.json({ error: 'سقف استفاده از کد تخفیف تکمیل شده است' }, { status: 400 })
      }
      if (subtotalIrr < coupon.minOrderIrr) {
        return NextResponse.json({
          error: `حداقل خرید برای این کد ${new Intl.NumberFormat('fa-IR').format(coupon.minOrderIrr)} تومان است`,
        }, { status: 400 })
      }
      if (coupon.type === 'PERCENT') discountIrr = Math.round((subtotalIrr * coupon.value) / 100)
      else discountIrr = Math.min(coupon.value, subtotalIrr)
      appliedCouponCode = coupon.code
    }

    const totalIrr = Math.max(0, subtotalIrr - discountIrr)
    const totalUsd = grandUsdBeforeDiscount // USD figure kept for the snapshot (no discount in USD)

    // upsert customer
    const customer = await db.customer.upsert({
      where: { phone },
      update: { name, family: family || undefined, address: address || undefined },
      create: { phone, name, family, address },
    })

    // generate order number ORD-<1000+count+1>
    const orderCount = await db.order.count()
    const orderNumber = `ORD-${1000 + orderCount + 1}`

    // create order + items + decrement stock + increment soldCount (in a tx)
    const order = await db.$transaction(async (tx) => {
      const created = await tx.order.create({
        data: {
          orderNumber,
          customerId: customer.id,
          mechanicId: mechanicId || null,
          status: 'PENDING',
          subtotalUsd,
          shippingUsd,
          discountIrr,
          totalUsd,
          totalIrr,
          currencyRateAtOrder: eff.rate,
          marginPercentAtOrder: eff.marginPercent,
          couponCode: appliedCouponCode,
          shippingAddress: address,
          notes,
          paymentStatus: 'UNPAID',
          items: { create: orderItemData },
        },
        include: { items: true },
      })

      for (const it of orderItemData) {
        await tx.part.update({
          where: { id: it.partId },
          data: {
            stock: { decrement: it.quantity },
            soldCount: { increment: it.quantity },
          },
        })
      }

      if (appliedCouponCode) {
        await tx.coupon.update({
          where: { code: appliedCouponCode },
          data: { usedCount: { increment: 1 } },
        })
      }

      await tx.customer.update({
        where: { id: customer.id },
        data: { totalOrders: { increment: 1 } },
      })

      return created
    })

    return NextResponse.json({
      ok: true,
      order: {
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        paymentStatus: order.paymentStatus,
        subtotalUsd: order.subtotalUsd,
        shippingUsd: order.shippingUsd,
        discountIrr: order.discountIrr,
        totalUsd: order.totalUsd,
        totalIrr: order.totalIrr,
        currencyRateAtOrder: order.currencyRateAtOrder,
        marginPercentAtOrder: order.marginPercentAtOrder,
        couponCode: order.couponCode,
        shippingAddress: order.shippingAddress,
        notes: order.notes,
        createdAt: order.createdAt,
        items: order.items,
      },
    })
  } catch (e) {
    console.error('[POST /api/orders]', e)
    return NextResponse.json({ error: 'خطا در ثبت سفارش', detail: (e as Error).message }, { status: 500 })
  }
}
