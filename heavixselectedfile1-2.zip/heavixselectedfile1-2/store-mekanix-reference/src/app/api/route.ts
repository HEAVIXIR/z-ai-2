import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getEffectiveRate } from '@/lib/currency'

export const dynamic = 'force-dynamic'

/** Public health-check / bootstrap info for the SPA. */
export async function GET() {
  const eff = await getEffectiveRate()
  const settings = await db.setting.findMany()
  const settingMap: Record<string, string> = {}
  for (const s of settings) settingMap[s.id] = s.value

  return NextResponse.json({
    name: 'بازار قطعات خودرو — API',
    status: 'ok',
    currency: eff,
    shopName: settingMap.shopName || 'بازار قطعات خودرو',
    shopPhone: settingMap.shopPhone || '',
    shippingFlatFeeUsd: Number(settingMap.shippingFlatFeeUsd || 2),
    time: new Date().toISOString(),
  })
}
