import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getEffectiveRate, usdToIrr } from '@/lib/currency'

export const dynamic = 'force-dynamic'

interface Row {
  id: string
  name: string
  nameFa: string | null
  sku: string
  description: string | null
  priceUsd: number
  oldPriceUsd: number | null
  stock: number
  lowStockThreshold: number
  images: string
  compatibleCars: string
  featured: boolean
  views: number
  soldCount: number
  createdAt: Date
  categoryId: string
  brandId: string | null
  brand: { id: string; name: string; country: string | null } | null
  category: { id: string; name: string; slug: string }
  carModels: { id: string; brand: string; model: string; yearFrom: number; yearTo: number }[]
  _count: { reviews: number; wishlists: number }
  reviews: { rating: number }[]
}

function decorate(row: Row, eff: { rate: number; marginPercent: number }) {
  const priceIrr = usdToIrr(row.priceUsd, eff)
  const oldPriceIrr = row.oldPriceUsd ? usdToIrr(row.oldPriceUsd, eff) : null
  const discountPercent =
    oldPriceIrr && oldPriceIrr > priceIrr
      ? Math.round(((oldPriceIrr - priceIrr) / oldPriceIrr) * 100)
      : null
  const ratings = row.reviews || []
  const ratingSum = ratings.reduce((a, r) => a + r.rating, 0)
  const ratingCount = ratings.length
  const ratingAvg = ratingCount ? Math.round((ratingSum / ratingCount) * 10) / 10 : 0
  let images: string[] = []
  try {
    images = JSON.parse(row.images || '[]')
  } catch {
    images = []
  }
  let compatibleCars: any[] = []
  try {
    compatibleCars = JSON.parse(row.compatibleCars || '[]')
  } catch {
    compatibleCars = []
  }
  return {
    id: row.id,
    name: row.name,
    nameFa: row.nameFa,
    sku: row.sku,
    description: row.description,
    priceUsd: row.priceUsd,
    priceIrr,
    priceIrrFormatted: new Intl.NumberFormat('fa-IR').format(priceIrr) + ' تومان',
    oldPriceUsd: row.oldPriceUsd,
    oldPriceIrr,
    oldPriceIrrFormatted: oldPriceIrr
      ? new Intl.NumberFormat('fa-IR').format(oldPriceIrr) + ' تومان'
      : null,
    discountPercent,
    stock: row.stock,
    lowStockThreshold: row.lowStockThreshold,
    images,
    compatibleCars,
    featured: row.featured,
    views: row.views,
    soldCount: row.soldCount,
    createdAt: row.createdAt,
    brand: row.brand,
    category: row.category,
    carModels: row.carModels,
    ratingAvg,
    ratingCount,
    wishlistCount: row._count.wishlists,
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const q = searchParams.get('q')?.trim() || ''
    const categoryId = searchParams.get('categoryId')
    const brandId = searchParams.get('brandId')
    const carModelId = searchParams.get('carModelId')
    const sort = searchParams.get('sort') || 'newest'
    const featured = searchParams.get('featured')
    const onlyInStock = searchParams.get('onlyInStock') === 'true'
    const onlyDiscount = searchParams.get('onlyDiscount') === 'true'

    const where: any = { active: true }
    if (q) {
      where.OR = [
        { name: { contains: q } },
        { nameFa: { contains: q } },
        { sku: { contains: q } },
        { description: { contains: q } },
      ]
    }
    if (categoryId) where.categoryId = categoryId
    if (brandId) where.brandId = brandId
    if (carModelId) where.carModels = { some: { id: carModelId } }
    if (featured === 'true') where.featured = true
    if (onlyInStock) where.stock = { gt: 0 }
    if (onlyDiscount) where.oldPriceUsd = { not: null }

    let orderBy: any = { createdAt: 'desc' }
    if (sort === 'price-asc') orderBy = { priceUsd: 'asc' }
    else if (sort === 'price-desc') orderBy = { priceUsd: 'desc' }
    else if (sort === 'popular') orderBy = { views: 'desc' }
    else if (sort === 'bestseller') orderBy = { soldCount: 'desc' }

    const eff = await getEffectiveRate()

    const rows = (await db.part.findMany({
      where,
      orderBy,
      include: {
        brand: { select: { id: true, name: true, country: true } },
        category: { select: { id: true, name: true, slug: true } },
        carModels: { select: { id: true, brand: true, model: true, yearFrom: true, yearTo: true } },
        reviews: { where: { approved: true }, select: { rating: true } },
        _count: { select: { reviews: true, wishlists: true } },
      },
    })) as unknown as Row[]

    const parts = rows.map((r) => decorate(r, eff))
    return NextResponse.json({ parts, currency: eff })
  } catch (e) {
    console.error('[GET /api/parts]', e)
    return NextResponse.json(
      { error: 'خطا در دریافت لیست قطعات', detail: (e as Error).message },
      { status: 500 },
    )
  }
}
