import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    const reviews = await db.review.findMany({
      where: { partId: id, approved: true },
      orderBy: { createdAt: 'desc' },
      include: { customer: { select: { name: true, family: true } } },
    })
    return NextResponse.json({
      reviews: reviews.map((r) => ({
        id: r.id,
        rating: r.rating,
        title: r.title,
        comment: r.comment,
        createdAt: r.createdAt,
        customerName: [r.customer.name, r.customer.family].filter(Boolean).join(' '),
      })),
    })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در دریافت نظرات', detail: (e as Error).message }, { status: 500 })
  }
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id: partId } = await ctx.params
    const body = await req.json().catch(() => ({}))
    const phone = String(body.phone || '').trim()
    const name = String(body.name || '').trim()
    const family = String(body.family || '').trim()
    const rating = Number(body.rating)
    const title = body.title ? String(body.title).trim().slice(0, 200) : null
    const comment = body.comment ? String(body.comment).trim().slice(0, 2000) : null

    if (!phone || phone.length < 8) {
      return NextResponse.json({ error: 'شماره موبایل معتبر وارد کنید' }, { status: 400 })
    }
    if (!name) {
      return NextResponse.json({ error: 'نام را وارد کنید' }, { status: 400 })
    }
    if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'امتیاز باید بین ۱ تا ۵ باشد' }, { status: 400 })
    }

    const part = await db.part.findUnique({ where: { id: partId } })
    if (!part) return NextResponse.json({ error: 'قطعه یافت نشد' }, { status: 404 })

    const customer = await db.customer.upsert({
      where: { phone },
      update: { name },
      create: { phone, name, family },
    })

    const review = await db.review.create({
      data: {
        partId,
        customerId: customer.id,
        rating,
        title,
        comment,
        approved: false, // pending moderation
      },
    })
    return NextResponse.json({ review, message: 'نظر شما پس از تایید مدیر نمایش داده می‌شود' })
  } catch (e) {
    console.error('[POST /api/parts/[id]/reviews]', e)
    return NextResponse.json({ error: 'خطا در ثبت نظر', detail: (e as Error).message }, { status: 500 })
  }
}
