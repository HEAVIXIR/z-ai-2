import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getEffectiveRate, usdToIrr } from '@/lib/currency'

export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    const part = await db.part.findUnique({
      where: { id },
      include: {
        brand: { select: { id: true, name: true, country: true } },
        category: { select: { id: true, name: true, slug: true } },
        carModels: { select: { id: true, brand: true, model: true, yearFrom: true, yearTo: true } },
        reviews: {
          where: { approved: true },
          orderBy: { createdAt: 'desc' },
          include: {
            customer: { select: { name: true, family: true } },
          },
        },
        _count: { select: { reviews: true, wishlists: true } },
      },
    })
    if (!part) return NextResponse.json({ error: 'قطعه یافت نشد' }, { status: 404 })

    // increment views (best-effort, non-blocking)
    db.part.update({ where: { id }, data: { views: { increment: 1 } } }).catch(() => {})

    const eff = await getEffectiveRate()
    const priceIrr = usdToIrr(part.priceUsd, eff)
    const oldPriceIrr = part.oldPriceUsd ? usdToIrr(part.oldPriceUsd, eff) : null
    const discountPercent =
      oldPriceIrr && oldPriceIrr > priceIrr
        ? Math.round(((oldPriceIrr - priceIrr) / oldPriceIrr) * 100)
        : null

    const ratings = part.reviews || []
    const ratingSum = ratings.reduce((a, r) => a + r.rating, 0)
    const ratingCount = ratings.length
    const ratingAvg = ratingCount ? Math.round((ratingSum / ratingCount) * 10) / 10 : 0

    let images: string[] = []
    try {
      images = JSON.parse((part.images as string) || '[]')
    } catch {
      images = []
    }
    let compatibleCars: any[] = []
    try {
      compatibleCars = JSON.parse((part.compatibleCars as string) || '[]')
    } catch {
      compatibleCars = []
    }

    return NextResponse.json({
      part: {
        ...part,
        priceIrr,
        priceIrrFormatted: new Intl.NumberFormat('fa-IR').format(priceIrr) + ' تومان',
        oldPriceIrr,
        oldPriceIrrFormatted: oldPriceIrr
          ? new Intl.NumberFormat('fa-IR').format(oldPriceIrr) + ' تومان'
          : null,
        discountPercent,
        images,
        compatibleCars,
        ratingAvg,
        ratingCount,
        wishlistCount: part._count.wishlists,
        reviews: part.reviews.map((r) => ({
          id: r.id,
          rating: r.rating,
          title: r.title,
          comment: r.comment,
          createdAt: r.createdAt,
          customerName: [r.customer.name, r.customer.family].filter(Boolean).join(' '),
        })),
      },
      currency: eff,
    })
  } catch (e) {
    console.error('[GET /api/parts/[id]]', e)
    return NextResponse.json({ error: 'خطا در دریافت قطعه', detail: (e as Error).message }, { status: 500 })
  }
}
