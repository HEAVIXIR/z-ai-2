import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const mechanics = await db.mechanic.findMany({
      where: { verified: true, status: 'ACTIVE' },
      orderBy: { rating: 'desc' },
    })
    return NextResponse.json({
      mechanics: mechanics.map((m) => ({
        id: m.id,
        name: m.name,
        family: m.family,
        shopName: m.shopName,
        specialty: m.specialty,
        city: m.city,
        address: m.address,
        phone: m.phone,
        rating: m.rating,
        verified: m.verified,
        totalOrders: m.totalOrders,
      })),
    })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در دریافت تعمیرکاران', detail: (e as Error).message }, { status: 500 })
  }
}
