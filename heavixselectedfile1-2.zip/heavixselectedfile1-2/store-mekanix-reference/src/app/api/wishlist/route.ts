import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const phone = new URL(req.url).searchParams.get('phone') || ''
    if (!phone) return NextResponse.json({ partIds: [] })
    const customer = await db.customer.findUnique({
      where: { phone },
      include: { wishlists: { select: { partId: true } } },
    })
    if (!customer) return NextResponse.json({ partIds: [] })
    return NextResponse.json({ partIds: customer.wishlists.map((w) => w.partId) })
  } catch (e) {
    return NextResponse.json({ error: 'خطا', detail: (e as Error).message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const phone = String(body.phone || '').trim()
    const partId = String(body.partId || '').trim()
    const action = String(body.action || 'add') as 'add' | 'remove'

    if (!phone || phone.length < 8) return NextResponse.json({ error: 'شماره موبایل معتبر وارد کنید' }, { status: 400 })
    if (!partId) return NextResponse.json({ error: 'قطعه مشخص نیست' }, { status: 400 })

    const part = await db.part.findUnique({ where: { id: partId } })
    if (!part) return NextResponse.json({ error: 'قطعه یافت نشد' }, { status: 404 })

    const customer = await db.customer.upsert({
      where: { phone },
      update: {},
      create: { phone, name: 'مشتری', family: '' },
      include: { wishlists: { select: { partId: true } } },
    })

    const existing = await db.wishlist.findUnique({
      where: { customerId_partId: { customerId: customer.id, partId } },
    })

    if (action === 'add') {
      if (!existing) await db.wishlist.create({ data: { customerId: customer.id, partId } })
    } else {
      if (existing) await db.wishlist.delete({ where: { id: existing.id } })
    }

    const fresh = await db.wishlist.findMany({
      where: { customerId: customer.id },
      select: { partId: true },
    })
    return NextResponse.json({ partIds: fresh.map((w) => w.partId) })
  } catch (e) {
    console.error('[POST /api/wishlist]', e)
    return NextResponse.json({ error: 'خطا در به‌روزرسانی علاقه‌مندی', detail: (e as Error).message }, { status: 500 })
  }
}
