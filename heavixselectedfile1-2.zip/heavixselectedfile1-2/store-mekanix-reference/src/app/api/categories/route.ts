import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const cats = await db.category.findMany({
      include: { children: true },
      orderBy: { name: 'asc' },
    })
    // build tree (top-level first, with nested children)
    const byId = new Map<string, any>()
    cats.forEach((c) =>
      byId.set(c.id, {
        id: c.id,
        name: c.name,
        slug: c.slug,
        icon: c.icon,
        parentId: c.parentId,
        children: [],
      }),
    )
    const roots: any[] = []
    byId.forEach((c) => {
      if (c.parentId && byId.has(c.parentId)) {
        byId.get(c.parentId).children.push(c)
      } else {
        roots.push(c)
      }
    })
    return NextResponse.json({ categories: roots })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در دریافت دسته‌بندی‌ها', detail: (e as Error).message }, { status: 500 })
  }
}
