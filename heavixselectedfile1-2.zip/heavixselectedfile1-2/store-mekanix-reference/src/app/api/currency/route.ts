import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getEffectiveRate } from '@/lib/currency'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const eff = await getEffectiveRate()
    const setting = await db.currencySetting.findUnique({ where: { id: 'singleton' } })
    return NextResponse.json({
      rate: eff.rate,
      marginPercent: eff.marginPercent,
      source: eff.source,
      date: eff.date,
      // from setting
      lastAutoRate: setting?.lastAutoRate ?? null,
      lastAutoStatus: setting?.lastAutoStatus ?? null,
      lastAutoFetchAt: setting?.lastAutoFetchAt ?? null,
      autoUpdateEnabled: setting?.autoUpdateEnabled ?? false,
      autoSource: setting?.autoSource ?? null,
      defaultRate: setting?.defaultRate ?? null,
    })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در دریافت نرخ ارز', detail: (e as Error).message }, { status: 500 })
  }
}
