import { NextResponse } from 'next/server'
import { refreshTelegramRateInDB } from '@/lib/telegram-rate'
import { getEffectiveRate } from '@/lib/currency'

export const dynamic = 'force-dynamic'

export async function POST() {
  try {
    const rate = await refreshTelegramRateInDB()
    if (!rate) {
      const eff = await getEffectiveRate()
      return NextResponse.json(
        {
          ok: false,
          message: 'دریافت نرخ از تلگرام ناموفق بود؛ نرخ فعلی نمایش داده می‌شود',
          rate: eff.rate,
          source: eff.source,
        },
        { status: 200 },
      )
    }
    const eff = await getEffectiveRate()
    return NextResponse.json({
      ok: true,
      message: 'نرخ با موفقیت از تلگرام بروزرسانی شد',
      rate: rate.rate,
      status: rate.status,
      fetchedAt: rate.fetchedAt,
      effective: eff,
    })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در بروزرسانی نرخ', detail: (e as Error).message }, { status: 500 })
  }
}
