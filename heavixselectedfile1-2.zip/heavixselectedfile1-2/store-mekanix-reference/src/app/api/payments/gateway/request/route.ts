import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requestPayment } from '@/lib/zarinpal'

export const dynamic = 'force-dynamic'

interface ReqBody {
  orderId?: string
  phone?: string
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as ReqBody
    const orderId = String(body.orderId || '').trim()
    const phone = String(body.phone || '').trim()
    if (!orderId) return NextResponse.json({ error: 'سفارش مشخص نیست' }, { status: 400 })
    if (!phone) return NextResponse.json({ error: 'شماره موبایل را وارد کنید' }, { status: 400 })

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: { customer: true },
    })
    if (!order) return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 })
    if (order.customer.phone !== phone) {
      return NextResponse.json({ error: 'این سفارش متعلق به شما نیست' }, { status: 403 })
    }
    if (order.paymentStatus === 'PAID') {
      return NextResponse.json({ error: 'این سفارش قبلاً پرداخت شده است' }, { status: 400 })
    }

    const amountIrr = Math.round(order.totalIrr)
    if (!Number.isFinite(amountIrr) || amountIrr <= 0) {
      return NextResponse.json({ error: 'مبلغ سفارش نامعتبر است' }, { status: 400 })
    }

    // Build the absolute callback URL. We must use the host from the request so
    // Zarinpal can reach us back. In the sandbox/mock path the URL is relative.
    const host = req.headers.get('x-forwarded-host') || req.headers.get('host') || ''
    const proto = req.headers.get('x-forwarded-proto') || (host.startsWith('localhost') ? 'http' : 'https')
    const callbackUrl = host ? `${proto}://${host}/api/payments/gateway/callback` : '/api/payments/gateway/callback'

    const result = await requestPayment({
      amountIrr,
      description: `سفارش ${order.orderNumber} — بازار قطعات خودرو`,
      callbackUrl,
      mobile: phone,
      orderNumber: order.orderNumber,
    })

    // Save Payment row with PENDING status
    const payment = await db.payment.create({
      data: {
        orderId: order.id,
        customerId: order.customerId,
        amountIrr,
        amountUsd: order.totalUsd,
        method: 'GATEWAY',
        status: 'PENDING',
        gateway: result.method,
        authority: result.authority,
        gatewayUrl: result.gatewayUrl,
      },
    })

    // In mock mode, zarinpal.ts returns `/api/payment/mock-gateway?Authority=...`.
    // Our actual route lives at `/api/payments/mock-gateway`. Normalize the path so
    // the browser lands on our mock-gateway handler regardless.
    let finalGatewayUrl = result.gatewayUrl
    if (result.method === 'MOCK' && finalGatewayUrl.startsWith('/api/payment/mock-gateway')) {
      finalGatewayUrl = finalGatewayUrl.replace('/api/payment/mock-gateway', '/api/payments/mock-gateway')
    }

    // mark order paymentStatus = PENDING
    if (order.paymentStatus === 'UNPAID') {
      await db.order.update({ where: { id: order.id }, data: { paymentStatus: 'PENDING' } })
    }

    return NextResponse.json({
      ok: true,
      authority: result.authority,
      gatewayUrl: finalGatewayUrl,
      method: result.method,
      paymentId: payment.id,
    })
  } catch (e) {
    console.error('[POST /api/payments/gateway/request]', e)
    return NextResponse.json({ error: 'خطا در ایجاد درگاه پرداخت', detail: (e as Error).message }, { status: 500 })
  }
}
