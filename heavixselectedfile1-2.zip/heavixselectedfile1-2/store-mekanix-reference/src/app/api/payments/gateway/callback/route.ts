import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPayment } from '@/lib/zarinpal'

export const dynamic = 'force-dynamic'

function htmlRedirect(targetPath: string, message: string, isError = false) {
  const color = isError ? '#dc2626' : '#059669'
  return new NextResponse(
    `<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>بازار قطعات خودرو — درگاه پرداخت</title>
<script>
  // Give the user a brief moment to read the message, then bounce them home.
  setTimeout(function () {
    window.location.replace('${targetPath}');
  }, 2500);
</script>
<style>
  body{margin:0;font-family:Vazirmatn,system-ui,Segoe UI,Tahoma,sans-serif;background:#f7f7f7;color:#0a0a0a}
  .wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
  .card{background:#fff;border-radius:1rem;box-shadow:0 8px 30px rgba(0,0,0,.08);padding:2rem 1.5rem;max-width:480px;width:100%;text-align:center}
  .badge{width:64px;height:64px;border-radius:9999px;margin:0 auto 1rem;display:flex;align-items:center;justify-content:center;font-size:32px;background:${color}22;color:${color}}
  h1{font-size:1.25rem;margin:.25rem 0 .5rem}
  p{color:#525252;font-size:.95rem;line-height:1.7}
  .count{font-size:.8rem;color:#9ca3af;margin-top:.75rem}
</style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <div class="badge">${isError ? '✕' : '✓'}</div>
      <h1>${message}</h1>
      <p>در حال انتقال به صفحه اصلی...</p>
      <div class="count">اگر به‌صورت خودکار منتقل نشدید، <a href="${targetPath}">اینجا کلیک کنید</a>.</div>
    </div>
  </div>
</body>
</html>`,
    {
      status: 200,
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    },
  )
}

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const authority = url.searchParams.get('Authority') || url.searchParams.get('authority') || ''
    const status = url.searchParams.get('Status') || url.searchParams.get('status') || 'NOK'

    if (!authority) {
      return htmlRedirect('/?payment=failed', 'شناسه پرداخت یافت نشد', true)
    }

    const payment = await db.payment.findFirst({
      where: { authority },
      include: { order: { include: { customer: true } } },
    })
    if (!payment) {
      return htmlRedirect('/?payment=failed', 'پرداخت نامعتبر است', true)
    }

    const order = payment.order
    const amountIrr = Math.round(payment.amountIrr)

    const verify = await verifyPayment({ authority, status, amountIrr })

    if (verify.success && verify.refId) {
      await db.$transaction(async (tx) => {
        await tx.payment.update({
          where: { id: payment.id },
          data: {
            status: 'APPROVED',
            refId: verify.refId,
            reviewedAt: new Date(),
            note: (payment.note ? payment.note + ' | ' : '') + `تایید خودکار درگاه — refId: ${verify.refId}`,
          },
        })
        await tx.order.update({
          where: { id: order.id },
          data: {
            paymentStatus: 'PAID',
            ...(order.status === 'PENDING' ? { status: 'CONFIRMED' } : {}),
          },
        })
        await tx.customer.update({
          where: { id: order.customerId },
          data: { totalSpentIrr: { increment: amountIrr } },
        })
      })
      return htmlRedirect(`/?payment=success&order=${order.orderNumber}`, 'پرداخت شما با موفقیت انجام شد')
    } else {
      await db.payment.update({
        where: { id: payment.id },
        data: { status: 'REJECTED', refId: verify.refId ?? null },
      })
      return htmlRedirect(`/?payment=failed&order=${order.orderNumber}`, 'پرداخت ناموفق بود', true)
    }
  } catch (e) {
    console.error('[GET /api/payments/gateway/callback]', e)
    return htmlRedirect('/?payment=failed', 'خطا در پردازش پرداخت', true)
  }
}
