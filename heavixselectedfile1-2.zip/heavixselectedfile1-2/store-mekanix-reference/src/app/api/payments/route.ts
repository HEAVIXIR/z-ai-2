import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const orderId = url.searchParams.get('orderId')
    const phone = url.searchParams.get('phone')

    const where: any = {}
    if (orderId) where.orderId = orderId
    if (phone) where.customer = { phone }

    const payments = await db.payment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: { order: { select: { orderNumber: true, id: true, totalIrr: true } } },
    })

    return NextResponse.json({
      payments: payments.map((p) => ({
        id: p.id,
        orderId: p.orderId,
        orderNumber: p.order?.orderNumber,
        amountIrr: p.amountIrr,
        amountUsd: p.amountUsd,
        method: p.method,
        status: p.status,
        gateway: p.gateway,
        authority: p.authority,
        refId: p.refId,
        referenceCode: p.referenceCode,
        payerName: p.payerName,
        payerCard: p.payerCard,
        note: p.note,
        createdAt: p.createdAt,
        reviewedAt: p.reviewedAt,
      })),
    })
  } catch (e) {
    return NextResponse.json({ error: 'خطا در دریافت پرداخت‌ها', detail: (e as Error).message }, { status: 500 })
  }
}
