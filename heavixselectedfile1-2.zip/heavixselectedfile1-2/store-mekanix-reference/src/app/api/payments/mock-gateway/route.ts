import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

/**
 * Mock Zarinpal gateway (sandbox).
 *
 * Rendered when ZARINPAL_MERCHANT_ID is not set. Reads ?Authority&Amount,
 * looks up the payment row to confirm, and shows two buttons:
 *   "پرداخت موفق"  -> /api/payments/gateway/callback?Authority=...&Status=OK
 *   "پرداخت ناموفق" -> /api/payments/gateway/callback?Authority=...&Status=NOK
 */
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const authority = url.searchParams.get('Authority') || ''
    const amount = url.searchParams.get('Amount') || ''

    let orderNumber = '—'
    if (authority) {
      const payment = await db.payment.findFirst({
        where: { authority },
        include: { order: { select: { orderNumber: true, totalIrr: true } } },
      })
      if (payment?.order?.orderNumber) {
        orderNumber = payment.order.orderNumber
      }
    }

    const successUrl = `/api/payments/gateway/callback?Authority=${encodeURIComponent(authority)}&Status=OK`
    const failureUrl = `/api/payments/gateway/callback?Authority=${encodeURIComponent(authority)}&Status=NOK`

    const amountFa = amount
      ? new Intl.NumberFormat('fa-IR').format(Number(amount)) + ' تومان'
      : '—'

    const html = `<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>درگاه پرداخت تستی — بازار قطعات خودرو</title>
<style>
  *{box-sizing:border-box}
  body{margin:0;font-family:Vazirmatn,system-ui,Segoe UI,Tahoma,sans-serif;background:linear-gradient(135deg,#f5f5f4 0%,#fafaf9 100%);color:#0a0a0a;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
  .card{background:#fff;border-radius:1.25rem;box-shadow:0 12px 40px rgba(0,0,0,.08);padding:2rem 1.75rem;max-width:460px;width:100%;text-align:center;border:1px solid #e7e5e4}
  .logo{font-size:1.1rem;font-weight:700;color:#1c1917;margin-bottom:.5rem}
  .sub{color:#78716c;font-size:.85rem;margin-bottom:1.5rem}
  .amount-box{background:#f5f5f4;border-radius:.75rem;padding:1rem;margin:1rem 0}
  .amount-box .lbl{font-size:.75rem;color:#78716c;margin-bottom:.25rem}
  .amount-box .val{font-size:1.5rem;font-weight:700;color:#059669;font-variant-numeric:tabular-nums}
  .meta{font-size:.8rem;color:#57534e;margin-top:.5rem}
  .row{display:flex;gap:.5rem;margin-top:1.5rem;flex-direction:column}
  .btn{display:block;width:100%;padding:.85rem 1rem;border-radius:.65rem;font-size:.95rem;font-weight:600;cursor:pointer;text-decoration:none;border:none;transition:transform .08s ease, filter .2s ease}
  .btn:active{transform:translateY(1px)}
  .btn-ok{background:#059669;color:#fff}
  .btn-ok:hover{filter:brightness(1.05)}
  .btn-nok{background:#fff;color:#dc2626;border:1.5px solid #fecaca}
  .btn-nok:hover{background:#fef2f2}
  .note{margin-top:1.25rem;padding:.6rem .75rem;background:#fef9c3;color:#713f12;border-radius:.5rem;font-size:.75rem;line-height:1.6}
</style>
</head>
<body>
  <div class="card">
    <div class="logo">🛒 بازار قطعات خودرو</div>
    <div class="sub">درگاه پرداخت تستی (Mock Gateway)</div>
    <div class="amount-box">
      <div class="lbl">مبلغ قابل پرداخت</div>
      <div class="val">${amountFa}</div>
      <div class="meta">سفارش ${orderNumber} • شناسه ${authority ? authority.slice(0, 14) : '—'}</div>
    </div>
    <div class="row">
      <a class="btn btn-ok" href="${successUrl}">پرداخت موفق ✓</a>
      <a class="btn btn-nok" href="${failureUrl}">پرداخت ناموفق ✕</a>
    </div>
    <div class="note">
      این یک درگاه پرداخت شبیه‌سازی‌شده برای تست است. در حالت واقعی، کاربر به
      صفحه‌ی زرین‌پال هدایت می‌شود. برای فعال‌سازی درگاه واقعی، متغیر محیطی
      <code>ZARINPAL_MERCHANT_ID</code> را تنظیم کنید.
    </div>
  </div>
</body>
</html>`
    return new NextResponse(html, {
      status: 200,
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    })
  } catch (e) {
    return new NextResponse(
      `<!doctype html><meta charset="utf-8"><title>خطا</title><p dir="rtl">خطا در بارگذاری درگاه: ${(e as Error).message}</p>`,
      { status: 500, headers: { 'Content-Type': 'text/html; charset=utf-8' } },
    )
  }
}
