import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

interface ManualBody {
  orderId?: string
  phone?: string
  amountIrr?: number
  method?: string // CARD | WALLET | CASH
  referenceCode?: string
  payerName?: string
  payerCard?: string
  note?: string
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as ManualBody
    const orderId = String(body.orderId || '').trim()
    const phone = String(body.phone || '').trim()
    const method = String(body.method || 'CARD').toUpperCase()
    const referenceCode = body.referenceCode ? String(body.referenceCode).trim().slice(0, 200) : null
    const payerName = body.payerName ? String(body.payerName).trim().slice(0, 200) : null
    const payerCard = body.payerCard ? String(body.payerCard).trim().slice(0, 100) : null
    const note = body.note ? String(body.note).trim().slice(0, 1000) : null

    if (!orderId) return NextResponse.json({ error: 'سفارش مشخص نیست' }, { status: 400 })
    if (!phone) return NextResponse.json({ error: 'شماره موبایل را وارد کنید' }, { status: 400 })
    if (!['CARD', 'WALLET', 'CASH'].includes(method)) {
      return NextResponse.json({ error: 'روش پرداخت نامعتبر است' }, { status: 400 })
    }

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: { customer: true },
    })
    if (!order) return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 })
    if (order.customer.phone !== phone) {
      return NextResponse.json({ error: 'این سفارش متعلق به شما نیست' }, { status: 403 })
    }

    const payment = await db.payment.create({
      data: {
        orderId: order.id,
        customerId: order.customerId,
        amountIrr: body.amountIrr ?? order.totalIrr,
        amountUsd: order.totalUsd,
        method,
        status: 'PENDING',
        referenceCode,
        payerName,
        payerCard,
        note,
      },
    })

    // mark order paymentStatus = PENDING (awaiting admin review)
    if (order.paymentStatus === 'UNPAID') {
      await db.order.update({ where: { id: order.id }, data: { paymentStatus: 'PENDING' } })
    }

    return NextResponse.json({
      ok: true,
      payment,
      message: 'فیش شما ثبت شد و در انتظار تایید مدیر است',
    })
  } catch (e) {
    console.error('[POST /api/payments/manual]', e)
    return NextResponse.json({ error: 'خطا در ثبت فیش', detail: (e as Error).message }, { status: 500 })
  }
}
