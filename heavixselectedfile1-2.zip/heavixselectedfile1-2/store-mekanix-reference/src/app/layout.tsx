import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";
import { Toaster as Sonner } from "@/components/ui/sonner";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: "بازار قطعات خودرو",
  description:
    "بازار آنلاین قطعات خودرو — خرید آسان قطعات اصلی و باکیفیت با نرخ روز دلار و درگاه پرداخت امن.",
  keywords: [
    "قطعات خودرو",
    "لوازم یدکی",
    "بازار قطعات",
    "تویوتا",
    "هیوندای",
    "کیا",
    "پژو",
    "زرین‌پال",
  ],
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className={`${vazirmatn.variable} font-sans antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        {children}
        <Sonner position="top-center" richColors closeButton />
      </body>
    </html>
  );
}
