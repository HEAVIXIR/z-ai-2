'use client'

import { Phone, MapPin, Mail, Instagram, Send, Truck, ShieldCheck } from 'lucide-react'

export function Footer({
  shopName,
  shopPhone,
}: {
  shopName: string
  shopPhone: string
}) {
  return (
    <footer className="mt-auto border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-7xl px-3 sm:px-4 py-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-foreground text-background grid place-items-center font-bold">ب</div>
            <h3 className="font-bold">{shopName}</h3>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            خرید آنلاین قطعات خودرو با ضمانت اصالت کالا، نرخ روز دلار و ارسال
            سریع به سراسر کشور.
          </p>
        </div>

        <div className="space-y-1.5">
          <h4 className="text-xs font-bold mb-1 text-muted-foreground">دسترسی سریع</h4>
          <ul className="space-y-1 text-sm">
            <li><a href="#" className="hover:text-foreground text-muted-foreground">قطعات منتخب</a></li>
            <li><a href="#" className="hover:text-foreground text-muted-foreground">تخفیف‌های ویژه</a></li>
            <li><a href="#" className="hover:text-foreground text-muted-foreground">پرفروش‌ترین‌ها</a></li>
            <li><a href="#" className="hover:text-foreground text-muted-foreground">سفارش‌های من</a></li>
          </ul>
        </div>

        <div className="space-y-1.5">
          <h4 className="text-xs font-bold mb-1 text-muted-foreground">تماس با ما</h4>
          <ul className="space-y-1.5 text-sm text-muted-foreground">
            <li className="flex items-center gap-2" dir="ltr">
              <Phone className="size-3.5" />
              {shopPhone || '۰۲۱-۱۲۳۴۵۶۷۸'}
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="size-3.5" />
              تهران، خیابان ولیعصر
            </li>
            <li className="flex items-center gap-2">
              <Mail className="size-3.5" />
              info@autoparts.ir
            </li>
          </ul>
        </div>

        <div className="space-y-2">
          <h4 className="text-xs font-bold mb-1 text-muted-foreground">خدمات</h4>
          <ul className="space-y-1.5 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <ShieldCheck className="size-3.5 text-success" />
              ضمانت اصالت کالا
            </li>
            <li className="flex items-center gap-2">
              <Truck className="size-3.5 text-warning" />
              ارسال به سراسر ایران
            </li>
            <li className="flex items-center gap-2">
              <Send className="size-3.5 text-foreground" />
              پشتیبانی آنلاین
            </li>
          </ul>
          <div className="flex gap-1.5 pt-1">
            <a href="#" aria-label="Instagram" className="size-8 grid place-items-center rounded bg-background border border-border hover:border-foreground">
              <Instagram className="size-4" />
            </a>
            <a href="#" aria-label="Telegram" className="size-8 grid place-items-center rounded bg-background border border-border hover:border-foreground">
              <Send className="size-4" />
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-border/70 py-3 text-center text-xs text-muted-foreground">
        © <span className="num-fa">۱۴۰۳</span> — تمامی حقوق برای {shopName} محفوظ است.
      </div>
    </footer>
  )
}
