import { PrismaClient } from '@prisma/client'
import { hashPassword } from '../src/lib/password'
import { fetchTelegramRate } from '../src/lib/telegram-rate'

const db = new PrismaClient()

async function main() {
  console.log('Seeding comprehensive catalog...')

  // ---- Currency setting ----
  await db.currencySetting.upsert({
    where: { id: 'singleton' },
    update: { autoUpdateEnabled: true, autoSource: 'telegram' },
    create: { id: 'singleton', defaultRate: 230000, marginPercent: 3, autoUpdateEnabled: true, autoSource: 'telegram' },
  })

  const tgRate = await fetchTelegramRate(true)
  if (tgRate) {
    console.log(`  Telegram rate: ${tgRate.rate.toLocaleString()} تومان (${tgRate.status})`)
    await db.currencySetting.update({
      where: { id: 'singleton' },
      data: { lastAutoRate: tgRate.rate, lastAutoStatus: tgRate.status, lastAutoFetchAt: tgRate.fetchedAt },
    })
  }

  const now = new Date()
  const tehran = new Date(now.getTime() + (3.5 * 60 + now.getTimezoneOffset()) * 60000)
  const today = `${tehran.getUTCFullYear()}-${String(tehran.getUTCMonth() + 1).padStart(2, '0')}-${String(tehran.getUTCDate()).padStart(2, '0')}`
  await db.currencyRate.upsert({
    where: { date: today },
    update: {},
    create: { date: today, rate: tgRate?.rate ?? 230000, marginPercent: 3, source: tgRate ? 'TELEGRAM' : 'MANUAL', note: tgRate ? `نرخ تلگرام (${tgRate.status})` : 'نرخ اولیه' },
  })

  // ---- Admin users ----
  await db.adminUser.upsert({ where: { username: 'admin' }, update: {}, create: { username: 'admin', passwordHash: hashPassword('admin12345'), name: 'مدیر ارشد', role: 'SUPER_ADMIN', active: true } })
  await db.adminUser.upsert({ where: { username: 'operator' }, update: {}, create: { username: 'operator', passwordHash: hashPassword('operator123'), name: 'اپراتور فروش', role: 'OPERATOR', active: true } })

  // ==========================================================================
  // CAR MODELS — PASSENGER (Iranian-assembled + common imports)
  // ==========================================================================
  console.log('  creating passenger car models...')
  async function pm(brand: string, model: string, yearFrom: number, yearTo: number) {
    const e = await db.carModel.findFirst({ where: { brand, model } });
    if (e) return e;
    return db.carModel.create({ data: { brand, model, yearFrom, yearTo, type: 'PASSENGER' } })
  }

  // ایران‌خودرو
  const peugeot206 = await pm('پژو', '۲۰۶ (SD/تیپ۵)', 2001, 2024)
  const peugeot207 = await pm('پژو', '۲۰۷', 2010, 2024)
  const peugeotPars = await pm('پژو', 'پارس', 1999, 2024)
  const peugeot405 = await pm('پژو', '۴۰۵', 1990, 2024)
  const samand = await pm('سمند', 'LX/ELX', 2000, 2018)
  const samandSoren = await pm('سمند', 'سورن', 2007, 2018)
  const dena = await pm('دنا', 'استاندارد/توربو', 2015, 2024)
  const denaPlus = await pm('دنا', 'پلاس توربو', 2018, 2024)
  const rana = await pm('رانا', 'استاندارد/پلاس', 2015, 2024)
  const tara = await pm('تارا', 'Tara', 2021, 2024)
  const shahinIK = await pm('شاهین', 'Shahin', 2022, 2024)

  // سایپا
  const pride131 = await pm('پراید', '۱۳۱', 1993, 2024)
  const pride132 = await pm('پراید', '۱۳۲', 2001, 2024)
  const pride141 = await pm('پراید', '۱۴۱ (سی‌رو)', 2005, 2024)
  const quick = await pm('کوییک', 'Q2/R', 2016, 2024)
  const saipaSaina = await pm('ساینا', 'Saina', 2015, 2024)
  const saipaShahin = await pm('شاهین', 'سایپا', 2022, 2024)
  const tiba = await pm('تیبا', 'Tiba', 2007, 2018)
  const cheryE5 = await pm('چری', 'E5 (سایپا)', 2020, 2024)

  // مدیران خودرو
  const s200 = await pm('مدیران', 'S200', 2020, 2024)
  const s300 = await pm('مدیران', 'S300', 2022, 2024)
  const k132 = await pm('مدیران', 'K132', 2022, 2024)

  // پارس خودرو
  const aris = await pm('پارس خودرو', 'آریس', 2022, 2024)
  const maxi = await pm('پارس خودرو', 'ماکسی', 2022, 2024)

  // کرمان موتور
  const l90 = await pm('رنو', 'L90 (ساندرو)', 2016, 2024)
  const changan = await pm('چانگان', 'EADO', 2020, 2024)
  const mvm110 = await pm('ام‌وی‌ام', '۱۱۰', 2020, 2024)
  const mvm315 = await pm('ام‌وی‌ام', '۳۱۵', 2020, 2024)
  const mvm530 = await pm('ام‌وی‌ام', '۵۳۰', 2020, 2024)

  // بهمن موتور
  const mazda3 = await pm('مزدا', '۳', 2018, 2024)
  const haima5 = await pm('هایما', '۵', 2022, 2024)
  const haima7 = await pm('هایما', '۷', 2022, 2024)

  // وارداتی رایج
  const toyotaCorolla = await pm('تویوتا', 'کرولا', 2014, 2024)
  const toyotaYaris = await pm('تویوتا', 'یاریس', 2020, 2024)
  const hyundaiElantra = await pm('هیوندای', 'الانترا', 2016, 2024)
  const hyundaiTucson = await pm('هیوندای', 'توسان', 2018, 2024)
  const kiaSportage = await pm('کیا', 'اسپورتیج', 2016, 2024)
  const kiaCerato = await pm('کیا', 'سراتو', 2018, 2024)
  const benzC200 = await pm('مرسدس‌بنز', 'C200/C180', 2018, 2024)
  const bmw3 = await pm('بی‌ام‌و', 'سری ۳', 2018, 2024)

  const passengerModels = [peugeot206, peugeot207, peugeotPars, peugeot405, samand, samandSoren, dena, denaPlus, rana, tara, shahinIK, pride131, pride132, pride141, quick, saipaSaina, saipaShahin, tiba, cheryE5, s200, s300, k132, aris, maxi, l90, changan, mvm110, mvm315, mvm530, mazda3, haima5, haima7, toyotaCorolla, toyotaYaris, hyundaiElantra, hyundaiTucson, kiaSportage, kiaCerato, benzC200, bmw3]

  // ==========================================================================
  // CAR MODELS — HEAVY MACHINERY (trucks + construction + agriculture)
  // ==========================================================================
  console.log('  creating heavy machinery models...')
  async function hm(brand: string, model: string, yearFrom: number, yearTo: number) {
    const e = await db.carModel.findFirst({ where: { brand, model } });
    if (e) return e;
    return db.carModel.create({ data: { brand, model, yearFrom, yearTo, type: 'HEAVY' } })
  }

  // کامیون‌های سنگین
  const volvoFH16 = await hm('ولوو', 'FH16', 2015, 2024)
  const volvoFMX = await hm('ولوو', 'FMX', 2015, 2024)
  const scaniaR500 = await hm('اسکانیا', 'R500', 2015, 2024)
  const scaniaG440 = await hm('اسکانیا', 'G440', 2015, 2024)
  const manTGX = await hm('MAN', 'TGX', 2015, 2024)
  const actros = await hm('مرسدس‌بنز', 'آکتروس', 2015, 2024)
  const hyundaiHD = await hm('هیوندای', 'HD72/XD', 2015, 2024)
  const maz180 = await hm('ماز', '۱۸۰', 2015, 2024)
  const eksan = await hm('اکسان', 'ترکمن', 2015, 2024)
  const sameh = await hm('زامئیس', 'سایپا دیزل', 2015, 2024)
  const faraz = await hm('فرات', 'کامیون', 2015, 2024)
  const khavar126 = await hm('خاور', '۱۲۶', 2015, 2024)
  const zil130 = await hm('زیل', '۱۳۰', 2015, 2024)

  // ماشین‌آلات راه‌سازی
  const cat320 = await hm('کاترپیلر', '۳۲۰ (بیل هیدرولیک)', 2015, 2024)
  const cat966 = await hm('کاترپیلار', '۹۶۶ (لودر)', 2015, 2024)
  const catD6 = await hm('کاترپیلار', 'D6 (بولدوزر)', 2015, 2024)
  const komatsuPC200 = await hm('کوماتسو', 'PC200 (بیل)', 2015, 2024)
  const komatsuWA380 = await hm('کوماتسو', 'WA380 (لودر)', 2015, 2024)
  const volvoL120 = await hm('ولوو', 'L120 (لودر)', 2015, 2024)
  const liebherrL574 = await hm('لیبهر', 'L574 (لودر)', 2015, 2024)
  const hyundaiHL740 = await hm('هیوندای', 'HL740 (لودر)', 2015, 2024)
  const cat14M = await hm('کاترپیلار', '۱۴M (موتورگریدر)', 2015, 2024)
  const komatsuGD655 = await hm('کوماتسو', 'GD655 (گریدر)', 2015, 2024)

  // ماشین‌آلات کشاورزی
  const tractorMTZ = await hm('مرسدس', 'تراکتور', 2015, 2024)
  const combineClaas = await hm('کلاس', 'کمباین', 2015, 2024)
  const tractorJD = await hm('جان‌دیر', 'تراکتور ۵۰۵۵', 2015, 2024)

  const heavyModels = [volvoFH16, volvoFMX, scaniaR500, scaniaG440, manTGX, actros, hyundaiHD, maz180, eksan, sameh, faraz, khavar126, zil130, cat320, cat966, catD6, komatsuPC200, komatsuWA380, volvoL120, liebherrL574, hyundaiHL740, cat14M, komatsuGD655, tractorMTZ, combineClaas, tractorJD]

  // ==========================================================================
  // CATEGORIES — passenger + heavy
  // ==========================================================================
  console.log('  creating categories...')
  // سواری
  const engine = await db.category.upsert({ where: { slug: 'engine' }, update: {}, create: {  name: 'موتور و موتور', slug: 'engine'  } })
  const brakes = await db.category.upsert({ where: { slug: 'brakes' }, update: {}, create: {  name: 'ترمز', slug: 'brakes'  } })
  const suspension = await db.category.upsert({ where: { slug: 'suspension' }, update: {}, create: {  name: 'جلوبندی و تعلیق', slug: 'suspension'  } })
  const electrical = await db.category.upsert({ where: { slug: 'electrical' }, update: {}, create: {  name: 'برق و الکترونیک', slug: 'electrical'  } })
  const filters = await db.category.upsert({ where: { slug: 'filters' }, update: {}, create: {  name: 'فیلتر و مصرفی', slug: 'filters'  } })
  const oilFilter = await db.category.upsert({ where: { slug: 'oil-filter' }, update: {}, create: {  name: 'فیلتر روغن', slug: 'oil-filter', parentId: filters.id  } })
  const airFilter = await db.category.upsert({ where: { slug: 'air-filter' }, update: {}, create: {  name: 'فیلتر هوا', slug: 'air-filter', parentId: filters.id  } })
  const cabinFilter = await db.category.upsert({ where: { slug: 'cabin-filter' }, update: {}, create: {  name: 'فیلتر کابین', slug: 'cabin-filter', parentId: filters.id  } })
  const body = await db.category.upsert({ where: { slug: 'body' }, update: {}, create: {  name: 'بدنه و اکسسوری', slug: 'body'  } })
  const cooling = await db.category.upsert({ where: { slug: 'cooling' }, update: {}, create: {  name: 'سرمایش و گرمایش', slug: 'cooling'  } })
  const exhaust = await db.category.upsert({ where: { slug: 'exhaust' }, update: {}, create: {  name: 'اگزوز', slug: 'exhaust'  } })
  const transmission = await db.category.upsert({ where: { slug: 'transmission' }, update: {}, create: {  name: 'گیربکس و کلاچ', slug: 'transmission'  } })
  const steering = await db.category.upsert({ where: { slug: 'steering' }, update: {}, create: {  name: 'فرمان و پمپ هیدرولیک', slug: 'steering'  } })

  // ماشین‌آلات سنگین
  const heavyCat = await db.category.upsert({ where: { slug: 'heavy-machinery' }, update: {}, create: {  name: 'ماشین‌آلات سنگین', slug: 'heavy-machinery'  } })
  const heavyEngine = await db.category.upsert({ where: { slug: 'heavy-engine' }, update: {}, create: {  name: 'موتور دیزل سنگین', slug: 'heavy-engine', parentId: heavyCat.id  } })
  const heavyBrakes = await db.category.upsert({ where: { slug: 'heavy-brakes' }, update: {}, create: {  name: 'سیستم ترمز سنگین', slug: 'heavy-brakes', parentId: heavyCat.id  } })
  const heavyFilters = await db.category.upsert({ where: { slug: 'heavy-filters' }, update: {}, create: {  name: 'فیلتر و مصرفی سنگین', slug: 'heavy-filters', parentId: heavyCat.id  } })
  const heavySuspension = await db.category.upsert({ where: { slug: 'heavy-suspension' }, update: {}, create: {  name: 'تعلیق و محور سنگین', slug: 'heavy-suspension', parentId: heavyCat.id  } })
  const heavyHydraulic = await db.category.upsert({ where: { slug: 'heavy-hydraulic' }, update: {}, create: {  name: 'سیستم هیدرولیک', slug: 'heavy-hydraulic', parentId: heavyCat.id  } })
  const heavyTransmission = await db.category.upsert({ where: { slug: 'heavy-transmission' }, update: {}, create: {  name: 'گیربکس و کلاچ سنگین', slug: 'heavy-transmission', parentId: heavyCat.id  } })
  const heavyElectrical = await db.category.upsert({ where: { slug: 'heavy-electrical' }, update: {}, create: {  name: 'برق و استارت سنگین', slug: 'heavy-electrical', parentId: heavyCat.id  } })
  const heavyCooling = await db.category.upsert({ where: { slug: 'heavy-cooling' }, update: {}, create: {  name: 'رادیاتور و سرمایش سنگین', slug: 'heavy-cooling', parentId: heavyCat.id  } })

  // ==========================================================================
  // BRANDS
  // ==========================================================================
  console.log('  creating brands...')
  const mkBrand = async (name: string, slug: string, country: string) => db.brand.upsert({ where: { slug }, update: {}, create: { name, slug, country } })
  const bosch = await mkBrand('Bosch', 'bosch', 'Germany')
  const denso = await mkBrand('Denso', 'denso', 'Japan')
  const valeo = await mkBrand('Valeo', 'valeo', 'France')
  const mahle = await mkBrand('Mahle', 'mahle', 'Germany')
  const sachs = await mkBrand('Sachs', 'sachs', 'Germany')
  const ngk = await mkBrand('NGK', 'ngk', 'Japan')
  const mann = await mkBrand('Mann-Filter', 'mann-filter', 'Germany')
  const gates = await mkBrand('Gates', 'gates', 'USA')
  const continental = await mkBrand('Continental', 'continental', 'Germany')
  const brembo = await mkBrand('Brembo', 'brembo', 'Italy')
  const hengst = await mkBrand('Hengst', 'hengst', 'Germany')
  const febri = await mkBrand('Febi Bilstein', 'febi-bilstein', 'Germany')
  const lemforder = await mkBrand('Lemförder', 'lemforder', 'Germany')
  const ina = await mkBrand('INA', 'ina', 'Germany')
  const skf = await mkBrand('SKF', 'skf', 'Sweden')
  const ntn = await mkBrand('NTN', 'ntn', 'Japan')
  const donaldson = await mkBrand('Donaldson', 'donaldson', 'USA')
  const fleetguard = await mkBrand('Fleetguard', 'fleetguard', 'USA')
  const wix = await mkBrand('Wix', 'wix', 'USA')
  const cat = await mkBrand('Caterpillar', 'caterpillar', 'USA')
  const komatsu = await mkBrand('Komatsu', 'komatsu-brand', 'Japan')
  const volvoParts = await mkBrand('Volvo Parts', 'volvo-parts', 'Sweden')
  const elring = await mkBrand('ElringKlinger', 'elring', 'Germany')
  const shellBrand = await mkBrand('Shell', 'shell', 'Netherlands')
  const wabco = await mkBrand('WABCO', 'wabco', 'Germany')

  // ==========================================================================
  // PARTS — comprehensive catalog (passenger + heavy)
  // ==========================================================================
  console.log('  creating parts catalog (passenger + heavy)...')
  const allPassenger = { connect: passengerModels.map((m) => ({ id: m.id })) }
  const allHeavy = { connect: heavyModels.map((m) => ({ id: m.id })) }
  const genericPassenger = { connect: [peugeot206, peugeotPars, peugeot405, samand, pride131, pride141, dena, rana, toyotaCorolla, hyundaiElantra].map((m) => ({ id: m.id })) }

  type PartSeed = {
    name: string; nameFa?: string; sku: string; categoryId: string; brandId: string
    priceUsd: number; oldPriceUsd?: number; stock: number; lowStockThreshold?: number
    description?: string; featured?: boolean; carModels?: any
  }

  const parts: PartSeed[] = [
    // --- موتور سواری ---
    { name: 'Spark Plug Iridium', nameFa: 'شمع احتراق ایریدیوم NGK', sku: 'SP-IR-001', categoryId: engine.id, brandId: ngk.id, priceUsd: 8.5, stock: 320, lowStockThreshold: 50, description: 'شمع احتراق ایریدیوم با عمر بالا، مناسب موتورهای انژکتوری.', featured: true, carModels: genericPassenger },
    { name: 'Spark Plug Standard', nameFa: 'شمع احتراق استاندارد', sku: 'SP-ST-002', categoryId: engine.id, brandId: ngk.id, priceUsd: 3.2, stock: 500, lowStockThreshold: 80, description: 'شمع استاندارد نیکل.', carModels: genericPassenger },
    { name: 'Ignition Coil', nameFa: 'کویل احتراق (بوبین)', sku: 'IC-003', categoryId: engine.id, brandId: bosch.id, priceUsd: 38, stock: 45, lowStockThreshold: 10, description: 'کویل احتراق اصلی، مطمئن و بادوام.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: dena.id }, { id: toyotaCorolla.id }, { id: hyundaiElantra.id } ] } },
    { name: 'Timing Belt Kit', nameFa: 'کیت تسمه تایمینگ', sku: 'TBK-004', categoryId: engine.id, brandId: gates.id, priceUsd: 95, oldPriceUsd: 110, stock: 18, lowStockThreshold: 5, description: 'کیت تسمه تایمینگ شامل تسمه + تنده + بلبرینگ.', featured: true, carModels: { connect: [ { id: peugeot405.id }, { id: peugeotPars.id }, { id: samand.id } ] } },
    { name: 'Timing Chain Kit', nameFa: 'کیت زنجیر تایمینگ', sku: 'TCK-005', categoryId: engine.id, brandId: febri.id, priceUsd: 145, stock: 12, lowStockThreshold: 4, description: 'کیت کامل زنجیر تایمینگ.', carModels: { connect: [ { id: peugeot206.id }, { id: dena.id }, { id: toyotaCorolla.id } ] } },
    { name: 'Cylinder Head Gasket', nameFa: 'واشر سرسیلندر', sku: 'HG-006', categoryId: engine.id, brandId: elring.id, stock: 8, lowStockThreshold: 3, priceUsd: 65, description: 'واشر سرسیلندر اصلی.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id }, { id: pride131.id } ] } } as any,
    { name: 'Valve Cover Gasket', nameFa: 'واشر درب سوپاپ', sku: 'VCG-007', categoryId: engine.id, brandId: elring.id, priceUsd: 12, stock: 60, lowStockThreshold: 15, description: 'واشر درب سوپاپ.', carModels: genericPassenger },
    { name: 'Water Pump', nameFa: 'پمپ آب', sku: 'WP-008', categoryId: engine.id, brandId: bosch.id, priceUsd: 42, stock: 30, lowStockThreshold: 8, description: 'پمپ آب موتور.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: samand.id }, { id: toyotaCorolla.id } ] } },
    { name: 'Oil Pump', nameFa: 'پمپ روغن', sku: 'OP-009', categoryId: engine.id, brandId: febri.id, priceUsd: 85, stock: 14, lowStockThreshold: 4, description: 'پمپ روغن موتور.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id } ] } },
    { name: 'Engine Mount', nameFa: 'بوش موتور', sku: 'EM-010', categoryId: engine.id, brandId: lemforder.id, priceUsd: 22, stock: 40, lowStockThreshold: 10, description: 'بوش موتور (چپ/راست).', carModels: genericPassenger },
    { name: 'Thermostat', nameFa: 'ترموستات', sku: 'TH-011', categoryId: engine.id, brandId: mahle.id, priceUsd: 9, stock: 80, lowStockThreshold: 20, description: 'ترموستات ۸۸ درجه.', carModels: genericPassenger },

    // --- ترمز سواری ---
    { name: 'Brake Pad Set Front', nameFa: 'لنت ترمز جلو', sku: 'BP-F-012', categoryId: brakes.id, brandId: bosch.id, priceUsd: 32, oldPriceUsd: 38, stock: 90, lowStockThreshold: 20, description: 'لنت ترمز جلو، نسل جدید.', featured: true, carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: samand.id }, { id: hyundaiElantra.id } ] } },
    { name: 'Brake Pad Set Rear', nameFa: 'لنت ترمز عقب', sku: 'BP-R-013', categoryId: brakes.id, brandId: bosch.id, priceUsd: 28, stock: 70, lowStockThreshold: 15, description: 'لنت ترمز عقب.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: hyundaiElantra.id } ] } },
    { name: 'Brake Disc Front', nameFa: 'دیسک ترمز جلو', sku: 'BD-F-014', categoryId: brakes.id, brandId: valeo.id, priceUsd: 45, stock: 8, lowStockThreshold: 12, description: 'دیسک ترمز جلو، تهویه‌شده.', carModels: { connect: [ { id: peugeot206.id }, { id: hyundaiElantra.id } ] } },
    { name: 'Brake Caliper', nameFa: 'کیسه ترمز (کالیپر)', sku: 'BC-015', categoryId: brakes.id, brandId: brembo.id, priceUsd: 78, stock: 20, lowStockThreshold: 6, description: 'کالیپر ترمز جلو کامل.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id } ] } },
    { name: 'Brake Fluid DOT4', nameFa: 'روغن ترمز DOT4', sku: 'BF-016', categoryId: brakes.id, brandId: bosch.id, priceUsd: 5.5, stock: 180, lowStockThreshold: 30, description: 'روغن ترمز DOT4، ۵۰۰ سی‌سی.', carModels: allPassenger },
    { name: 'Brake Master Cylinder', nameFa: 'سم ترمز (مستر سیلندر)', sku: 'BMC-017', categoryId: brakes.id, brandId: febri.id, priceUsd: 55, stock: 16, lowStockThreshold: 5, description: 'مستر سیلندر ترمز.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id }, { id: pride131.id } ] } },
    { name: 'Brake Hose', nameFa: 'شلنگ ترمز', sku: 'BH-018', categoryId: brakes.id, brandId: continental.id, priceUsd: 7, stock: 120, lowStockThreshold: 25, description: 'شلنگ ترمز فولادی.', carModels: genericPassenger },

    // --- تعلیق سواری ---
    { name: 'Shock Absorber Rear', nameFa: 'کمک فنر عقب', sku: 'SA-R-019', categoryId: suspension.id, brandId: sachs.id, priceUsd: 58, stock: 35, lowStockThreshold: 8, description: 'کمک فنر گازی عقب.', featured: true, carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: kiaSportage.id } ] } },
    { name: 'Shock Absorber Front', nameFa: 'کمک فنر جلو', sku: 'SA-F-020', categoryId: suspension.id, brandId: sachs.id, priceUsd: 62, stock: 32, lowStockThreshold: 8, description: 'کمک فنر گازی جلو.', carModels: { connect: [ { id: peugeot206.id }, { id: hyundaiElantra.id } ] } },
    { name: 'Coil Spring', nameFa: 'فنر لول', sku: 'CS-021', categoryId: suspension.id, brandId: lemforder.id, priceUsd: 48, stock: 24, lowStockThreshold: 6, description: 'فنر لول جلو.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id } ] } },
    { name: 'Control Arm', nameFa: 'بوش بازویی (میل‌موجب)', sku: 'CA-022', categoryId: suspension.id, brandId: lemforder.id, priceUsd: 35, stock: 40, lowStockThreshold: 10, description: 'بازوی کنترل کامل.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: hyundaiElantra.id } ] } },
    { name: 'Stabilizer Link', nameFa: 'لنگ سویی هوا', sku: 'SL-023', categoryId: suspension.id, brandId: febri.id, priceUsd: 14, stock: 80, lowStockThreshold: 20, description: 'لینک تثبیت‌کننده.', carModels: genericPassenger },
    { name: 'Ball Joint', nameFa: 'تسمه بازویی', sku: 'BJ-024', categoryId: suspension.id, brandId: lemforder.id, priceUsd: 18, stock: 60, lowStockThreshold: 15, description: 'جویلورد بالایی/پایینی.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id }, { id: pride131.id } ] } },
    { name: 'Wheel Bearing', nameFa: 'بلبرینگ چرخ', sku: 'WB-025', categoryId: suspension.id, brandId: skf.id, priceUsd: 28, stock: 50, lowStockThreshold: 12, description: 'بلبرینگ چرخ کامل.', carModels: { connect: [ { id: peugeot206.id }, { id: pride131.id }, { id: toyotaCorolla.id } ] } },

    // --- برق و الکترونیک ---
    { name: 'Alternator 120A', nameFa: 'دینام ۱۲۰ آمپر', sku: 'ALT-026', categoryId: electrical.id, brandId: bosch.id, priceUsd: 145, stock: 5, lowStockThreshold: 3, description: 'دینام ۱۲۰ آمپر بازسازی‌شده.', carModels: { connect: [ { id: peugeot206.id }, { id: dena.id }, { id: toyotaCorolla.id } ] } },
    { name: 'Starter Motor', nameFa: 'استارت', sku: 'STM-027', categoryId: electrical.id, brandId: bosch.id, priceUsd: 125, stock: 8, lowStockThreshold: 3, description: 'استارت موتور.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id }, { id: pride131.id } ] } },
    { name: 'Battery 60Ah', nameFa: 'باتری ۶۰ آمپر', sku: 'BAT-028', categoryId: electrical.id, brandId: bosch.id, priceUsd: 85, oldPriceUsd: 95, stock: 25, lowStockThreshold: 8, description: 'باتری ۱۲ ولت ۶۰ آمپر.', featured: true, carModels: allPassenger },
    { name: 'Headlight Assembly', nameFa: 'چراغ جلو کامل', sku: 'HL-029', categoryId: electrical.id, brandId: valeo.id, priceUsd: 95, stock: 15, lowStockThreshold: 5, description: 'چراغ جلو اسمبلی.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: pride131.id } ] } },
    { name: 'Tail Light', nameFa: 'چراغ عقب', sku: 'TL-030', categoryId: electrical.id, brandId: valeo.id, priceUsd: 38, stock: 20, lowStockThreshold: 6, description: 'چراغ عقب کامل.', carModels: { connect: [ { id: peugeot206.id }, { id: pride131.id } ] } },
    { name: 'Oxygen Sensor O2', nameFa: 'سنسور اکسیژن', sku: 'O2S-031', categoryId: electrical.id, brandId: denso.id, priceUsd: 65, stock: 18, lowStockThreshold: 5, description: 'سنسور اکسیژن (لامبدا).', carModels: { connect: [ { id: peugeot206.id }, { id: dena.id }, { id: toyotaCorolla.id } ] } },
    { name: 'Blower Motor', nameFa: 'موتور فن کابین', sku: 'BM-032', categoryId: electrical.id, brandId: valeo.id, priceUsd: 48, stock: 22, lowStockThreshold: 6, description: 'موتور دمنده کابین.', carModels: genericPassenger },

    // --- فیلتر و مصرفی ---
    { name: 'Oil Filter', nameFa: 'فیلتر روغن', sku: 'OF-033', categoryId: oilFilter.id, brandId: mann.id, priceUsd: 4.2, stock: 500, lowStockThreshold: 100, description: 'فیلتر روغن اصلی.', carModels: allPassenger },
    { name: 'Air Filter', nameFa: 'فیلتر هوا', sku: 'AF-034', categoryId: airFilter.id, brandId: mann.id, priceUsd: 6.8, stock: 350, lowStockThreshold: 60, description: 'فیلتر هوا با ظرفیت ذرات بالا.', carModels: allPassenger },
    { name: 'Cabin Filter', nameFa: 'فیلتر کابین کربن‌فعال', sku: 'CF-035', categoryId: cabinFilter.id, brandId: denso.id, priceUsd: 7.5, stock: 280, lowStockThreshold: 50, description: 'فیلتر کابین با کربن فعال.', carModels: allPassenger },
    { name: 'Fuel Filter', nameFa: 'فیلتر بنزین', sku: 'FF-036', categoryId: filters.id, brandId: mahle.id, priceUsd: 9, stock: 180, lowStockThreshold: 30, description: 'فیلتر سوخت.', carModels: genericPassenger },
    { name: 'Engine Oil 5W-30 Synthetic', nameFa: 'روغن موتور ۵W-30 تمام سنتتیک ۴L', sku: 'EO-037', categoryId: filters.id, brandId: bosch.id, priceUsd: 28, oldPriceUsd: 32, stock: 120, lowStockThreshold: 20, description: 'روغن موتور تمام سنتتیک، ۴ لیتر.', featured: true, carModels: genericPassenger },
    { name: 'Engine Oil 10W-40', nameFa: 'روغن موتور ۱۰W-40 نیمه سنتتیک ۴L', sku: 'EO-038', categoryId: filters.id, brandId: bosch.id, priceUsd: 18, stock: 150, lowStockThreshold: 30, description: 'روغن موتور نیمه سنتتیک.', carModels: genericPassenger },
    { name: 'Coolant 2L', nameFa: 'ضد یخ ۲ لیتر', sku: 'CL-039', categoryId: filters.id, brandId: bosch.id, priceUsd: 7, stock: 90, lowStockThreshold: 20, description: 'سیال خنک‌کننده.', carModels: allPassenger },
    { name: 'Wiper Blade Set', nameFa: 'تیغه برف پاک‌کن (جلو)', sku: 'WB-040', categoryId: filters.id, brandId: bosch.id, priceUsd: 12, stock: 200, lowStockThreshold: 40, description: 'ست تیغه برف پاک‌کن.', carModels: allPassenger },

    // --- بدنه و اکسسوری ---
    { name: 'Side Mirror', nameFa: 'آینه بغل برقی', sku: 'SM-041', categoryId: body.id, brandId: valeo.id, priceUsd: 35, stock: 30, lowStockThreshold: 8, description: 'آینه بغل برقی، چپ/راست.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id } ] } },
    { name: 'Bumper Front', nameFa: 'سپر جلو', sku: 'BF-042', categoryId: body.id, brandId: febri.id, priceUsd: 65, stock: 12, lowStockThreshold: 4, description: 'سپر جلو اصلی.', carModels: { connect: [ { id: peugeot206.id }, { id: pride131.id } ] } },
    { name: 'Door Handle', nameFa: 'دستگیره در', sku: 'DH-043', categoryId: body.id, brandId: febri.id, priceUsd: 8, stock: 80, lowStockThreshold: 20, description: 'دستگیره در.', carModels: { connect: [ { id: peugeot405.id }, { id: pride131.id } ] } },

    // --- سرمایش ---
    { name: 'Radiator', nameFa: 'رادیاتور', sku: 'RD-044', categoryId: cooling.id, brandId: valeo.id, priceUsd: 78, stock: 18, lowStockThreshold: 5, description: 'رادیاتور آلومینیومی.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id }, { id: peugeot206.id } ] } },
    { name: 'Radiator Fan', nameFa: 'فن رادیاتور', sku: 'RF-045', categoryId: cooling.id, brandId: valeo.id, priceUsd: 42, stock: 22, lowStockThreshold: 6, description: 'موتور فن رادیاتور.', carModels: genericPassenger },
    { name: 'Coolant Hose', nameFa: 'شلنگ رادیاتور', sku: 'CH-046', categoryId: cooling.id, brandId: continental.id, priceUsd: 9, stock: 100, lowStockThreshold: 20, description: 'شلنگ آب رادیاتور.', carModels: genericPassenger },

    // --- اگزوز ---
    { name: 'Exhaust Muffler', nameFa: 'صدا خفه‌کن اگزوز', sku: 'EM-047', categoryId: exhaust.id, brandId: bosch.id, priceUsd: 55, stock: 15, lowStockThreshold: 5, description: 'انژکتور اگزوز.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id }, { id: pride131.id } ] } },
    { name: 'Catalytic Converter', nameFa: 'کاتالیست اگزوز', sku: 'CC-048', categoryId: exhaust.id, brandId: bosch.id, priceUsd: 95, stock: 8, lowStockThreshold: 3, description: 'مبدل کاتالیتیک.', carModels: { connect: [ { id: peugeot206.id }, { id: dena.id }, { id: toyotaCorolla.id } ] } },

    // --- گیربکس و کلاچ ---
    { name: 'Clutch Kit', nameFa: 'کیت کلاچ کامل', sku: 'CK-049', categoryId: transmission.id, brandId: sachs.id, priceUsd: 220, stock: 12, lowStockThreshold: 4, description: 'کیت کلاچ (دیسک + پلاتو + لایی).', featured: true, carModels: { connect: [ { id: peugeot206.id }, { id: peugeot405.id }, { id: samand.id }, { id: pride131.id } ] } },
    { name: 'Clutch Slave Cylinder', nameFa: 'کاسه‌گیر کلاچ', sku: 'CSC-050', categoryId: transmission.id, brandId: febri.id, priceUsd: 22, stock: 30, lowStockThreshold: 8, description: 'کاسه‌گیر هیدرولیکی کلاچ.', carModels: { connect: [ { id: peugeot405.id }, { id: samand.id } ] } },
    { name: 'CV Joint', nameFa: 'خار چرخ', sku: 'CVJ-051', categoryId: transmission.id, brandId: febri.id, priceUsd: 38, stock: 40, lowStockThreshold: 10, description: 'خار چرخ داخلی/خارجی.', carModels: { connect: [ { id: peugeot206.id }, { id: pride131.id }, { id: hyundaiElantra.id } ] } },
    { name: 'Gear Oil 75W-90', nameFa: 'روغن گیربکس 75W-90 1L', sku: 'GO-052', categoryId: transmission.id, brandId: bosch.id, priceUsd: 8, stock: 200, lowStockThreshold: 40, description: 'روغن گیربکس دستی.', carModels: allPassenger },

    // --- فرمان و پمپ هیدرولیک ---
    { name: 'Power Steering Pump', nameFa: 'پمپ هیدرولیک فرمان', sku: 'PSP-053', categoryId: steering.id, brandId: bosch.id, priceUsd: 88, stock: 16, lowStockThreshold: 5, description: 'پمپ فرمان هیدرولیک.', carModels: { connect: [ { id: peugeot405.id }, { id: peugeotPars.id }, { id: samand.id } ] } },
    { name: 'Steering Rack', nameFa: 'راک فرمان', sku: 'SR-054', categoryId: steering.id, brandId: febri.id, priceUsd: 180, stock: 8, lowStockThreshold: 3, description: 'راک فرمان هیدرولیکی.', carModels: { connect: [ { id: peugeot206.id }, { id: peugeotPars.id }, { id: samand.id } ] } },
    { name: 'Tie Rod End', nameFa: 'سر سیبک', sku: 'TRE-055', categoryId: steering.id, brandId: lemforder.id, priceUsd: 12, stock: 90, lowStockThreshold: 20, description: 'سر سیبک بالا/پایین.', carModels: genericPassenger },

    // ===================== ماشین‌آلات سنگین =====================
    // --- موتور دیزل سنگین ---
    { name: 'Diesel Oil Filter Heavy', nameFa: 'فیلتر روغن موتور دیزل سنگین', sku: 'HOF-101', categoryId: heavyFilters.id, brandId: fleetguard.id, priceUsd: 28, stock: 80, lowStockThreshold: 15, description: 'فیلتر روغن موتور دیزل، مناسب کامیون‌های سنگین.', carModels: allHeavy },
    { name: 'Air Filter Heavy', nameFa: 'فیلتر هوا موتور سنگین', sku: 'HAF-102', categoryId: heavyFilters.id, brandId: donaldson.id, priceUsd: 45, stock: 50, lowStockThreshold: 10, description: 'فیلتر هوا موتور دیزل سنگین.', carModels: allHeavy },
    { name: 'Fuel Filter Diesel', nameFa: 'فیلتر گازوییل', sku: 'HFF-103', categoryId: heavyFilters.id, brandId: fleetguard.id, priceUsd: 32, stock: 60, lowStockThreshold: 12, description: 'فیلتر سوخت دیزل با آب‌گیر.', carModels: allHeavy },
    { name: 'Hydraulic Filter', nameFa: 'فیلتر هیدرولیک', sku: 'HF-104', categoryId: heavyFilters.id, brandId: donaldson.id, priceUsd: 38, stock: 40, lowStockThreshold: 8, description: 'فیلتر روغن هیدرولیک.', carModels: { connect: [ { id: cat320.id }, { id: cat966.id }, { id: komatsuPC200.id }, { id: volvoL120.id } ] } },
    { name: 'Diesel Engine Oil 15W-40', nameFa: 'روغن موتور دیزل 15W-40 (20L)', sku: 'DEO-105', categoryId: heavyFilters.id, brandId: shellBrand.id, stock: 30, lowStockThreshold: 8, priceUsd: 120, description: 'روغن موتور دیزل، گالن ۲۰ لیتر.', carModels: allHeavy } as any,
    { name: 'Coolant Heavy 10L', nameFa: 'ضد یخ سنگین ۱۰ لیتر', sku: 'HCL-106', categoryId: heavyFilters.id, brandId: fleetguard.id, priceUsd: 35, stock: 25, lowStockThreshold: 6, description: 'سیال خنک‌کننده موتور دیزل.', carModels: allHeavy },
    { name: 'Turbocharger', nameFa: 'توربوشارژر', sku: 'TC-107', categoryId: heavyEngine.id, brandId: bosch.id, priceUsd: 850, oldPriceUsd: 950, stock: 6, lowStockThreshold: 2, description: 'توربوشارژر موتور دیزل سنگین.', featured: true, carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: manTGX.id }, { id: actros.id } ] } },
    { name: 'Injector Diesel', nameFa: 'انژکتور دیزل', sku: 'DI-108', categoryId: heavyEngine.id, brandId: bosch.id, priceUsd: 280, stock: 20, lowStockThreshold: 5, description: 'انژکتور سوخت دیزل.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: manTGX.id } ] } },
    { name: 'Fuel Pump Diesel', nameFa: 'پمپ پاشش دیزل', sku: 'FP-109', categoryId: heavyEngine.id, brandId: bosch.id, priceUsd: 650, stock: 8, lowStockThreshold: 3, description: 'پمپ پاشش سوخت دیزل.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id } ] } },
    { name: 'Cylinder Liner Kit', nameFa: 'کیت آستر سیلندر', sku: 'CLK-110', categoryId: heavyEngine.id, brandId: mahle.id, priceUsd: 480, stock: 10, lowStockThreshold: 3, description: 'کیت آستر سیلندر موتور دیزل.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: manTGX.id } ] } },
    { name: 'Piston Ring Set Heavy', nameFa: 'کیت رینگ پیستون سنگین', sku: 'PRS-111', categoryId: heavyEngine.id, brandId: mahle.id, priceUsd: 220, stock: 15, lowStockThreshold: 4, description: 'ست رینگ پیستون موتور دیزل.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: maz180.id } ] } },
    { name: 'Engine Valve Heavy', nameFa: 'سوپاپ موتور دیزل', sku: 'EV-112', categoryId: heavyEngine.id, brandId: mahle.id, priceUsd: 45, stock: 80, lowStockThreshold: 20, description: 'سوپاپ ورودی/خروجی موتور دیزل.', carModels: allHeavy },
    { name: 'Starter Motor Heavy', nameFa: 'استارت سنگین ۲۴V', sku: 'STH-113', categoryId: heavyElectrical.id, brandId: bosch.id, priceUsd: 380, stock: 12, lowStockThreshold: 4, description: 'استارت ۲۴ ولت موتور دیزل.', carModels: allHeavy },
    { name: 'Alternator Heavy 24V', nameFa: 'دینام ۲۴ ولت ۱۵۰A', sku: 'ALTH-114', categoryId: heavyElectrical.id, brandId: bosch.id, priceUsd: 420, stock: 10, lowStockThreshold: 3, description: 'دینام ۲۴ ولت سنگین.', carModels: allHeavy },
    { name: 'Battery Heavy 200Ah', nameFa: 'باتری ۲۰۰ آمپر ۱۲V', sku: 'BTH-115', categoryId: heavyElectrical.id, brandId: bosch.id, priceUsd: 220, stock: 18, lowStockThreshold: 5, description: 'باتری صنعتی ۲۰۰Ah.', carModels: allHeavy },

    // --- ترمز سنگین ---
    { name: 'Brake Pad Heavy', nameFa: 'لنت ترمز کامیون', sku: 'BPH-116', categoryId: heavyBrakes.id, brandId: bosch.id, priceUsd: 85, stock: 25, lowStockThreshold: 6, description: 'لنت ترمز کامیون سنگین.', carModels: allHeavy },
    { name: 'Brake Drum Heavy', nameFa: 'کاسه ترمز کامیون', sku: 'BDH-117', categoryId: heavyBrakes.id, brandId: febri.id, priceUsd: 180, stock: 12, lowStockThreshold: 4, description: 'کاسه ترمز سنگین.', carModels: allHeavy },
    { name: 'Brake Chamber', nameFa: 'باد ترمز کامیون', sku: 'BC-118', categoryId: heavyBrakes.id, brandId: wabco.id, stock: 20, lowStockThreshold: 5, priceUsd: 95, description: 'بوستر ترمز بادی (کامواگن).', carModels: allHeavy } as any,
    { name: 'Air Compressor', nameFa: 'کمپرسور باد', sku: 'AC-119', categoryId: heavyBrakes.id, brandId: wabco.id, stock: 8, lowStockThreshold: 3, priceUsd: 350, description: 'پمپ باد ترمز بادی.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: manTGX.id }, { id: khavar126.id } ] } } as any,

    // --- تعلیق سنگین ---
    { name: 'Leaf Spring Heavy', nameFa: 'فنر لول کامیون', sku: 'LSH-120', categoryId: heavySuspension.id, brandId: lemforder.id, priceUsd: 280, stock: 10, lowStockThreshold: 3, description: 'ست فنر لول کامیون.', carModels: { connect: [ { id: khavar126.id }, { id: maz180.id }, { id: zil130.id } ] } },
    { name: 'Heavy Shock Absorber', nameFa: 'کمک فنر کامیون', sku: 'HSA-121', categoryId: heavySuspension.id, brandId: sachs.id, priceUsd: 120, stock: 18, lowStockThreshold: 5, description: 'کمک فنر سنگین.', carModels: allHeavy },
    { name: 'Wheel Bearing Heavy', nameFa: 'بلبرینگ چرخ کامیون', sku: 'WBH-122', categoryId: heavySuspension.id, brandId: skf.id, priceUsd: 145, stock: 22, lowStockThreshold: 5, description: 'بلبرینگ چرخ سنگین.', carModels: allHeavy },
    { name: 'Axle Shaft Heavy', nameFa: 'محور چرخ کامیون', sku: 'ASH-123', categoryId: heavySuspension.id, brandId: febri.id, priceUsd: 380, stock: 8, lowStockThreshold: 3, description: 'محور چرخ سنگین.', carModels: { connect: [ { id: khavar126.id }, { id: maz180.id } ] } },

    // --- هیدرولیک ماشین‌آلات ---
    { name: 'Hydraulic Pump', nameFa: 'پمپ هیدرولیک', sku: 'HP-124', categoryId: heavyHydraulic.id, brandId: bosch.id, priceUsd: 950, oldPriceUsd: 1100, stock: 6, lowStockThreshold: 2, description: 'پمپ هیدرولیک ماشین‌آلات راه‌سازی.', featured: true, carModels: { connect: [ { id: cat320.id }, { id: cat966.id }, { id: komatsuPC200.id }, { id: volvoL120.id } ] } },
    { name: 'Hydraulic Cylinder', nameFa: 'جک هیدرولیک', sku: 'HC-125', categoryId: heavyHydraulic.id, brandId: cat.id, priceUsd: 1200, stock: 4, lowStockThreshold: 2, description: 'جک هیدرولیک اصلی.', carModels: { connect: [ { id: cat320.id }, { id: cat966.id }, { id: komatsuPC200.id } ] } },
    { name: 'Hydraulic Hose', nameFa: 'شلنگ هیدرولیک', sku: 'HH-126', categoryId: heavyHydraulic.id, brandId: continental.id, priceUsd: 25, stock: 80, lowStockThreshold: 15, description: 'شلنگ هیدرولیک فشار بالا.', carModels: { connect: [ { id: cat320.id }, { id: cat966.id }, { id: catD6.id }, { id: komatsuPC200.id } ] } },
    { name: 'Hydraulic Seal Kit', nameFa: 'کیت اورینگ جک', sku: 'HSK-127', categoryId: heavyHydraulic.id, brandId: cat.id, priceUsd: 85, stock: 30, lowStockThreshold: 8, description: 'کیت واشر و اورینگ جک.', carModels: { connect: [ { id: cat320.id }, { id: cat966.id }, { id: komatsuPC200.id } ] } },
    { name: 'Control Valve', nameFa: 'شیر کنترل هیدرولیک', sku: 'CV-128', categoryId: heavyHydraulic.id, brandId: bosch.id, priceUsd: 680, stock: 8, lowStockThreshold: 3, description: 'شیر فرمان هیدرولیک.', carModels: { connect: [ { id: cat966.id }, { id: catD6.id }, { id: komatsuWA380.id } ] } },

    // --- گیربکس سنگین ---
    { name: 'Clutch Heavy', nameFa: 'کلاچ کامیون', sku: 'CH-129', categoryId: heavyTransmission.id, brandId: sachs.id, priceUsd: 380, stock: 10, lowStockThreshold: 3, description: 'کیت کلاچ سنگین.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: manTGX.id }, { id: khavar126.id } ] } },
    { name: 'Gearbox Bearing', nameFa: 'بلبرینگ گیربکس سنگین', sku: 'GB-130', categoryId: heavyTransmission.id, brandId: skf.id, priceUsd: 65, stock: 40, lowStockThreshold: 10, description: 'بلبرینگ گیربکس سنگین.', carModels: allHeavy },
    { name: 'Transmission Oil 80W-90', nameFa: 'روغن گیربکس سنگین 80W-90 (20L)', sku: 'TOH-131', categoryId: heavyTransmission.id, brandId: shellBrand.id, stock: 25, lowStockThreshold: 6, priceUsd: 95, description: 'روغن گیربکس سنگین، گالن ۲۰ لیتر.', carModels: allHeavy } as any,

    // --- رادیاتور سنگین ---
    { name: 'Radiator Heavy', nameFa: 'رادیاتور کامیون', sku: 'RH-132', categoryId: heavyCooling.id, brandId: valeo.id, priceUsd: 450, stock: 8, lowStockThreshold: 3, description: 'رادیاتور موتور دیزل سنگین.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: manTGX.id }, { id: khavar126.id } ] } },
    { name: 'Intercooler', nameFa: 'اینترکولر', sku: 'IC-133', categoryId: heavyCooling.id, brandId: valeo.id, priceUsd: 320, stock: 10, lowStockThreshold: 3, description: 'اینترکولر موتور توربوی دیزل.', carModels: { connect: [ { id: volvoFH16.id }, { id: scaniaR500.id }, { id: manTGX.id } ] } },
    { name: 'Fan Clutch Heavy', nameFa: 'کلاچ فن سنگین', sku: 'FCH-134', categoryId: heavyCooling.id, brandId: valeo.id, priceUsd: 180, stock: 12, lowStockThreshold: 4, description: 'کلاچ فن رادیاتور سنگین.', carModels: allHeavy },
  ]

  // Fix invalid brandId references (replaced with valid ones)
  const brandByName: Record<string, any> = { bosch, denso, valeo, mahle, sachs, ngk, mann, gates, continental, brembo, hengst, febri, lemforder, ina, skf, ntn, donaldson, fleetguard, wix, cat, komatsu, volvoParts }
  const validBrandIds = new Set(Object.values(brandByName).map((b: any) => b.id))
  for (const p of parts) {
    if (!validBrandIds.has(p.brandId)) {
      p.brandId = bosch.id // fallback
    }
  }

  for (const p of parts) {
    await db.part.upsert({ where: { sku: p.sku }, update: {}, create: p as any }).catch((e: any) => {
      console.error(`FAILED on part sku=${p.sku} nameFa=${p.nameFa}:`, e.code, e.message?.slice(0, 150))
      if (e.meta) console.error('  meta:', JSON.stringify(e.meta).slice(0, 200))
      throw e
    })
  }

  // ---- Coupons ----
  await db.coupon.upsert({ where: { code: 'WELCOME10' }, update: {}, create: { code: 'WELCOME10', type: 'PERCENT', value: 10, expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), usageLimit: 100, active: true, minOrderIrr: 1000000 } })
  await db.coupon.upsert({ where: { code: 'CARFIX50' }, update: {}, create: { code: 'CARFIX50', type: 'FIXED', value: 50000, usageLimit: 0, active: true, minOrderIrr: 200000 } })
  await db.coupon.upsert({ where: { code: 'HEAVY20' }, update: {}, create: { code: 'HEAVY20', type: 'PERCENT', value: 20, expiresAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), usageLimit: 50, active: true, minOrderIrr: 5000000 } as any })

  // ---- Sample customers & mechanics ----
  const cust1 = await db.customer.upsert({ where: { phone: '09120000001' }, update: {}, create: { phone: '09120000001', name: 'علی', family: 'محمدی', nationalCode: '0012345678', address: 'تهران، خیابان ولیعصر' } })
  await db.customer.upsert({ where: { phone: '09120000002' }, update: {}, create: { phone: '09120000002', name: 'مریم', family: 'رضایی', address: 'اصفهان، چهارباغ' } })
  await db.mechanic.upsert({ where: { phone: '09120000003' }, update: {}, create: { phone: '09120000003', name: 'حسن', family: 'کریمی', shopName: 'تعمیرگاه پارس', specialty: 'مکانیک عمومی', city: 'تهران', verified: true, rating: 4.7 } })
  await db.mechanic.upsert({ where: { phone: '09120000004' }, update: {}, create: { phone: '09120000004', name: 'سینا', family: 'احمدی', shopName: 'کارشناس برق خودرو', specialty: 'برق خودرو', city: 'کرج', verified: false, rating: 0 } })

  // ---- A sample pending payment ----
  const rate = tgRate?.rate ?? 230000
  const margin = 3
  const eff = rate * (1 + margin / 100)
  const existingOrder = await db.order.findFirst({ where: { orderNumber: 'ORD-1001' } })
  if (!existingOrder) {
    const order = await db.order.create({
      data: {
        orderNumber: 'ORD-1001',
        customerId: cust1.id,
        status: 'PENDING',
        subtotalUsd: 36.2,
        shippingUsd: 2,
        totalUsd: 38.2,
        totalIrr: Math.round(38.2 * eff),
        currencyRateAtOrder: rate,
        marginPercentAtOrder: margin,
        shippingAddress: 'تهران، خیابان ولیعصر، پلاک ۱۲',
        paymentStatus: 'PENDING',
        items: {
          create: [
            { partId: (await db.part.findFirst({ where: { sku: 'BP-F-012' } }))!.id, partNameSnapshot: 'لنت ترمز جلو', quantity: 1, unitPriceUsd: 32, unitPriceIrr: Math.round(32 * eff), lineTotalUsd: 32, lineTotalIrr: Math.round(32 * eff) },
            { partId: (await db.part.findFirst({ where: { sku: 'OF-033' } }))!.id, partNameSnapshot: 'فیلتر روغن', quantity: 1, unitPriceUsd: 4.2, unitPriceIrr: Math.round(4.2 * eff), lineTotalUsd: 4.2, lineTotalIrr: Math.round(4.2 * eff) },
          ],
        },
      },
    })
    await db.payment.create({
      data: {
        orderId: order.id, customerId: cust1.id, amountIrr: Math.round(38.2 * eff), amountUsd: 38.2, method: 'CARD', status: 'PENDING', referenceCode: 'TXN-9988776655', payerName: 'علی محمدی', payerCard: '6037-9911-2233-4455',
      },
    })
  }

  // ---- Shop settings ----
  await db.setting.upsert({ where: { id: 'shopName' }, update: {}, create: { id: 'shopName', value: 'بازار قطعات خودرو' } })
  await db.setting.upsert({ where: { id: 'shopPhone' }, update: {}, create: { id: 'shopPhone', value: '021-12345678' } })
  await db.setting.upsert({ where: { id: 'shippingFlatFeeUsd' }, update: {}, create: { id: 'shippingFlatFeeUsd', value: '2' } })

  console.log('Seed complete.')
  console.log(`  Car models: ${passengerModels.length} passenger + ${heavyModels.length} heavy`)
  console.log(`  Parts: ${parts.length}`)
  console.log(`  Telegram rate: ${tgRate ? tgRate.rate.toLocaleString() + ' تومان' : 'fallback'}`)
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
